# -*- coding: utf-8 -*-
"""生成中文旁白：逐段合成 → 量时长 → 拼成一条连续音轨。

音频驱动时间轴，所以每段实测时长就是该片段的长度。

引擎优先级（2026-10-12 用户定）
--------------------------------
  1. **edge-tts**（`zh-CN-XiaoxiaoNeural` +8%）—— 默认主引擎。免费、无限量、本地零依赖，
     且在句号/分号处有**真停顿**（可直接用 `page_breaks.py` 做 silencedetect 找换页点）。
     ⚠️ 需要 v2 端点补丁，见下方「edge-tts 前置」。
  2. **fish-audio**（OpenRouter `/audio/speech`，**走代理**）—— 备选。edge-tts 挂了才用。
     ⚠️ 它**标点处没有真停顿**，`page_breaks.py` 会报「段内停顿 0 处」→ 必须改用
     **按屏分段合成**（把 `SEGMENTS` 那一项写成 list，见下）。

edge-tts 前置（2026-10-12：微软 v1 端点全球下线）
------------------------------------------------
现象 `WSServerHandshakeError: 403`，不代表签名/时钟/IP 有问题，而是
`speech.platform.bing.com` 被 `api.msedgeservices.com` 取代。修法一条命令：

    python <SKILL>/scripts/patch_edge_tts_v2.py            # 重装 edge-tts 后要重打
    python <SKILL>/scripts/patch_edge_tts_v2.py --check    # v2 -> exit 0

本脚本对 403 会打印这条提示，并在**直连失败时自动降级走代理**（本机直连境外随机失败）。

SEGMENTS 写法
-------------
    ("sec1", "一句话……")                 # 单屏段
    ("sec3", ["第一屏的话。", "第二屏的话。"])   # 多屏段：按语义边界预切，换页点确定

多屏段会先分别合成、再拼成 `seg_<name>.mp3`，并把**子段累计时长**写进
`segments.json` 的 `page_breaks` —— 这是多屏版式 `PAGE_BREAKS` 的真值源，
比事后用 silencedetect 猜点可靠（fish-audio 无停顿，edge-tts 也难免切在句中）。

可调环境变量
------------
    TTS_ENGINE   auto(默认) | edge | fish
    TTS_VOICE    edge 音色（默认 zh-CN-XiaoxiaoNeural）
    TTS_RATE     edge 语速（默认 +8%）
    TTS_FISH_VOICE / TTS_FISH_MODEL   fish 音色 / 模型
    TTS_PROXY    代理（默认 http://127.0.0.1:7890）
    TTS_OUT_NAME 输出名（默认 narration-v1.mp3；**改内容必须升版本号**）
    TTS_GAP / TTS_PAGE_GAP            段间 / 屏间静音秒数
    OPENROUTER_API_KEY                fish 备选引擎需要

输出（都在本脚本旁边）：
    seg_<name>.mp3    每段一个
    narration.mp3     拼好的整轨
    segments.json     {total, gap, page_gap, page_breaks, engine, segments:[…]}
    ../assets/<TTS_OUT_NAME>
"""
import argparse
import asyncio
import json
import os
import shutil
import subprocess
import sys
import time

# ---------------------------------------------------------------- 引擎配置
ENGINE = os.environ.get("TTS_ENGINE", "auto").strip().lower()   # auto | edge | fish
EDGE_VOICE = os.environ.get("TTS_VOICE", "zh-CN-XiaoxiaoNeural")
EDGE_RATE = os.environ.get("TTS_RATE", "+8%")

FISH_URL = os.environ.get("TTS_FISH_URL",
                          "https://openrouter.ai/api/v1/audio/speech")
FISH_MODEL = os.environ.get("TTS_FISH_MODEL", "fish-audio/s2.1-pro-free:free")
FISH_VOICE = os.environ.get("TTS_FISH_VOICE", "5c353fdb312f4888836a9a5680099ef0")

PROXY = os.environ.get("TTS_PROXY", "http://127.0.0.1:7890")

OUT_NAME = os.environ.get("TTS_OUT_NAME", "narration-v1.mp3")

GAP = float(os.environ.get("TTS_GAP", "0.30"))            # 段间静音
PAGE_GAP = float(os.environ.get("TTS_PAGE_GAP", "0.22"))  # 段内分屏静音
MIN_BYTES = 2000     # 小于此体积基本是空壳 / 半截文件

HERE = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------- ffmpeg
def _find(exe, env_var):
    p = os.environ.get(env_var)
    if p and os.path.exists(p):
        return p
    p = shutil.which(exe)
    if p:
        return p
    return None


FFMPEG = _find("ffmpeg", "FFMPEG")
FFPROBE = _find("ffprobe", "FFPROBE")
if FFMPEG and not FFPROBE:  # infer the sibling next to ffmpeg
    sibling = os.path.join(os.path.dirname(FFMPEG),
                           "ffprobe.exe" if os.name == "nt" else "ffprobe")
    FFPROBE = sibling if os.path.exists(sibling) else None


# ---------------------------------------------------------------- script
# 编辑 SEGMENTS 前先读 SKILL.md 第 4 步。段数必须与模式匹配：
#   a-share -> 7 段: intro, sec1..sec5, outro
#              （② 概述找不到跨市场共性时**整段省略** = 6 段，段名跳 sec2、拥挤不顺移）
#   us      -> 6 段: intro, sec1..sec4, outro   (4 sections, fixed)
# 数字一律写口语中文（"五千三百五十九点九九"，不是 "53,559.99"），否则会被逐位念。
#
# 多屏段：把那一项写成 list，按「一屏一句」切 —— 换页点 = 子段累计时长（确定性）。
#
# 旁白硬闸门（2026-09-24 起，逐条都踩过）：
#   * **intro 段不读日期、不预演后续板块** —— ≤3 句且 ≤22 字（≈5.4s）。
#     日期由画面承载（片头日期小字），念出来纯属浪费 2 秒。
#   * **每个 topic / 板块最多播报 3 条明细**：画面负责完整、旁白负责精炼。
#     rank-list 可以排十行、topic 可以挂多个 chip，但旁白最多点名 3 条，
#     或汇总成最多 3 句话。逐条念完是「成片被拖长」的头号原因（实测 ~4.3 汉字/秒）。
#   * **指数一律只报涨跌幅、不报点位**（点位留在画面上）；个股涨跌幅可照报。
#     a-share sec1（大盘，2 屏）= A股 4 指数 + 港韩日 3 指数，7 个都念百分比。
#   * **A股综述（sec3）只点名一个领涨股**；**港股综述（sec4）只报南向资金**。
#   * **休市市场只在指数段念一句「XX今日休市」**，其综述段整段省略（日韩按市场粒度省略）。
SEGMENTS = [
    ("intro", "节前缩量观望，A股微涨，港股科技走弱。"),          # 19 字 / 4.45s，不读日期
    ("sec1", ["首先看A股，上证指数涨百分之零点一八，沪深300涨百分之零点一零，创业板指涨百分之零点零九，科创50涨百分之零点八六。",
              "港韩日方面，恒生指数跌百分之零点四八，日经225跌百分之零点六零，韩国综指跌百分之零点二七。"]),
    ("sec2", "全球方面，隔夜十年期美债收益率突破百分之五点二，创二零零七年以来最高；国际油价维持高位，布伦特原油接近九十八美元。港股科技股与日韩权重股同步走弱；A股则靠稳地产等国内政策预期独立收红。"),
    ("sec3", ["两市成交一点四一万亿元，较上日缩量两千九百三十六亿元，创十四个月新低；成交额前三为中际旭创、亨通光电与新易盛。",
              "领涨方向，房地产板块走强，特发服务涨超百分之十三；固态电池与印刷电路板板块同步大涨，多股涨停。领跌方向，石油石化板块跌幅居前，培育钻石与种植业板块同步走弱。"]),
    ("sec4", "港股方面，南向资金净买入不足一亿元，基本持平；内房股领涨，万科企业涨超百分之十一；汽车股走弱，吉利汽车跌百分之七点三六。"),
    ("sec5", ["日本方面，半导体设备股领涨，网屏制造涨百分之二点六五；银行股领跌，三井住友跌超百分之四。",
              "韩国方面，半导体设备与材料股领涨，HPSP涨百分之八点九三；电池股走弱，LG新能源跌百分之三点一六。"]),
    ("outro", "投资有风险，视频内容不构成投资建议。"),
]

# 美股模式示例（整段替换上面的 SEGMENTS；同样可把 sec2/sec3 写成 list 分屏）：
# SEGMENTS = [
#     ("intro", "AI 龙头一涨一跌，油价跳水、美股收涨。"),
#     ("sec1", "美股大盘方面，道琼斯指数涨百分之零点九三，标普500涨百分之零点五一，纳斯达克综合指数涨百分之零点四八，费城半导体指数涨百分之一点四一，三大指数周线齐涨。标普500十一大板块八涨三跌，科技与工业领涨，能源与通信服务领跌。最大推手是油价跳水，美债短端回落，但三十年期收益率续创二〇〇四年以来新高。"),
#     ("sec2", "当日主线是 AI 硬件全面走强。微软涨百分之三点六六、创去年十一月以来收盘新高，当天发布新版 Copilot。费城半导体指数本周累涨百分之六点二七、周线四连涨；安森美涨百分之五点五四，微芯科技涨百分之五点三六。存储与高速互连同步发力，SK 海力士涨百分之二点七八，Credo 涨百分之七点六五，唯亚威通讯涨百分之九点二七。"),
#     ("sec3", "大型科技股涨跌分化。微软涨百分之三点六六、创去年十一月以来收盘新高；苹果涨百分之一点五三、再创历史收盘新高；Meta 跌百分之三点三三，本周仍累涨近百分之十三。万得美国科技七巨头指数涨百分之零点六六。中概股多数下跌，纳斯达克中国金龙指数跌百分之零点六四，陆金所控股跌近百分之九，亚玛芬体育涨超百分之三。"),
#     ("sec4", "承压的一面是能源与通信服务板块，分别跌百分之零点八七和百分之零点六五。油价跳水拖累石油股，西方石油跌百分之二点零五，康菲石油跌百分之一点五八。个股方面，Zscaler 跌超百分之十，Gen Digital 跌超百分之六、本周累跌超百分之二十五。另一面，贵金属止跌反弹，现货黄金小幅收涨，黄金股多数走高，金罗斯黄金涨百分之二点六。欧股涨跌不一，德国 DAX 涨百分之零点五六，美元指数跌百分之零点三二。"),
#     ("outro", "投资有风险，视频内容不构成投资建议。"),
# ]


def probe_duration(path: str) -> float:
    r = subprocess.run(
        [FFPROBE, "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", path],
        capture_output=True, text=True)
    d = (r.stdout or "").strip()
    if not d:
        raise RuntimeError(f"ffprobe 量不到时长（文件可能是半截/空壳）：{path}")
    return float(d)


# ---------------------------------------------------------------- 引擎一：edge-tts
def _edge_hint(msg: str) -> str:
    if "403" in msg:
        return "  ← 403 = v1 端点已下线，先跑 scripts/patch_edge_tts_v2.py 打 v2 补丁"
    if "429" in msg:
        return "  ← 429 = 限流（≠没修好），稍后重试即可"
    if "Cannot connect" in msg or "timed out" in msg or "Timeout" in msg:
        return "  ← 直连境外随机失败，改走代理"
    return ""


async def _synth_edge(text: str, out: str, tries: int = 3) -> None:
    """edge-tts 合成。每轮先直连、失败再走代理；429/网络抖动退避重试。"""
    import edge_tts

    last = ""
    for attempt in range(tries):
        for label, proxy in (("direct", None), ("proxy", PROXY)):
            if proxy is None and label == "proxy":
                continue
            try:
                c = edge_tts.Communicate(text, EDGE_VOICE, rate=EDGE_RATE,
                                         proxy=proxy)
                await c.save(out)
                n = os.path.getsize(out) if os.path.exists(out) else 0
                if n < MIN_BYTES:
                    # 撞 429 时接口会留下 0 字节 / 半截文件，必须当失败
                    raise RuntimeError(
                        f"只写出 {n} 字节（低于下限 {MIN_BYTES}，"
                        "多半是限流留下的空壳文件）")
                return
            except Exception as e:  # noqa: BLE001
                last = f"{type(e).__name__}: {e}"
                print(f"    [edge-tts] {label} 第 {attempt + 1}/{tries} 次失败："
                      f"{last[:120]}{_edge_hint(last)}")
                await asyncio.sleep(4 * (attempt + 1))
    raise RuntimeError(f"edge-tts 合成失败：{last[:200]}")


# ---------------------------------------------------------------- 引擎二：fish-audio（备选）
def _synth_fish(text: str, out: str, tries: int = 4) -> None:
    """OpenRouter /audio/speech 的 fish-audio。必须走代理。"""
    import requests

    key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not key:
        raise RuntimeError("缺少 OPENROUTER_API_KEY（fish 备选引擎需要）")
    proxies = {"http": PROXY, "https": PROXY} if PROXY else None
    s = requests.Session()
    s.trust_env = False          # 本机系统代理开关是关的，必须显式传
    body = {"model": FISH_MODEL, "voice": FISH_VOICE,
            "input": text, "response_format": "mp3"}
    headers = {"Authorization": f"Bearer {key}",
               "Content-Type": "application/json"}
    last = ""
    for attempt in range(tries):
        try:
            r = s.post(FISH_URL, json=body, headers=headers,
                       proxies=proxies, timeout=120)
            if r.status_code == 429:
                wait = 5 * (attempt + 1)
                print(f"    [fish] 429 限流，等 {wait}s 重试")
                time.sleep(wait)
                continue
            r.raise_for_status()
            data = r.content
            # 首字节判型：正常 mp3 以 0xFF 同步字或 ID3 开头
            if data[:1] == b"\xff" or data[:3] == b"ID3":
                with open(out, "wb") as f:
                    f.write(data)
                return
            last = f"返回非 mp3（首字节 {data[:8]!r}，{len(data)} 字节）"
        except Exception as e:  # noqa: BLE001
            last = f"{type(e).__name__}: {e}"
        print(f"    [fish] 第 {attempt + 1}/{tries} 次失败：{last[:120]}")
        time.sleep(3 * (attempt + 1))
    raise RuntimeError(f"fish-audio 合成失败：{last[:200]}")


# ---------------------------------------------------------------- 调度
def synthesize(name: str, text: str, out: str) -> str:
    """按 ENGINE 优先级合成，返回实际生效的引擎名。"""
    order = {"auto": ["edge", "fish"], "edge": ["edge"], "fish": ["fish"]}[ENGINE]
    errs = []
    for eng in order:
        try:
            if eng == "edge":
                asyncio.run(_synth_edge(text, out))
            else:
                _synth_fish(text, out)
            return eng
        except Exception as e:  # noqa: BLE001
            errs.append(f"{eng}: {e}")
            if eng != order[-1]:
                print(f"  [warn] {eng} 失败，降级到 {order[order.index(eng) + 1]} 引擎")
    raise RuntimeError(f"{name} 所有引擎均失败 -> " + " | ".join(
        e[:160] for e in errs))


# ---------------------------------------------------------------- 拼接
def concat_parts(files, out: str, gap: float) -> None:
    """段内多屏拼接：只在前 n-1 段后补 gap，最后一段 anull（否则尾部多一截静音）。"""
    if len(files) == 1:
        shutil.copy2(files[0], out)
        return
    inputs = []
    for f in files:
        inputs += ["-i", f]
    parts = []
    for i in range(len(files)):
        tail = f"apad=pad_dur={gap}" if i < len(files) - 1 else "anull"
        parts.append(f"[{i}]{tail}[a{i}]")
    parts.append("".join(f"[a{i}]" for i in range(len(files)))
                 + f"concat=n={len(files)}:v=0:a=1[out]")
    subprocess.run([FFMPEG, "-y", *inputs, "-filter_complex", ";".join(parts),
                    "-map", "[out]", "-c:a", "libmp3lame", "-b:a", "128k", out],
                   capture_output=True, text=True, check=True)


def spec_parts(spec) -> list[str]:
    return [spec] if isinstance(spec, str) else list(spec)


# ---------------------------------------------------------------- main
def run(resume: bool = False) -> int:
    if not FFMPEG or not FFPROBE:
        print("[error] 找不到 ffmpeg/ffprobe。请安装后加入 PATH，"
              "或设置 FFMPEG / FFPROBE 环境变量指向可执行文件。", file=sys.stderr)
        return 1

    os.makedirs(HERE, exist_ok=True)
    durations, parts_dur, engines_used = {}, {}, []

    for name, spec in SEGMENTS:
        texts = spec_parts(spec)
        seg_path = os.path.join(HERE, f"seg_{name}.mp3")
        if resume and os.path.exists(seg_path) and \
                os.path.getsize(seg_path) >= MIN_BYTES:
            try:
                durations[name] = probe_duration(seg_path)
                parts_dur[name] = [durations[name]]
                print(f"[keep]  {name} {durations[name]:.2f}s（已存在，跳过）")
                continue
            except Exception as e:  # noqa: BLE001
                print(f"[keep-x] {name} 体积达标但量不到时长（{e}），重合成")

        print(f"[synth] {name} ...（{len(texts)} 屏，engine={ENGINE}）")
        part_files = []
        for i, t in enumerate(texts):
            pf = (seg_path if len(texts) == 1
                  else os.path.join(HERE, f"_p{name}_{i}.mp3"))
            eng = synthesize(name if len(texts) == 1 else f"{name}[{i + 1}]", t, pf)
            engines_used.append(eng)
            part_files.append(pf)
            print(f"         {name}[{i + 1}] {probe_duration(pf):.2f}s  via {eng}")

        if len(part_files) == 1:
            parts_dur[name] = [probe_duration(part_files[0])]
        else:
            concat_parts(part_files, seg_path, PAGE_GAP)
            parts_dur[name] = [probe_duration(p) for p in part_files]
        durations[name] = probe_duration(seg_path)
        print(f"         {name}: {durations[name]:.2f}s"
              + (f"（{len(part_files)} 屏）" if len(part_files) > 1 else ""))

    # 时间轴 + 换页点（真值源）
    timeline, page_breaks = [], {}
    start = 0.0
    for name, spec in SEGMENTS:
        plist = parts_dur[name]
        if len(plist) > 1:
            acc, marks = start, []
            for d in plist[:-1]:
                acc += d + PAGE_GAP
                marks.append(round(acc, 3))
            page_breaks[name] = marks
        else:
            page_breaks[name] = []
        timeline.append({"name": name, "start": round(start, 3),
                         "duration": round(durations[name] + GAP, 3)})
        start += durations[name] + GAP
    total = round(start, 3)

    # 整轨拼接
    inputs = []
    for name, _ in SEGMENTS:
        inputs += ["-i", os.path.join(HERE, f"seg_{name}.mp3")]
    parts = []
    for i in range(len(SEGMENTS)):
        parts.append(f"[{i}]apad=pad_dur={GAP}[a{i}]")
    parts.append("".join(f"[a{i}]" for i in range(len(SEGMENTS)))
                 + f"concat=n={len(SEGMENTS)}:v=0:a=1[out]")
    narration = os.path.join(HERE, "narration.mp3")
    print("[mux] concat narration ...")
    subprocess.run([FFMPEG, "-y", *inputs, "-filter_complex", ";".join(parts),
                    "-map", "[out]", "-c:a", "libmp3lame", "-b:a", "128k",
                    narration], capture_output=True, text=True, check=True)

    dst = os.path.abspath(os.path.join(HERE, "..", "assets", OUT_NAME))
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(narration, dst)

    engines = sorted(set(engines_used))
    out_json = {
        "total": total,
        "gap": GAP,
        "page_gap": PAGE_GAP,
        "page_breaks": page_breaks,          # -> build_cards.py 的 PAGE_BREAKS（绝对秒）
        "engine": engines[0] if len(engines) == 1 else (engines or [ENGINE]),
        "engines_used": engines_used,
        "voice": FISH_VOICE if engines and engines[0] == "fish" else EDGE_VOICE,
        "rate": EDGE_RATE,
        "out_name": OUT_NAME,
        "segments": timeline,
    }
    with open(os.path.join(HERE, "segments.json"), "w", encoding="utf-8") as f:
        json.dump(out_json, f, ensure_ascii=False, indent=2)

    print("\n===== TIMELINE =====")
    print(f"total = {total:.2f}s   engine = {out_json['engine']}")
    for t in timeline:
        pb = page_breaks.get(t["name"]) or []
        extra = f"  page_breaks={pb}" if pb else ""
        print(f"{t['name']:6s}  start={t['start']:7.2f}  dur={t['duration']:6.2f}{extra}")
    print(f"narration -> {narration}")
    print(f"           -> {dst}")
    if out_json["page_breaks"]:
        print("\n把上面的 page_breaks 抄进 build_cards.py 的 PAGE_BREAKS（绝对秒）。")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--resume", action="store_true",
                    help="跳过已存在且体积达标的 seg_*.mp3，只补缺失/损坏的")
    a = ap.parse_args()
    return run(resume=a.resume)


if __name__ == "__main__":
    sys.exit(main())
