# -*- coding: utf-8 -*-
"""Generate Chinese narration for the stock video, measure per-segment
duration, and mux a single continuous track with inter-segment gaps.

Audio drives the video timeline, so each segment's measured duration
becomes that clip's length.

Portable: ffmpeg/ffprobe are auto-detected from $FFMPEG/$FFPROBE or PATH.
Run `python preflight.py` first if you are unsure whether they are on PATH.

Outputs (all next to this script):
    seg_<name>.mp3    one file per segment
    narration.mp3     concatenated track with GAP silence between segments
    segments.json     {total, gap, segments:[{name,start,duration}]}
"""
import asyncio
import json
import os
import shutil
import subprocess
import sys

import edge_tts

VOICE = os.environ.get("TTS_VOICE", "zh-CN-XiaoxiaoNeural")
RATE = os.environ.get("TTS_RATE", "+8%")
GAP = 0.30  # seconds of silence between segments

HERE = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------- ffmpeg
def _find(exe, env_var):
    p = os.environ.get(env_var)
    if p and os.path.exists(p):
        return p
    p = shutil.which(exe)
    if p:
        return p
    return None


FFMPEG = _find("ffmpeg", "FFMPEG")
FFPROBE = _find("ffprobe", "FFPROBE")
if FFMPEG and not FFPROBE:  # infer the sibling next to ffmpeg
    sibling = os.path.join(os.path.dirname(FFMPEG),
                           "ffprobe.exe" if os.name == "nt" else "ffprobe")
    FFPROBE = sibling if os.path.exists(sibling) else None

# ---------------------------------------------------------------- script
# Edit SEGMENTS before running. Segment count must match the mode:
#   a-share -> 7 segments: intro, sec1..sec5, outro
#              （② 概述找不到跨市场共性时**整段省略** = 6 段，段名跳 sec2、拥挤不顺移）
#   us      -> 6 segments: intro, sec1..sec4, outro   (4 sections, fixed)
# Write every number in spoken Chinese ("五千三百五十九点九九", not "53,559.99")
# so edge-tts does not mispronounce it.
#
# 旁白硬闸门（2026-09-24 起，逐条都踩过）：
#   * **intro 段不读日期、不预演后续板块** —— ≤3 句且 ≤22 字（≈5.4s）。
#     日期由画面承载（片头日期小字），念出来纯属浪费 2 秒。
#   * **每个 topic / 板块最多播报 3 条明细**：画面负责完整、旁白负责精炼。
#     rank-list 可以排十行、topic 可以挂多个 chip，但旁白最多点名 3 条，
#     或汇总成最多 3 句话。逐条念完是「成片被拖长」的头号原因（实测 4.3 汉字/秒）。
#   * **指数一律只报涨跌幅、不报点位**（点位留在画面上）；个股涨跌幅可照报。
#     a-share sec1（大盘，2 屏）= A股 4 指数 + 港韩日 3 指数，7 个都念百分比
#     （画面只有指数、旁白也只讲指数）；us sec1 = 道指/标普500/纳指/费半 4 个全念
#     （它们经常背离，省掉会丢信息量）。
#   * **A股综述（sec3）只点名一个领涨股**；**港股综述（sec4）只报南向资金**
#     （不报港股大市总成交额）。
SEGMENTS = [
    ("intro", "节前缩量观望，A股微涨，港股科技走弱。"),          # 19 字 / 4.45s，不读日期
    ("sec1", "首先看A股，上证指数涨百分之零点一八，沪深300涨百分之零点一零，创业板指涨百分之零点零九，科创50涨百分之零点八六。港韩日方面，恒生指数跌百分之零点四八，日经225跌百分之零点六零，韩国综指跌百分之零点二七。"),
    ("sec2", "全球方面，隔夜十年期美债收益率突破百分之五点二，创二零零七年以来最高；国际油价维持高位，布伦特原油接近九十八美元。港股科技股与日韩权重股同步走弱；A股则靠稳地产等国内政策预期独立收红。"),
    ("sec3", "两市成交一点四一万亿元，较上日缩量两千九百三十六亿元，创十四个月新低；成交额前三为中际旭创、亨通光电与新易盛。领涨方向，房地产板块走强，特发服务涨超百分之十三；固态电池与印刷电路板板块同步大涨，多股涨停。领跌方向，石油石化板块跌幅居前，培育钻石与种植业板块同步走弱。"),
    ("sec4", "港股方面，南向资金净买入不足一亿元，基本持平；内房股领涨，万科企业涨超百分之十一；汽车股走弱，吉利汽车跌百分之七点三六。"),
    ("sec5", "日本方面，半导体设备股领涨，网屏制造涨百分之二点六五；银行股领跌，三井住友跌超百分之四。韩国方面，半导体设备与材料股领涨，HPSP涨百分之八点九三；电池股走弱，LG新能源跌百分之三点一六。"),
    ("outro", "投资有风险，视频内容不构成投资建议。"),
]

# 美股模式示例（整段替换上面的 SEGMENTS）：
# SEGMENTS = [
#     ("intro", "AI 龙头一涨一跌，油价跳水、美股收涨。"),
#     ("sec1", "美股大盘方面，道琼斯指数涨百分之零点九三，标普500涨百分之零点五一，纳斯达克综合指数涨百分之零点四八，费城半导体指数涨百分之一点四一，三大指数周线齐涨。标普500十一大板块八涨三跌，科技与工业领涨，能源与通信服务领跌。最大推手是油价跳水，美债短端回落，但三十年期收益率续创二〇〇四年以来新高。"),
#     ("sec2", "当日主线是 AI 硬件全面走强。微软涨百分之三点六六、创去年十一月以来收盘新高，当天发布新版 Copilot。费城半导体指数本周累涨百分之六点二七、周线四连涨；安森美涨百分之五点五四，微芯科技涨百分之五点三六。存储与高速互连同步发力，SK 海力士涨百分之二点七八，Credo 涨百分之七点六五，唯亚威通讯涨百分之九点二七。"),
#     ("sec3", "大型科技股涨跌分化。微软涨百分之三点六六、创去年十一月以来收盘新高；苹果涨百分之一点五三、再创历史收盘新高；Meta 跌百分之三点三三，本周仍累涨近百分之十三。万得美国科技七巨头指数涨百分之零点六六。中概股多数下跌，纳斯达克中国金龙指数跌百分之零点六四，陆金所控股跌近百分之九，亚玛芬体育涨超百分之三。"),
#     ("sec4", "承压的一面是能源与通信服务板块，分别跌百分之零点八七和百分之零点六五。油价跳水拖累石油股，西方石油跌百分之二点〇五，康菲石油跌百分之一点五八。个股方面，Zscaler 跌超百分之十，Gen Digital 跌超百分之六、本周累跌超百分之二十五。另一面，贵金属止跌反弹，现货黄金小幅收涨，黄金股多数走高，金罗斯黄金涨百分之二点六。欧股涨跌不一，德国 DAX 涨百分之零点五六，美元指数跌百分之零点三二。"),
#     ("outro", "投资有风险，视频内容不构成投资建议。"),
# ]


def probe_duration(path: str) -> float:
    r = subprocess.run(
        [FFPROBE, "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", path],
        capture_output=True, text=True)
    return float(r.stdout.strip())


async def synthesize(name: str, text: str, out: str) -> None:
    for attempt in range(3):
        try:
            c = edge_tts.Communicate(text, VOICE, rate=RATE)
            await c.save(out)
            return
        except Exception as e:  # noqa: BLE001
            print(f"  retry {attempt + 1} for {name}: {e}")
            await asyncio.sleep(2)
    raise RuntimeError(f"failed to synthesize {name}")


async def main() -> None:
    if not FFMPEG or not FFPROBE:
        print("[error] 找不到 ffmpeg/ffprobe。请安装后加入 PATH，"
              "或设置 FFMPEG / FFPROBE 环境变量指向可执行文件。", file=sys.stderr)
        sys.exit(1)

    os.makedirs(HERE, exist_ok=True)
    durations = {}
    for name, text in SEGMENTS:
        seg_path = os.path.join(HERE, f"seg_{name}.mp3")
        print(f"[synth] {name} ...")
        await synthesize(name, text, seg_path)
        durations[name] = probe_duration(seg_path)
        print(f"         {name}: {durations[name]:.2f}s")

    timeline = []
    start = 0.0
    for name, _ in SEGMENTS:
        d = durations[name]
        timeline.append({
            "name": name,
            "start": round(start, 3),
            "duration": round(d + GAP, 3),  # clip covers speech + gap tail
        })
        start += d + GAP
    total = round(start, 3)

    inputs = []
    for name, _ in SEGMENTS:
        inputs += ["-i", os.path.join(HERE, f"seg_{name}.mp3")]
    filter_parts = []
    for i in range(len(SEGMENTS)):
        filter_parts.append(f"[{i}]apad=pad_dur={GAP}[a{i}]")
    concat_labels = "".join(f"[a{i}]" for i in range(len(SEGMENTS)))
    filter_parts.append(f"{concat_labels}concat=n={len(SEGMENTS)}:v=0:a=1[out]")
    narration = os.path.join(HERE, "narration.mp3")
    cmd = [FFMPEG, "-y", *inputs, "-filter_complex", ";".join(filter_parts),
           "-map", "[out]", "-c:a", "libmp3lame", "-b:a", "128k", narration]
    print("[mux] concat narration ...")
    subprocess.run(cmd, capture_output=True, text=True, check=True)
    shutil.copy2(narration, os.path.join(HERE, "..", "assets", "narration-v1.mp3"))

    out_json = {
        "total": total,
        "gap": GAP,
        "voice": VOICE,
        "rate": RATE,
        "segments": timeline,
    }
    with open(os.path.join(HERE, "segments.json"), "w", encoding="utf-8") as f:
        json.dump(out_json, f, ensure_ascii=False, indent=2)

    print("\n===== TIMELINE =====")
    print(f"total = {total:.2f}s")
    for t in timeline:
        print(f"{t['name']:6s}  start={t['start']:7.2f}  dur={t['duration']:6.2f}")
    print(f"narration -> {narration}")
    print(f"           -> {os.path.abspath(os.path.join(HERE, '..', 'assets', 'narration-v1.mp3'))}")


if __name__ == "__main__":
    asyncio.run(main())
