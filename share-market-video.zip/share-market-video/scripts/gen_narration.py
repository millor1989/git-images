# -*- coding: utf-8 -*-
"""Generate Chinese narration for the stock video, measure per-segment
duration, and mux a single continuous track with inter-segment gaps.

Audio drives the video timeline, so each segment's measured duration
becomes that clip's length.

Portable: ffmpeg/ffprobe are auto-detected from $FFMPEG/$FFPROBE or PATH.
Run `python preflight.py` first if you are unsure whether they are on PATH.

Outputs (all next to this script):
    seg_<name>.mp3    one file per segment
    narration.mp3     concatenated track with GAP silence between segments
    segments.json     {total, gap, segments:[{name,start,duration}]}
"""
import asyncio
import json
import os
import shutil
import subprocess
import sys

import edge_tts

VOICE = os.environ.get("TTS_VOICE", "zh-CN-XiaoxiaoNeural")
RATE = os.environ.get("TTS_RATE", "+8%")
GAP = 0.30  # seconds of silence between segments

HERE = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------- ffmpeg
def _find(exe, env_var):
    p = os.environ.get(env_var)
    if p and os.path.exists(p):
        return p
    p = shutil.which(exe)
    if p:
        return p
    return None


FFMPEG = _find("ffmpeg", "FFMPEG")
FFPROBE = _find("ffprobe", "FFPROBE")
if FFMPEG and not FFPROBE:  # infer the sibling next to ffmpeg
    sibling = os.path.join(os.path.dirname(FFMPEG),
                           "ffprobe.exe" if os.name == "nt" else "ffprobe")
    FFPROBE = sibling if os.path.exists(sibling) else None

# ---------------------------------------------------------------- script
# Edit SEGMENTS before running. Segment count must match the mode:
#   a-share -> 7 segments: intro, sec1..sec5, outro
#   us      -> 6 segments: intro, sec1..sec4, outro   (4 sections, fixed)
# Write every number in spoken Chinese ("五千三百五十九点九九", not "53,559.99")
# so edge-tts does not mispronounce it.
#
# ITEM CAP (hard rule): each topic/section narrates AT MOST 3 line items.
# The visuals may show the full list (a 10-row rank list, many chips), but the
# voice reads at most 3 representative items plus one summary sentence -- three
# sentences per segment, max. E.g. 10 movers -> name 3 only; a volume top-10
# list -> read the top 3 only. Reading every item verbatim is the #1 cause of
# bloated, over-long videos.
#
# a-share sec1 (index cards): SHOW 6 cards (上证指数/深证成指/创业板指/科创50/
# 沪深300/北证50) but NARRATE ONLY 3 -- 上证指数, 创业板指, 沪深300. The other
# three (深证成指/科创50/北证50) are visual-only: they track 上证 closely, so
# reading their points is pure repetition. If small-cap divergence matters, fold
# it into one clause ("北证50 跌百分之二点六六，小盘股更弱"). us sec1 is exempt --
# narrate all 4 (道指/标普500/纳指/费半), they often diverge.
SEGMENTS = [
    ("intro", "今日股市行情，2026年8月31日，周一。"),
    ("sec1", "A股大盘方面，上证指数报三千九百八十六点三零，涨百分之零点八六；创业板指报三千四百三十八点六八，涨百分之零点四二；沪深300报四千六百二十五点零九，涨百分之零点三五。两市成交两万一千三百亿元，较上日放量约两百八十亿元；超三千只个股上涨，八十九只涨停。"),
    ("sec2", "热门板块方面，AI视频与短剧概念掀涨停潮，中文在线、芒果超媒二十厘米涨停；AI芯片、液冷服务器走强，瑞芯微、浪潮信息涨停。领跌方面，贵金属、光伏设备、创新药调整，白银有色跌近百分之十，阳光电源跌超百分之六。"),
    ("sec3", "成交额前十方面，长鑫科技成交两百零九亿居首，中际旭创一百八十九亿紧随其后，新易盛一百七十六亿位列第三。"),
    ("sec4", "港股方面，恒生指数报两万五千五百六十六点九九，微跌百分之零点零七；恒生科技指数报四千六百一十九点八七，涨百分之零点三二。内银股领涨，中国银行涨超百分之五创历史新高；AI应用活跃，MINIMAX涨超百分之十六。内房股领跌，绿城中国跌超百分之十七。"),
    ("sec5", "韩日股市方面，日经二二五报六万六千三百一十一点九三，跌百分之零点一四；韩国KOSPI报六千八百二十点一零，涨百分之零点四六。存储芯片尾盘反攻，三星电子、SK海力士转涨。"),
    ("outro", "投资有风险，视频内容不构成投资建议。"),
]

# 美股模式示例（替换上面的 SEGMENTS 即可）：
# SEGMENTS = [
#     ("intro", "隔夜美股行情，2026年8月31日，周一。"),
#     ("sec1",  "美股大盘方面，道琼斯指数报五万三千一百八十五点九零，跌百分之零点七零；标普500报七千六百八十六点一四，跌百分之零点三三；纳斯达克综合指数报两万六千三百七十点八九，跌百分之零点一二；费城半导体指数报一万一千五百三十五点零五，涨百分之零点五七。"),
#     ("sec2",  "热门板块方面，能源板块领涨；通信与公用事业跌幅居前。中概股普遍回落。"),
#     ("outro", "投资有风险，视频内容不构成投资建议。"),
# ]


def probe_duration(path: str) -> float:
    r = subprocess.run(
        [FFPROBE, "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", path],
        capture_output=True, text=True)
    return float(r.stdout.strip())


async def synthesize(name: str, text: str, out: str) -> None:
    for attempt in range(3):
        try:
            c = edge_tts.Communicate(text, VOICE, rate=RATE)
            await c.save(out)
            return
        except Exception as e:  # noqa: BLE001
            print(f"  retry {attempt + 1} for {name}: {e}")
            await asyncio.sleep(2)
    raise RuntimeError(f"failed to synthesize {name}")


async def main() -> None:
    if not FFMPEG or not FFPROBE:
        print("[error] 找不到 ffmpeg/ffprobe。请安装后加入 PATH，"
              "或设置 FFMPEG / FFPROBE 环境变量指向可执行文件。", file=sys.stderr)
        sys.exit(1)

    os.makedirs(HERE, exist_ok=True)
    durations = {}
    for name, text in SEGMENTS:
        seg_path = os.path.join(HERE, f"seg_{name}.mp3")
        print(f"[synth] {name} ...")
        await synthesize(name, text, seg_path)
        durations[name] = probe_duration(seg_path)
        print(f"         {name}: {durations[name]:.2f}s")

    timeline = []
    start = 0.0
    for name, _ in SEGMENTS:
        d = durations[name]
        timeline.append({
            "name": name,
            "start": round(start, 3),
            "duration": round(d + GAP, 3),  # clip covers speech + gap tail
        })
        start += d + GAP
    total = round(start, 3)

    inputs = []
    for name, _ in SEGMENTS:
        inputs += ["-i", os.path.join(HERE, f"seg_{name}.mp3")]
    filter_parts = []
    for i in range(len(SEGMENTS)):
        filter_parts.append(f"[{i}]apad=pad_dur={GAP}[a{i}]")
    concat_labels = "".join(f"[a{i}]" for i in range(len(SEGMENTS)))
    filter_parts.append(f"{concat_labels}concat=n={len(SEGMENTS)}:v=0:a=1[out]")
    narration = os.path.join(HERE, "narration.mp3")
    cmd = [FFMPEG, "-y", *inputs, "-filter_complex", ";".join(filter_parts),
           "-map", "[out]", "-c:a", "libmp3lame", "-b:a", "128k", narration]
    print("[mux] concat narration ...")
    subprocess.run(cmd, capture_output=True, text=True, check=True)
    shutil.copy2(narration, os.path.join(HERE, "..", "assets", "narration-v1.mp3"))

    out_json = {
        "total": total,
        "gap": GAP,
        "voice": VOICE,
        "rate": RATE,
        "segments": timeline,
    }
    with open(os.path.join(HERE, "segments.json"), "w", encoding="utf-8") as f:
        json.dump(out_json, f, ensure_ascii=False, indent=2)

    print("\n===== TIMELINE =====")
    print(f"total = {total:.2f}s")
    for t in timeline:
        print(f"{t['name']:6s}  start={t['start']:7.2f}  dur={t['duration']:6.2f}")
    print(f"narration -> {narration}")
    print(f"           -> {os.path.abspath(os.path.join(HERE, '..', 'assets', 'narration-v1.mp3'))}")


if __name__ == "__main__":
    asyncio.run(main())
