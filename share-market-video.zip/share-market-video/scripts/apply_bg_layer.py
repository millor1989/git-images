# -*- coding: utf-8 -*-
"""apply_bg_layer.py — 给已生成的 index.html 追加「可 seek 星空背景层」（全屏装饰背景）。

用法（**必须在 build_cards.py 之后跑**，见下）：
    python <SKILL>/scripts/apply_bg_layer.py --proj <PROJ> [--scrim 0.60]

    --proj <PROJ>        工程目录（默认当前目录）
    --scrim 0.60         深色遮罩强度：0.60 通透 / 0.78 保守（背景更淡、字更稳）
    --card-back 0.45     卡底加深量：0 = 原来的纯白半透明；0.45 = 近实心深底（副行最好读）
    --plate <jpg/png>    换掉底板图（默认 <SKILL>/assets/bg/taurus.jpg 金色星座牛）
    --seed <int>         星点种子（换种子 = 换一片星空，密度与分布完全一致）
    --live-stars 40      有几颗星做真实闪烁（**>60 会触发 snapshot 超时**，别乱加）
    --no-hero            不出 hero 主星层（只想试背景板时用）
    --parallax           开背景位移（**默认关，且强烈建议保持关**：码率 ×4）

⚠⚠ **顺序硬约束**：`build_cards.py` 每次重跑都会**整个重写 index.html**，本脚本追加的东西会
    被冲掉。所以正确顺序永远是：
        python build_cards.py && python <SKILL>/scripts/apply_bg_layer.py --proj .
    改完版式（SECTIONS / SEC*_PAGES / 文案）只跑 build_cards.py 会**静默丢掉背景层**。
    本脚本检测到 index.html 里已有 `<div id="hfbg">` 会直接报错退出，不叠加、不半途而废。

为什么不直接把背景写进 `_base-head.html` / `build_cards.py`：
  · 那两样是**版式载体**，改它们会污染所有场次和 `cp index.html _b.html` 的 diff 校验；
  · 背景层是**可选装饰**，成本不低（见下），应当逐期决定要不要；
  · 独立脚本 + 独立 id/类名 → 想撤掉只要重跑一次 build_cards.py，零残留。

成本（2026-09-30 实测，1080×1920/30fps，同一 recipe，30 秒切片）：
    纯色底（不加本层）        1.15 Mbps   全片折算 ≈15 MB / ≈9.4 min 渲染
    星空 · 零位移 · 带 hero   4.02 Mbps   全片折算 ≈52 MB / ≈17 min 渲染
  ⇒ 加了这一层，**成片体积 ×3.5、渲染时长约 ×1.8**。每天的自动化流水线有执行时长上限，
    要不要长期开需要单独决定（默认关闭，只在用户明确要求时加）。

────────────────────────────────────────────────────────────────────────────
这一层是什么 / 为什么必须重建成这个样子
────────────────────────────────────────────────────────────────────────────
源头是工作区那份 TAURUS 动态星空 demo（rAF 实时动画），**不能直接当背景用**：
  performance.now() 渲染时时钟 / 无种子 Math.random() / pointermove 输入态 / 无限 rAF
  —— 违反 hyperframes 的确定性契约；渲染器逐帧 seek、没有 playback，rAF 拿的是墙钟，
    同一 --at 抓两次不会字节一致，QA 直接判不可复现。
本脚本的重建映射（每一处都是为了「同一时刻永远画出同一帧」）：

  ① 星空位置/颜色/相位 = mulberry32 固定种子在**生成期**算好，烤进内联样式 → 运行期零随机
  ② 闪烁 = 逐星 GSAP tween（yoyo + 有限 repeat，floor 防 overshoot），immediateRender:false
     ⚠ repeat 必须有限次：`repeat: -1` 是正则禁词之一（本脚本末尾有反向断言）
  ③ 漫游 = **默认取消**（2026-09-30 用户定）。实测归因（2 秒短渲染 ×4 变体）：
       位移量化到整数像素 → 5.83 Mbps；背景静止只留星闪 → 5.13 Mbps；
       星不闪、只留亚像素位移 → 9.21 Mbps。
     ⇒ 唯一的大头是**亚像素平移/缩放的重采样噪声**，它逐帧扰动整屏像素，编码器无法复用宏块。
     保留 `--parallax` 可开回来对比。
  ④ 鼠标视差**删除**（渲染器没有输入事件）
  ⑤ `#bg-blur` 原本的 `filter: blur(40px)` 用 Pillow 预烘成 1/4 分辨率小图 → 运行期零滤镜
  ⑥ 星点光晕一律走**精灵图**（Pillow 生成），**一处 radial-gradient 都没有** ——
     hyperframes lint 的 `composition_heavy_overlay_count_high` 明确记录：一屏 ~40 个
     radial-gradient / filter:blur / clip-path 元素就会让**前半段成片抓成纯黑**（真出过黑帧）。
  ⑦ **只有 ~40 颗星是「活的」DOM，其余 300+ 颗全部烘焙进一张星图 PNG** ——
     实测同屏同时动画的小元素有量级悬崖：169 条 opacity tween → `snapshot` 直接
     「Navigation timeout of 10000 ms exceeded」；108 / 61 条正常；329 条必挂。
     烘焙掉的星点密度与观感不变，只是不闪烁。
  ⑧ `#scrim`（深色遮罩）+ 可读性微调（副行颜色/字号 + 卡底加深）——
     卡片原本是按**纯色深底**设计的（alpha 白 5.5~8.5% + 灰字），底下换成金色牛 + 星云
     之后必须补这一层，否则卡边界和副行直接糊掉。
  ⑨ **hero 主星**（用户定：「活星对比度不够明显，挑 1~2 颗变大 + 更亮更璀璨」，
     同日二次定版：**金黄色 + 光芒更长 + 光晕更小**，参考一张真实衍射星芒照片）：
     · 结构 = 三层：`.h-aura` 小柔光（紧扣核心，无外环）／`.h-rays` 4 长 + 4 短星芒（细、长、穿透式）／
       `.h-core` 近白热核。三张**静态精灵图**，运行期零渐变、零滤镜代价。
     · **配色 = 金黄**：热核 `#FFF8EA`（近白，避免整颗糊成黄块）→ 星芒 `#FFBA3C` → 柔光外缘 `#FF9E1C`。
     · **"穿透力"的做法**（关键，不是调亮度）：芒的横向剖面 = **极细亮线**（半宽 ~2.4px，权重 1.0）
       + **稍宽柔晕**（半宽 ~4.7px，权重 0.34）两层同轴叠加。
       只留宽的那层 → 发粗像光柱；只留细的那层 → 抗锯齿后断成虚点。
       沿芒衰减 `(1-ua/ln)^1.55`（指数 <2 是有意的，让尾部拖得更远）。
     · **整层 `#heroes` 放在 `#scrim` 之后**（DOM 顺序在后 → 渲染在遮罩之上）。
       这是"对比度不够"的真正原因：普通活星被 0.60 遮罩压掉 40% 亮度，差分峰值只有 ~45/255；
       hero 层不受遮罩影响，全亮度呈现。
     · 动画 = 三层不同周期的**舒缓**呼吸（aura 5.60s / rays 3.60s / core 2.28s），
       rays 另加 ±7° 缓慢旋动 → "璀璨"。三层各自的相位也错开（0 / 1.29 / 0.71s），
       否则会退化成"整体一起放大缩小"的机械感。全部有限次 + immediateRender:false，
       **CSS 静态值精确对齐 tween 起始值**（opacity / scale / rotate 三样）→ t≥0 零跳变。
     · ⚠ 大尺寸精灵图做 transform 动画**必须写 `will-change: transform`**，否则 snapshot 必超时
       （见 css_block 里 `.sth > b` 上方那段注释；`border-radius` 无害，`will-change` 才是关键项）。
     · 两颗 hero 之间再给 2.58s 相位错开，避免同步呼吸（同步会立刻显得像 UI 动效）。
     · 位置见 HERO_STARS（归一化坐标，落在热力图判定的空区里）。
     ⚠ **长芒会出框**：`h-rays` 峰值半芒 ≈ 191px，主星②在 x=157px → 左向芒被画面左边缘切掉 ~34px；
       主星①在 x=974px → 右向芒切掉 ~85px。当前版本用户已确认可接受（读起来像"星在画面外"），
       若某期不接受，改 HERO_STARS 的 x / k 即可（见该常量上方注释）。

活的星放在哪（用户定）：**只放信息卡片出现少的区域**，别闪到字上。
  依据 = 上一期成片的**内容占空热力图**（`scripts/bg_zones_heat.py` 算：ffmpeg 抽帧 →
  局部对比度 → 16px 盒滤波 → 31px 膨胀 → 逐区统计"有内容像素占比"）。
  LIVE_ZONES 的实测值标在常量行末；**换版式后要重跑 bg_zones_heat.py 复测**。
  ✅ **A股 / 美股两套版式共用同一份 LIVE_ZONES，已双市场复测**（2026-09-30）：
       A股 = `market-20260929/out-0929.mp4` 110 帧；美股 = `market-us-20260929/out-us-0929.mp4` 106 帧。
       6 个区在两份热力图上都 ≤3.8%，其中 5 个是 0.0% —— 两版式的骨架一致（标题左上、
       卡片居中、底部通栏留白），所以不需要按市场分预设。
  ⚠ 第一版把右竖带起点放在 x=0.56，抽帧差分一看有几颗就闪在卡片里面（那片占空 4.6%，不是"空"）
     —— 凭感觉画矩形必翻车，必须量。
  ⚠ 右上区（②）也是量出来的：最早的矩形 y 0.120~0.205 在 A股 12.8% / 美股 18.6% 有内容
     （卡片顶边在 y≈0.188 就开始了）→ 收紧到 y 0.095~0.170 后两市场都是 **0.0%**。
     教训：区的上边界压住标题、下边界必须压在 "卡片顶边 - 安全距" 之上，别凭肉眼。
  ⚠ **hero 位置也照同一张热力图定**（±40px 核心框：A股 1.4% / 美股 0.0%；±90px 含长芒后
     A股 15.7%，但长芒是细线、又画在遮罩之上，压到卡片上只是一道很淡的光丝，可接受）。

调参入口：改本文件常量后重跑本脚本（Studio 会热重载 index.html）。
"""

import argparse
import math
import os
import re
import shutil
import sys

from PIL import Image, ImageEnhance, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)                       # scripts/ 的上一级 = skill 根
DEFAULT_PLATE = os.path.join(SKILL, "assets", "bg", "taurus.png")

W, H = 1080, 1920  # 画布尺寸（= root data-width/height，硬编码前有断言校验）

# 运行期由 main() 从命令行填入（模块级保持默认值，方便被 bg_zones_heat.py import 复用）
PROJ = "."
ASSETS = ""        # = <PROJ>/assets，main() 里填
SCRIM = 0.60
CARD_BACK = 0.45
SEED = 20260930
STAR_DIV = 6500    # 环境星密度 = W*H/STAR_DIV（原 demo: Math.floor(W*H/6500)）
BIG_RATE = 0.047   # 环境星里大星比例
EXTRA_BRIGHT = 10
LIVE_STARS = 40    # 真实闪烁的星数（>60 会让 snapshot 超时）
LIVE_BIG_RATE = 0.45   # 活的星里带十字芒的大星比例
SUB_COLOR = "#c8d2e0"  # 灰色副行新色（原 #8a94a6）

PARALLAX = False   # 背景位移开关（2026-09-30 默认关 —— 见文件头 ③：亚像素位移是码率 ×4 的唯一根因）
BAKE_PAD = 0       # 烘焙星图四周余量（只在有位移时才需要，防边缘露空）
NO_STARS = False
NO_TWINKLE = False
NO_HERO = False
SNAP_PX = False
PLATE = DEFAULT_PLATE

# --- hero 主星（2026-09-30：从内容空区里挑 1~2 颗，放大 + 全亮度 + 复合呼吸）---
# x, y = 归一化坐标（落在热力图判定为空区处）；k = 尺寸倍率；phase = 起始相位（秒）
# ⚠ 两颗的 phase 必须错开 —— 同步呼吸会立刻显得像 UI 动效而不是星空。
HERO_STARS = (
    dict(x=0.902, y=0.255, k=1.00, phase=0.00),   # ① 右竖带上部（全片最空：占空 3.8%）
    dict(x=0.145, y=0.888, k=0.88, phase=2.58),   # ② 左下通栏（占空 0.0%，与①成对角）
)
# 每一层 = (类名, 呼吸周期s, opacity起, opacity止, scale起, scale止, 旋转起deg, 旋转止deg, 层相位s)
# ⚠ 最后一列的「层相位」让三层**不同步** —— 同相位会变成"整体一起放大缩小"的机械感，
#   错开后观感才像真实恒星那种不规则的明灭。幅度也刻意做足（aura 0.72→1.16 直径差 ~61%）。
#
# ⚠ 周期（2026-09-30 用户：「hero 星闪动的频率太快了，希望闪动频率是舒缓的」）
#   旧值 1.35 / 0.92 / 0.46s —— core 0.46s = 每秒闪 2.2 次，那是"闪"不是"呼吸"（视觉上像 UI 动效）。
#   新值整体放慢 ~4.2 倍，三层保持原有"外慢内快"的层级关系：
#       aura 1.35→5.60（×4.15） / rays 0.92→3.60（×3.91） / core 0.46→2.28（×4.96）
#   ⚠ 三个周期**刻意取不可通约的值**：以 0.01s 为单位的 LCM = 957.6s，远长于全片 190s
#     → 三层永远不会重新对齐，不会出现"每隔十几秒整体一起亮一次"的机械节拍。
#     （若取 5.4/3.6/2.4 这类整数倍关系，LCM 只有 10.8s，那个节拍肉眼能看出来。）
#   ⚠ 层相位与 hero② 相位同步 ×4.15 缩放，保持原有错开比例，否则慢下来后相位差被稀释、三层又同步了。
#   ⚠ 只改周期，**幅度一律未动**；若觉得慢下来后摆幅反而显得"沉"，再单独调 opacity/scale 区间。
HERO_LAYERS = (
    ("h-aura", 5.60, 0.30, 0.88, 0.78, 1.12,  0.0,  0.0, 0.00),   # 小柔光：幅度最大、最慢
    ("h-rays", 3.60, 0.52, 1.00, 0.62, 1.06, -7.0,  7.0, 1.29),   # 星芒：叠加缓慢旋动
    ("h-core", 2.28, 0.62, 1.00, 0.94, 1.08,  0.0,  0.0, 0.71),   # 热核：三层里最快，但仍慢于旧版
)
# ⚠ 尺寸是量出来的，不是拍脑袋：
#   aura 曾用 192px、峰值 scale 1.22 → 柔光团直径 234px，在 1080 宽的画面上变成"一团白光"
#   而不是一颗星。160px 仍偏大 → 本次按用户要求再收到 116px（**光晕变小**）。
#   rays 从 168 → 360：**光芒更长**。芒长（CSS px）= 精灵图半宽 × scale，
#   即 180 × 1.06 ≈ 191px —— 是柔光半径（58×1.12≈65px）的 ~2.9 倍，
#   "核心 → 小柔光 → 长芒伸出光晕之外"的层次才立得住。
#   ⚠ 精灵图变大后**横向半宽必须同比收窄**，否则芒会跟着变粗（见 _hero_rays 里的注释）。
HERO_AURA_S = 108   # 精灵图边长（px）；aura 108 / rays 360 / core 52
HERO_RAYS_S = 360
HERO_CORE_S = 52

# --- hero 配色（2026-09-30 用户定：「颜色用金黄色」）---
HERO_HOT = (255, 248, 234)   # 热核：近白，只带一点暖 —— 全黄会糊成一坨没有"灼点"
HERO_GOLD = (255, 186, 60)   # 金黄主色（星芒）
HERO_GOLD_DEEP = (255, 158, 28)  # 柔光外缘：更深更暖，制造"光晕衰减"的颜色层次

# 活的星只落在这些矩形里（x0, x1, y0, y1 为 0~1 归一化，最后一位是抽样权重）
# 依据 = 上一期成片的内容占空热力图（先按 31px 膨胀，把「偶尔有内容」也算占用）。
# 行末 = 「有内容像素占比」，**A股 / 美股 两份热力图都测过**（2026-09-30）。
# ⚠ 中段 y 0.20~0.80 之间**不存在干净的水平带**（每一行 x 0.08~0.72 都被卡片占着），
#   所以「中部靠上/靠下」只能落在左右两条竖带上，这跟肉眼观感一致。
LIVE_ZONES = (
    (0.030, 0.970, 0.008, 0.070, 1.0),   # ① 顶部通栏      0.0% / 0.0%
    (0.440, 0.800, 0.095, 0.170, 1.3),   # ② 右上（标题右侧、进度点下方） 0.0% / 0.0%
    (0.860, 0.975, 0.100, 0.800, 1.8),   # ③ 右竖带（贯穿中部，全片最空） 3.8% / 3.3%
    (0.008, 0.052, 0.180, 0.800, 0.9),   # ④ 左窄条        0.0% / 0.0%
    (0.630, 0.860, 0.690, 0.812, 0.8),   # ⑤ 右下空档      0.0% / 1.2%
    (0.030, 0.970, 0.818, 0.985, 1.3),   # ⑥ 下方通栏      0.0% / 0.0%
)

# 原 demo 的四档星色
COLS = ((255, 248, 232), (255, 217, 138), (207, 224, 255), (255, 180, 106))
SPR = 64           # 精灵图边长（px）
CORE_COL = (255, 253, 245)
FLARE_COL = (255, 245, 220)
FLARE_HALF = 0.7   # 十字芒半宽（CSS px）
# |sin| 的均值 = 2/π —— 烘焙层用「平均亮度」，与活的闪烁星观感一致
SIN_MEAN = 2.0 / math.pi

SMALL_RATIO = 6.0   # 小星元素边长 = 6r（光晕延伸到 3r）
BIG_RATIO = 14.0    # 大星元素边长 = 14r（光晕 7r + 十字芒）


# ------------------------------------------------------------------ 确定性 PRNG
def mulberry32(seed):
    """与原 demo 的 Math.random 无关：固定种子 → 每次生成完全相同的星空。"""
    s = seed & 0xFFFFFFFF

    def nxt():
        nonlocal s
        s = (s + 0x6D2B79F5) & 0xFFFFFFFF
        t = s
        t = ((t ^ (t >> 15)) * (t | 1)) & 0xFFFFFFFF
        t = (t + (((t ^ (t >> 7)) * (t | 61)) & 0xFFFFFFFF)) & 0xFFFFFFFF
        return ((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296.0

    return nxt


def pick_col(v):
    if v < 0.55:
        return COLS[0]
    if v < 0.75:
        return COLS[1]
    if v < 0.90:
        return COLS[2]
    return COLS[3]


def _star_at(rnd, x, y, big):
    return dict(
        x=x, y=y,
        r=(1.6 + rnd() * 1.8) if big else (0.3 + rnd() * 1.1),
        p=rnd() * 2 * math.pi,      # 相位
        w=0.6 + rnd() * 2.2,        # 角频率 rad/s；|sin| 周期 = π/ω
        big=big,
        col=pick_col(rnd()),
    )


def build_stars(rnd):
    """环境星：全画布均匀铺（原 demo 的分布：小星 r=0.3~1.4 · 大星 r=1.6~3.4）。"""
    stars = []
    n = int(W * H / STAR_DIV)
    for _ in range(n):
        stars.append(_star_at(rnd, rnd() * W, rnd() * H, rnd() < BIG_RATE))
    # 原 demo 额外 10 颗落在上半屏的固定亮星（青色）
    for _ in range(EXTRA_BRIGHT):
        stars.append(_star_at(rnd, rnd() * W, rnd() * H * 0.45, True))
        stars[-1]["col"] = COLS[2]
    return stars


def build_live_stars(rnd, n):
    """闪烁星：**只落在 LIVE_ZONES 里**（全片内容占空 ≤0.02 的空区）。

    抽样方式 = 按权重选矩形 → 矩形内均匀取点。权重正比于「该区域的空隙面积 ×
    想让观众在那里看到闪烁的意愿」，不按面积自动分配，因为右侧竖带虽然窄但最空。
    """
    wts = [z[4] for z in LIVE_ZONES]
    tot = sum(wts)
    out = []
    for _ in range(n):
        r = rnd() * tot
        for z in LIVE_ZONES:
            if r < z[4]:
                x0, x1, y0, y1 = z[0], z[1], z[2], z[3]
                break
            r -= z[4]
        else:  # 浮点兜底
            x0, x1, y0, y1 = LIVE_ZONES[-1][:4]
        out.append(_star_at(rnd, (x0 + rnd() * (x1 - x0)) * W,
                            (y0 + rnd() * (y1 - y0)) * H, rnd() < LIVE_BIG_RATE))
    return out


def star_sample(dx, dy, r, tint, big):
    """星点取样函数（**只看 CSS 尺度的相对距离**，精灵图与烘焙图共用同一套数学）。

    dx, dy = 相对星心的 CSS px。返回 (rgb, alpha) 或 None（完全透明）。
      · 核心半径 = r（实心、近白）
      · 光晕延伸到 3r（小星）/ 7r（大星），alpha 以 (1-t)^1.15 衰减
      · 大星另加十字芒：臂长 = 光晕半径，半宽 FLARE_HALF px
    """
    d = math.hypot(dx, dy)
    halo = r * (7.0 if big else 3.0)
    if d >= halo:
        return None
    if d <= r:
        t, a = 0.0, 1.0
    else:
        t = (d - r) / (halo - r)
        a = (1.0 - t) ** 1.15
    w = min(1.0, t / 0.30)                     # 核心偏白 → 外圈染成该档星色
    col = [CORE_COL[i] * (1 - w) + tint[i] * w for i in range(3)]
    if big:
        fy = max(0.0, 1.0 - abs(dy) / FLARE_HALF) * max(0.0, 1.0 - (abs(dx) / halo) ** 1.5)
        fx = max(0.0, 1.0 - abs(dx) / FLARE_HALF) * max(0.0, 1.0 - (abs(dy) / halo) ** 1.5)
        f = max(fx, fy)
        if f > 0.0:
            a = min(1.0, a + f)
            w2 = min(1.0, f)
            col = [col[i] * (1 - w2) + FLARE_COL[i] * w2 for i in range(3)]
    return tuple(int(round(c)) for c in col), a


def element_size(st):
    return st["r"] * (BIG_RATIO if st["big"] else SMALL_RATIO)


def base_opacity(st, mean=False):
    """原 demo: opacity = |sin| 的发光系数 × (big?1:.85)，区间 [0.45k, 1.0k]。
    mean=True 时取 |sin| 的均值（烘焙层用），False 取谷值即 tween 的起始值。"""
    k = 1.0 if st["big"] else 0.85
    f = SIN_MEAN if mean else 0.0
    return (0.45 + 0.55 * f) * k


def twinkle_plan(st, total):
    """把 opacity = k*(.45+.55*|sin(ωt+p)|) 翻译成一条可 seek 的 yoyo tween。

    返回 (lo, hi, half, repeat, start)：
      · cycle = π/ω（|sin| 的周期）· half = cycle/2（一次 lo→hi）
      · start = 相位对齐到 |sin|=0 的时刻，落在 [0, cycle)
      · repeat = floor(2*(total-start)/cycle) - 1 → half*(repeat+1) ≤ total-start，**绝不越出总时长**
      · 元素的 CSS opacity 直接写成 lo → tween 开始前停在 lo，进出场**零跳变**
    """
    lo, hi = base_opacity(st), 1.00 * (1.0 if st["big"] else 0.85)
    cycle = math.pi / st["w"]
    start = ((math.pi - st["p"]) % math.pi) / st["w"]
    repeat = max(0, int(math.floor(2 * (total - start) / cycle)) - 1)
    return lo, hi, cycle / 2.0, repeat, start


def star_html(st):
    ci = COLS.index(st["col"])
    cls = "st" + (" c%d" % ci if ci else "")
    if st["big"]:
        cls += " big"
    return ('<i class="%s" style="left:%.1fpx;top:%.1fpx;--s:%.2fpx;opacity:%.3f"></i>'
            % (cls, st["x"], st["y"], element_size(st), base_opacity(st)))


# ------------------------------------------------------------------ ① 烘焙 #bg-blur 底图
def bake_plate():
    """把 #bg-blur 那段 CSS 滤镜（cover/35% + blur40 + brightness.55 + saturate1.2）
    一次性烘成一张 1/4 分辨率 jpg。视觉等价，但渲染时**零 filter 代价**。

    #bg-blur 的盒 = inset:-5% of 1080x1920 = 1188x2112 → 1/4 = 297x528，模糊半径 40/4 = 10。

    顺便把 `#bg-sharp` 用的那张大图落盘成 **`assets/bg-plate.png`**（**无损，且一定转成 PNG**）。

    ⚠⚠ **底板必须是 PNG，不能用 JPEG**（2026-09-30 实测，这是本轮最反直觉的一条）：
       同一工程、同一 `--at` 连抓两次，用 JPEG 底板时**帧字节不一致**（max diff 10/255、
       差异遍布全屏、偏蓝通道），而且稳定地在两个状态间**交替**（A/B/A/B，共 5 次复现）；
       换回 PNG 底板后同一时刻连抓两次**字节完全一致**（2.8/60s 与 5.0/90s 各两轮，4/4 稳）。
       差异不是动画状态错位，而是**大尺寸 JPEG 在硬件光栅化路径下的解码/重采样抖动**。
       ⇒ 所以这里**无条件转成 PNG**（输入即使是 JPEG 也要转）：在生成期解码一次，
         运行期就只剩无损解码，抖动源被彻底摘掉。代价是文件从 ~0.7 MB 涨到 ~3.0 MB，
         但这一层的全部意义就是"同一时刻永远画出同一帧"，不能用体积换。
       ⚠ `bg-blur.jpg`（297x528、重度模糊）保持 JPEG 是安全的：实测它在场时 PNG 底板
         依然是 4/4 字节一致 —— 尺寸小 + 模糊掉了块效应，解码抖动落到 1/255 量化以下。
    """
    bw, bh = int(W * 1.1), int(H * 1.1)
    src = Image.open(PLATE).convert("RGB")
    sharp = os.path.join(ASSETS, "bg-plate.png")
    if os.path.abspath(PLATE) != os.path.abspath(sharp):
        src.save(sharp, "PNG", optimize=True)
        print("[plate] %s  %dx%d  %.1f KB（源 %s）"
              % (os.path.basename(sharp), src.width, src.height,
                 os.path.getsize(sharp) / 1024, os.path.basename(PLATE)))
    sc = max(bw / src.width, bh / src.height)
    nw, nh = int(round(src.width * sc)), int(round(src.height * sc))
    im = src.resize((nw, nh), Image.LANCZOS)
    ox = int(round((nw - bw) * 0.5))    # background-position-x: center
    oy = int(round((nh - bh) * 0.35))   # background-position-y: 35%
    im = im.crop((ox, oy, ox + bw, oy + bh))
    q = im.resize((bw // 4, bh // 4), Image.LANCZOS)
    q = q.filter(ImageFilter.GaussianBlur(10))          # = blur(40px) / 4
    q = ImageEnhance.Brightness(q).enhance(0.55)        # = brightness(.55)
    q = ImageEnhance.Color(q).enhance(1.2)              # = saturate(1.2)
    dst = os.path.join(ASSETS, "bg-blur.jpg")
    q.save(dst, "JPEG", quality=82)
    print("[plate] %s  %dx%d  %.1f KB" % (os.path.basename(dst), q.width, q.height,
                                          os.path.getsize(dst) / 1024))


# ------------------------------------------------------------------ ② 星点精灵图 / 烘焙星图
def bake_sprites():
    """8 张 64x64 精灵图：4 档星色 × (小星 / 大星带十字芒)。

    形状与 r 无关（核心 r、光晕 3r/7r 都是 r 的倍数），所以一张精灵图适配所有 r；
    只有十字芒的半宽是绝对 px，故 64px 映射到 (ratio*r) CSS px。
    """
    tot = 0
    for i, tint in enumerate(COLS):
        for big in (False, True):
            ratio = BIG_RATIO if big else SMALL_RATIO
            half = SPR / 2.0
            k = ratio / SPR                 # 1 精灵像素 = k 个 CSS px（取 r=1 归一）
            img = Image.new("RGBA", (SPR, SPR), (0, 0, 0, 0))
            px = img.load()
            for y in range(SPR):
                for x in range(SPR):
                    s = star_sample((x + 0.5 - half) * k, (y + 0.5 - half) * k, 1.0, tint, big)
                    if s:
                        px[x, y] = (s[0][0], s[0][1], s[0][2], int(round(255 * s[1])))
            dst = os.path.join(ASSETS, "stb%d.png" % i if big else "st%d.png" % i)
            img.save(dst, "PNG", optimize=True)
            tot += os.path.getsize(dst)
    print("[sprite] 8 张精灵图  合计 %.1f KB" % (tot / 1024))


def bake_stars_png(stars):
    """把「非闪烁」的星点画进一张透明 PNG（比画布大 BAKE_PAD 四周留余量，
    用于吸收 #stars 视差位移，避免边缘露空）。"""
    bw, bh = W + BAKE_PAD * 2, H + BAKE_PAD * 2
    img = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
    px = img.load()
    drawn = 0
    for st in stars:
        op = base_opacity(st, mean=True)
        halo = st["r"] * (7.0 if st["big"] else 3.0)
        cx, cy = st["x"] + BAKE_PAD, st["y"] + BAKE_PAD
        x0, x1 = max(0, int(cx - halo - 1)), min(bw - 1, int(cx + halo + 2))
        y0, y1 = max(0, int(cy - halo - 1)), min(bh - 1, int(cy + halo + 2))
        for y in range(y0, y1):
            for x in range(x0, x1):
                s = star_sample(x + 0.5 - cx, y + 0.5 - cy, st["r"], st["col"], st["big"])
                if s and s[1] > 0.004:
                    px[x, y] = (s[0][0], s[0][1], s[0][2], int(round(255 * s[1] * op)))
                    drawn += 1
    dst = os.path.join(ASSETS, "stars-baked.png")
    img.save(dst, "PNG", optimize=True)
    print("[stars-png] %s  %dx%d  非透明像素 %d   %.1f KB"
          % (os.path.basename(dst), bw, bh, drawn, os.path.getsize(dst) / 1024))


# ------------------------------------------------------------------ ②b hero 主星精灵图
def _hero_aura(u):
    """小柔光（2026-09-30 二次定版：**光晕变小**）。

    u = 归一化半径 0~1（1 = 图的边缘）。只有「紧核 + 一层中层柔光」两个分量，
    **原来那圈 u≈0.74 的外环已删除** —— 它在峰值 scale 下会变成一圈很规则的灯笼光，
    是"光晕太大"的主要视觉来源。现在亮度在 u≈0.62 就衰减到 0.5%，
    柔光半径 ≈ 108/2 × 0.62 ≈ 33px（峰值 scale 1.12 时 ~37px），
    只有星芒长度（~176px）的 1/5 → 长芒能明确地"穿出"光晕。
    """
    a = (0.82 * math.exp(-((u / 0.13) ** 1.9))        # 紧核
         + 0.21 * math.exp(-((u / 0.31) ** 2.3)))     # 中层柔光（唯一的外扩分量）
    return min(1.0, a)


def _hero_rays(dx, dy):
    """金黄色星芒：4 长芒（水平/垂直，触边）+ 4 短芒（斜 45°，46% 长）→ "穿透力"。

    ⚠ 横向剖面刻意做成**两层同轴叠加**，这是本次唯一真正的技术点：
         thin = 半宽 ~2.4px 的极细亮线（权重 1.00）
         soft = 半宽 ~4.7px 的稍宽容晕（权重 0.34）
       只留 thin → 抗锯齿后细线会断成虚点；只留 soft → 变成一根发粗的光柱。
       两层叠起来才是真实衍射星芒那种"细、不断、越近中心越灼"的观感。
    ⚠ 半宽是**归一化值**（乘精灵图半宽才是 CSS px）。精灵图曾从 168 放大到 360，
       所以这两个系数必须同比收窄，否则芒会跟着变粗 2.1 倍（这是最容易白干一轮的点）。
    沿芒衰减 (1 - ua/ln)^1.55：指数 <2 是有意的，让尾部拖得更远 = "光芒更长"。
    dx, dy = 归一化到 [-1, 1] 的图内坐标。
    """
    d = math.hypot(dx, dy)
    a = 0.97 * math.exp(-((d / 0.030) ** 1.7))       # 中心爆点：小、极亮
    for k in range(8):
        th = k * math.pi / 4.0
        lng = (k % 2 == 0)                            # 偶数索引用 0/90/180/270 四个长芒
        ln = 1.0 if lng else 0.46
        ua = dx * math.cos(th) + dy * math.sin(th)     # 沿芒方向
        vp = -dx * math.sin(th) + dy * math.cos(th)    # 垂直芒方向
        if ua <= 0.0 or ua >= ln:
            continue
        along = (1.0 - ua / ln) ** 1.55
        thin = max(0.0, 1.0 - abs(vp) / (0.0135 if lng else 0.0110))
        soft = max(0.0, 1.0 - abs(vp) / (0.0260 if lng else 0.0190))
        aa = along * (1.00 * thin ** 0.80 + 0.34 * soft ** 1.40)
        if aa > a:
            a = aa
    return min(1.0, a)


def _write_sprite(name, size, fn, c0, c1, wnorm):
    """通用出图：fn 返回 (alpha, 色偏权重 w)；c0 为核色、c1 为外围色。"""
    half = size / 2.0
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    px = img.load()
    for y in range(size):
        for x in range(size):
            a, w = fn(x + 0.5 - half, y + 0.5 - half, half)
            if a < 0.004:
                continue
            w = min(1.0, max(0.0, w / wnorm))
            c = tuple(c0[i] * (1 - w) + c1[i] * w for i in range(3))
            px[x, y] = (int(round(c[0])), int(round(c[1])), int(round(c[2])),
                        int(round(255 * min(1.0, a))))
    p = os.path.join(ASSETS, name)
    img.save(p, "PNG", optimize=True)
    return os.path.getsize(p)


def bake_hero_sprites():
    """三张 hero 精灵图（**全静态位图** → 运行期零渐变、零滤镜，不触发 lint 的重叠层警告）。

    配色（2026-09-30 用户定「金黄色」）统一走 `_write_sprite` 的核色→外围色插值：
      · aura：热核 #FFF8EA → 外缘 #FFA828（更深更暖，制造"光晕衰减"的颜色层次）
      · rays：热核 #FFF8EA → #FFC24A（金黄主色）—— 芒的根部近白、梢部金黄，
              这正是真实照片里亮星的样子（全黄会失去"灼点"）
      · core：纯热核色
    """
    tot = 0
    tot += _write_sprite(
        "hero-aura.png", HERO_AURA_S,
        lambda dx, dy, hp: (_hero_aura(math.hypot(dx, dy) / hp),
                            math.hypot(dx, dy) / hp),
        HERO_HOT, HERO_GOLD_DEEP, 0.42)
    tot += _write_sprite(
        "hero-rays.png", HERO_RAYS_S,
        lambda dx, dy, hp: (_hero_rays(dx / hp, dy / hp),
                            max(0.0, math.hypot(dx, dy) / hp - 0.035)),
        HERO_HOT, HERO_GOLD, 0.30)
    tot += _write_sprite(
        "hero-core.png", HERO_CORE_S,
        lambda dx, dy, hp: (math.exp(-((math.hypot(dx, dy) / hp / 0.34) ** 1.7)), 0.0),
        HERO_HOT, HERO_HOT, 1.0)
    print("[hero-sprite] 3 张（aura %d / rays %d / core %d）  合计 %.1f KB"
          % (HERO_AURA_S, HERO_RAYS_S, HERO_CORE_S, tot / 1024))


# ------------------------------------------------------------------ CSS
def css_block():
    # ⚠ 不能直接 % SCRIM：CSS 里有大量 `100%` / `-5%` 会被当成格式符
    la, lr, lc = HERO_LAYERS      # 三层的参数，避免在 CSS 里再写死一份（顺序 = aura/rays/core）
    return ("""      /* ================= 星空背景层（可 seek 重建 · 2026-09-30 demo） =================
         ⚠ 全部是新 id / 新类（#hfbg #bg-blur #bg-sharp #stars #stars-baked #vignette #scrim .st），
           一个公共类都没碰 —— 不影响其它场次，也不改 skill。
         层序：基座 .clip 是 position:absolute 且 z-index:auto（不建栈上下文），
               内部 .glow{z-index:1} / .content,.sec-title{z-index:2}
               → #hfbg 给 z-index:0 就天然落在「内容之下、辉光之上」，无需改任何共享类。
         ⚠ 星点光晕一律走精灵图，**一处 radial-gradient 都没有** ——
           hyperframes lint 记录的截图层 bug：同屏 ~40 个 radial-gradient 会前半段抓成纯黑。 */
      #hfbg { position: absolute; inset: 0; z-index: 0; overflow: hidden; background: #040614; }
      #bg-blur {
        position: absolute; inset: -5%;
        background: url("assets/bg-blur.jpg") center 35% / cover no-repeat;
        transform: scale(1.1);
      }
      #bg-sharp {
        position: absolute; inset: 0;
        background: url("assets/bg-plate.png") center 30% / contain no-repeat;
      }
      /* 星图层：烘焙星图（密度）+ 少量活的闪烁星（只落在内容空区，见 LIVE_ZONES） */
      #stars { position: absolute; inset: 0; }
      #stars-baked {
        position: absolute; left: -@PAD@px; top: -@PAD@px;
        width: @BW@px; height: @BH@px;
        background: url("assets/stars-baked.png") 0 0 / 100% 100% no-repeat;
      }
      .st {
        position: absolute; border-radius: 50%;
        width: var(--s); height: var(--s);
        margin: calc(var(--s) * -0.5) 0 0 calc(var(--s) * -0.5);
        background: url("assets/st0.png") center / 100% 100% no-repeat;
      }
      .st.c1 { background-image: url("assets/st1.png"); }
      .st.c2 { background-image: url("assets/st2.png"); }
      .st.c3 { background-image: url("assets/st3.png"); }
      .st.big { background-image: url("assets/stb0.png"); }
      .st.big.c1 { background-image: url("assets/stb1.png"); }
      .st.big.c2 { background-image: url("assets/stb2.png"); }
      .st.big.c3 { background-image: url("assets/stb3.png"); }
      #vignette {
        position: absolute; inset: 0; pointer-events: none;
        background:
          radial-gradient(120% 90% at 50% 40%, transparent 55%, rgba(0,0,10,.55) 100%),
          linear-gradient(to bottom, rgba(0,0,10,.45), transparent 22%, transparent 78%, rgba(0,0,10,.5));
      }
      /* 可读性遮罩：卡片是 alpha 白 5.5~8.5% + 灰副字，本来是照纯色深底设计的。
         金色公牛 + 星空压上去必须补这一层，否则卡边界直接消失。见 build_demo.py 的 SCRIM。 */
      #scrim { position: absolute; inset: 0; pointer-events: none; background: rgba(4, 6, 20, @SCRIM@); }

      /* ================= hero 主星（写在 #scrim **之后** → 渲染在遮罩之上 = 全亮度） =================
         ⚠ 层序就是 DOM 顺序：这一层放在 #scrim 后面，所以不被 0.60 遮罩压暗。
           普通活星透过遮罩后差分峰值只有 ~45/255 —— 这就是"对比度不够明显"的根因。
         ⚠ 三层全用静态精灵图（零 radial-gradient / 零 filter）→ 不触发 lint 的
           `composition_heavy_overlay_count_high`（那个警告对应过"前半段成片抓成纯黑"的真 bug）。
         ⚠ 每个层的 CSS 静态值必须**精确等于 tween 起始值**（opacity / scale / rotate 三样）：
           tween 带 immediateRender:false → t≥0 的第一帧直接用 CSS 值，对不齐会看见一次跳变。 */
      #heroes { position: absolute; inset: 0; pointer-events: none; }
      .sth { position: absolute; width: 0; height: 0; transform: scale(var(--k, 1)); }
      .sth > b {
        position: absolute; display: block; left: 0; top: 0;
        border-radius: 50%; pointer-events: none;
        background-position: center; background-repeat: no-repeat; background-size: 100% 100%;
        transform-origin: 50% 50%; will-change: transform, opacity;
      }
      /* ⚠⚠ 让 176~192px 的精灵图层做 transform 动画（scale / rotate）**必须有 will-change: transform**。
         缺了它，浏览器每帧重新光栅化整个层 → 实测（2026-09-30）6 条 tween 就能让 snapshot
         直接「Navigation timeout of 10000 ms exceeded」；而**同一批元素静态不动完全正常**
         （二分：NO_HERO=1 ✅ / NO_TWINKLE=1 ✅ / 带 hero tween ✗）。
         单变量复核：把 border-radius: 50% 加回来仍然 ✅ → 关键项只有 will-change，
         圆角本身无害（精灵图已是圆形 alpha，留着是为了将来换非圆图时裁剪边界明确）。
         对照：40 条只动 opacity 的小星 tween 一直正常 —— 差别在「动的是 transform 还是 opacity」。 */
      .sth .h-aura {
        width: @AUS@px; height: @AUS@px; margin: -@AUH@px 0 0 -@AUH@px;
        background-image: url("assets/hero-aura.png");
        opacity: @ALO@; transform: scale(@AS0@);
      }
      .sth .h-rays {
        width: @RYS@px; height: @RYS@px; margin: -@RYH@px 0 0 -@RYH@px;
        background-image: url("assets/hero-rays.png");
        opacity: @RLO@; transform: scale(@RS0@) rotate(@RR0@deg);
      }
      .sth .h-core {
        width: @COS@px; height: @COS@px; margin: -@COH@px 0 0 -@COH@px;
        background-image: url("assets/hero-core.png");
        opacity: @CLO@; transform: scale(@CS0@);
      }

      /* ================= 可读性微调（2026-09-30） =================
         ⚠ 全部用 `body.hfbg` 前缀作用域 —— 只在带背景的成片里生效，
           一条 <body class="hfbg"> 即可整体开关，将来并进 skill 时也不污染无背景场次。
         ⚠ 字号不是随手加的：`_wrapall.mjs` 实测 .pcs@27px 已占满可用宽 —— 全片最长那条
           「缩量 2,936 亿 · 14 个月新低」= 337/358px（余量 1.062）。
           试到 28px 时余量只剩 1.025（差 8.6px 就折行）→ **实测后回退，.pcs 字号保持 27px**。
           真正把可读性拉回来的是：
             ① 副行颜色 #8a94a6 → @SUB@（相对亮度约 ×2.3，这是最大的一项）
             ② 卡底加深（rgba(6,10,22,@CARD@)）—— 副行坐在均匀深底上，而不是星云上
           有空间的那几个（.idx-name 余量 2.59 / .idx-note 2.9 / .page.two .pcs 1.74）就正常放大。
         .pc-hero .hu 本期没用，一并改掉是为了将来复用不再踩同一个坑。 */
      body.hfbg .pchip .pcs   { color: @SUB@; }
      body.hfbg .page.two .pcard .pchip .pcs { font-size: 27px; color: @SUB@; }
      body.hfbg .pc-hero .hu  { font-size: 36px; color: @SUB@; }
      body.hfbg .pcard.mini .idx-name { font-size: 38px; color: @SUB@; }
      body.hfbg .page.ow3 .pcard.mini .idx-name { font-size: 47px; }
      body.hfbg .pcard.mini .idx-note { font-size: 29px; color: @SUB@; }
      body.hfbg .pcard.mini .idx-val.closed { color: @SUB@; }
      body.hfbg .pcard {
        background: linear-gradient(158deg, rgba(255,255,255,0.085) 0%, rgba(255,255,255,0.030) 100%),
                    rgba(6, 10, 22, @CARD@);
      }
""").replace("@PAD@", str(BAKE_PAD)).replace("@BW@", str(W + BAKE_PAD * 2)) \
    .replace("@BH@", str(H + BAKE_PAD * 2)).replace("@SCRIM@", "%.2f" % SCRIM) \
    .replace("@CARD@", "%.2f" % CARD_BACK).replace("@SUB@", SUB_COLOR) \
    .replace("@AUS@", str(HERO_AURA_S)).replace("@AUH@", str(HERO_AURA_S // 2)) \
    .replace("@ALO@", "%.2f" % la[2]).replace("@AS0@", "%.2f" % la[4]) \
    .replace("@RYS@", str(HERO_RAYS_S)).replace("@RYH@", str(HERO_RAYS_S // 2)) \
    .replace("@RLO@", "%.2f" % lr[2]).replace("@RS0@", "%.2f" % lr[4]) \
    .replace("@RR0@", "%.1f" % lr[6]) \
    .replace("@COS@", str(HERO_CORE_S)).replace("@COH@", str(HERO_CORE_S // 2)) \
    .replace("@CLO@", "%.2f" % lc[2]).replace("@CS0@", "%.2f" % lc[4])


def bg_stage_html(live_stars, heroes):
    rows = "\n".join("          " + star_html(s) for s in live_stars)
    hrows = "\n".join(
        '        <i class="sth" style="left:%.1fpx;top:%.1fpx;--k:%.2f">'
        '<b class="h-aura"></b><b class="h-rays"></b><b class="h-core"></b></i>'
        % (h["x"] * W, h["y"] * H, h["k"]) for h in heroes)
    return """      <!-- ============ 星空背景层（非 clip：无 data-start/duration，整条时间轴常驻） ============ -->
      <div id="hfbg">
        <div id="bg-blur"></div>
        <div id="bg-sharp"></div>
        <div id="stars">
          <div id="stars-baked"></div>
%s
        </div>
        <div id="vignette"></div>
        <div id="scrim"></div>
        <!-- hero 主星：DOM 顺序写在 #scrim 之后 → 渲染在遮罩之上 = 全亮度（见 css_block 注释） -->
        <div id="heroes">
%s
        </div>
      </div>
""" % (rows, hrows)


# ------------------------------------------------------------------ 时间轴
def timeline_block(live_stars, heroes, total):
    tw = [twinkle_plan(s, total) for s in live_stars]
    data = "\n".join(
        "          [%.3f, %.3f, %.3f, %d, %.3f]," % (lo, hi, half, rep, st)
        for (lo, hi, half, rep, st) in tw
    )
    # hero 主星：每条 tween 一段，[hero序号, 层序号, o起, o止, 半周期, repeat, start, s起, s止, r起, r止]
    hd = []
    for hi, h in enumerate(heroes):
        for li, (_cls, cyc, o0, o1, s0, s1, r0, r1, lph) in enumerate(HERO_LAYERS):
            start = round(h["phase"] + lph, 3)      # 层相位错开 → 三层不同步
            # yoyo + repeat=N → 总时长 = (cyc/2)*(N+1)；floor 收敛，绝不越出 total
            rep = max(0, int(math.floor(2.0 * (total - start) / cyc)) - 1)
            hd.append("          [%d, %d, %.2f, %.2f, %.3f, %d, %.3f, %.2f, %.2f, %.1f, %.1f],"
                      % (hi, li, o0, o1, cyc / 2.0, rep, start, s0, s1, r0, r1))
    hdata = "\n".join(hd)
    lg = round(total / 3.0, 2)   # 漫游分 3 段，每段 sine.inOut，首尾相接成不规则路径
    snap = ", snap: { x: 1, y: 1 }" if SNAP_PX else ""   # 整数像素位移 → 去掉重采样噪声
    walk = "" if not PARALLAX else """      // ①② 背景漫游（**默认关闭**，见文件头 ③：位移是码率 ×14 的唯一根因）
        var LG = %(lg)s;
        tl.fromTo("#bg-sharp", { x: -22, y: -30, scale: 1.07 },
          { x: 18, y: 22, scale: 1.10, duration: LG, ease: "sine.inOut", immediateRender: false%(snap)s }, 0);
        tl.to("#bg-sharp", { x: -12, y: -34, scale: 1.08, duration: LG, ease: "sine.inOut"%(snap)s }, LG);
        tl.to("#bg-sharp", { x: 20, y: 18, scale: 1.11, duration: LG, ease: "sine.inOut"%(snap)s }, LG * 2);
        tl.fromTo("#stars", { x: -7, y: -10 },
          { x: 7, y: 10, duration: %(total)s, ease: "sine.inOut", immediateRender: false%(snap)s }, 0);
""" % dict(lg=lg, total=total, snap=snap)
    return """      /* ================= 星空背景 · 可 seek 重建（严格无 rAF / 无随机 / 无输入态） ================= */
      (function () {
%(walk)s        // ③ 逐星闪烁：每项 = [lo, hi, half(半周期), repeat, start]；yoyo 往返，repeat 已按 floor 收敛
        var TW = [
%(data)s
        ];
        var els = document.querySelectorAll("#stars .st");
        for (var i = 0; i < TW.length; i++) {
          var a = TW[i], el = els[i];
          if (!el) continue;
          tl.fromTo(el, { opacity: a[0] },
            { opacity: a[1], duration: a[2], ease: "sine.inOut", yoyo: true, repeat: a[3],
              immediateRender: false }, a[4]);
        }
        // ④ hero 主星：三层不同周期的呼吸（aura 最慢幅度最大 / rays 加缓慢旋动 / core 最快）
        //    [hero序号, 层序号, opacity起, 止, 半周期, repeat, start, scale起, 止, 旋转起, 止]
        var HD = [
%(hdata)s
        ];
        var LAY = ["h-aura", "h-rays", "h-core"];
        var hb = document.querySelectorAll("#heroes .sth");
        for (var j = 0; j < HD.length; j++) {
          var b = HD[j], box = hb[b[0]];
          if (!box) continue;
          var el2 = box.querySelector("." + LAY[b[1]]);
          if (!el2) continue;
          tl.fromTo(el2, { opacity: b[2], scale: b[7], rotation: b[9] },
            { opacity: b[3], scale: b[8], rotation: b[10], duration: b[4],
              ease: "sine.inOut", yoyo: true, repeat: b[5], immediateRender: false }, b[6]);
        }
      })();

""" % dict(walk=walk, data=data, hdata=hdata)


# ------------------------------------------------------------------ 打补丁
def sub_once(text, old, new, tag):
    n = text.count(old)
    assert n == 1, "锚点 [%s] 命中 %d 次（要求恰好 1 次）" % (tag, n)
    return text.replace(old, new)


def die(msg):
    sys.stderr.write("[error] %s\n" % msg)
    sys.exit(1)


def parse_args(argv=None):
    ap = argparse.ArgumentParser(
        description="给已生成的 index.html 追加「可 seek 星空背景层」（必须在 build_cards.py 之后跑）")
    ap.add_argument("--proj", default=".", help="工程目录（默认当前目录）")
    ap.add_argument("--scrim", type=float, default=0.60, help="深色遮罩强度（默认 0.60）")
    ap.add_argument("--card-back", type=float, default=0.45, help="卡底加深量（默认 0.45）")
    ap.add_argument("--plate", default=DEFAULT_PLATE, help="底板图（默认 skill 自带的金色星座牛）")
    ap.add_argument("--seed", type=int, default=20260930, help="星点种子（默认 20260930）")
    ap.add_argument("--live-stars", type=int, default=40, help="真实闪烁的星数（默认 40，上限 60）")
    ap.add_argument("--star-div", type=int, default=6500, help="环境星密度 = W*H/star-div（默认 6500）")
    ap.add_argument("--sub-color", default="#c8d2e0", help="灰色副行新色（默认 #c8d2e0）")
    ap.add_argument("--no-hero", action="store_true", help="不出 hero 主星层")
    ap.add_argument("--no-twinkle", action="store_true", help="活星不闪（排障用）")
    ap.add_argument("--parallax", action="store_true", help="开背景位移（码率 ×4，强烈不建议）")
    return ap.parse_args(argv)


def main(argv=None):
    global PROJ, ASSETS, PLATE, SCRIM, CARD_BACK, SEED, STAR_DIV, LIVE_STARS, SUB_COLOR
    global NO_HERO, NO_TWINKLE, PARALLAX, BAKE_PAD, SNAP_PX
    args = parse_args(argv)

    PROJ = os.path.abspath(args.proj)
    if not os.path.isdir(PROJ):
        die("工程目录不存在：%s" % PROJ)
    ASSETS = os.path.join(PROJ, "assets")
    OS = os.path.join(PROJ, "index.html")
    if not os.path.exists(OS):
        die("找不到 %s —— 本脚本要在 build_cards.py **之后**跑（index.html 是它的生成物）" % OS)

    PLATE = os.path.abspath(args.plate)
    if not os.path.exists(PLATE):
        die("底板图不存在：%s" % PLATE)
    SCRIM, CARD_BACK = args.scrim, args.card_back
    SEED, STAR_DIV, LIVE_STARS = args.seed, args.star_div, args.live_stars
    SUB_COLOR = args.sub_color
    NO_HERO, NO_TWINKLE, PARALLAX = args.no_hero, args.no_twinkle, args.parallax
    BAKE_PAD = 14 if PARALLAX else 0
    if LIVE_STARS > 60:
        die("--live-stars %d 超上限（60）—— 同屏动画元素多了会让 snapshot 报 "
            "「Navigation timeout of 10000 ms exceeded」，实测 169 条必挂" % LIVE_STARS)

    src = open(OS, encoding="utf-8").read()

    # ⚠ 幂等闸门：绝不叠加。重复跑只会让 CSS/DOM/tween 各多一份，体积翻倍且 tween 冲突。
    if 'id="hfbg"' in src:
        die("index.html 里已经有背景层（<div id=\"hfbg\">）——本脚本不叠加。\n"
            "        先重跑 `python build_cards.py` 生成干净的 index.html，再跑本脚本。")

    os.makedirs(ASSETS, exist_ok=True)
    bake_plate()
    bake_sprites()

    # root 的尺寸/总时长从 base 解析，避免和常量各写一份
    m = re.search(r'<div [^>]*id="root"[^>]*data-duration="([\d.]+)"[^>]*>', src)
    assert m, "找不到 root 的 data-duration"
    total = float(m.group(1))
    m2 = re.search(r'<div [^>]*id="root"[^>]*data-width="(\d+)" data-height="(\d+)"', src)
    assert m2 and (int(m2.group(1)), int(m2.group(2))) == (W, H), \
        "root 尺寸 %s 与本脚本常量 (%d,%d) 不一致" % (m2.groups() if m2 else None, W, H)

    rnd = mulberry32(SEED)
    ambient = [] if NO_STARS else build_stars(rnd)
    live = [] if NO_STARS else build_live_stars(rnd, LIVE_STARS)
    heroes = [] if (NO_HERO or NO_STARS) else [dict(h) for h in HERO_STARS]
    if ambient:
        bake_stars_png(ambient)
    if heroes:
        bake_hero_sprites()

    if ambient or live:
        zb = {}
        for s in live:
            for zi, z in enumerate(LIVE_ZONES):
                if z[0] * W <= s["x"] <= z[1] * W and z[2] * H <= s["y"] <= z[3] * H:
                    zb[zi] = zb.get(zi, 0) + 1
                    break
        print("[stars] 环境 %d 颗（全部烘焙）+ 活的 %d 颗（大星 %d / 小星 %d），种子 %d%s"
              % (len(ambient), len(live), sum(s["big"] for s in live),
                 len(live) - sum(s["big"] for s in live), SEED,
                 "   [排障] NO_TWINKLE=1" if NO_TWINKLE else ""))
        print("        活星分区：%s"
              % "  ".join("区%d=%d" % (k + 1, zb.get(k, 0)) for k in range(len(LIVE_ZONES))))
        if heroes:
            print("        hero 主星：%s"
                  % "  ".join("#%d (%.0f,%.0f) k=%.2f phase=%.2fs"
                              % (i + 1, h["x"] * W, h["y"] * H, h["k"], h["phase"])
                              for i, h in enumerate(heroes)))

    out = src
    out = sub_once(out, "    </style>", css_block() + "    </style>", "css")
    out = sub_once(out, "  <body>\n", '  <body class="hfbg">\n', "body")
    out = sub_once(out, m.group(0), m.group(0) + "\n" + bg_stage_html(live, heroes), "root-open")
    out = sub_once(out, '      window.__timelines["main"] = tl;',
                   timeline_block([] if NO_TWINKLE else live, heroes, total)
                   + '      window.__timelines["main"] = tl;', "timeline")

    # hero 的 CSS 静态值必须与 tween 起始值逐项一致 —— tween 带 immediateRender:false，
    # 若两者不等，t≥0 的第一帧会看见一次跳变（这正是 MEMORY.md 第 12 条那个坑的变体）。
    if heroes and not NO_TWINKLE:
        for cls, li in (("h-aura", 0), ("h-rays", 1), ("h-core", 2)):
            mm = re.search(r"\.sth \.%s \{[^}]*\}" % cls, out)
            assert mm, "CSS 里找不到 .sth .%s 规则" % cls
            blk, lay = mm.group(0), HERO_LAYERS[li]
            checks = [("opacity", "opacity: %.2f" % lay[2])]
            if (lay[4], lay[5]) != (1.0, 1.0):     # scale 恒 1 的层不写 transform（缺省即 1）
                checks.append(("scale", "scale(%.2f)" % lay[4]))
            if lay[6] != 0.0:
                checks.append(("rotate", "rotate(%.1fdeg)" % lay[6]))
            for label, expect in checks:
                assert expect in blk, \
                    "hero .%s 的 CSS %s 与 tween 起始值不一致（期望 %s）→ t=0 会跳变" % (cls, label, expect)

    # 反向断言：产物里不许再出现任何渲染期不确定性来源（渲染器逐帧 seek，没有 playback）
    for bad, why in (("performance.now", "渲染时时钟"), ("Math.random", "无种子随机"),
                     ("requestAnimationFrame", "rAF 循环"), ("pointermove", "输入态"),
                     ("addEventListener", "事件驱动"), ("setTimeout", "定时器"),
                     ("repeat: -1", "无限循环")):
        assert bad not in out, "产物里仍含 %s（%s）" % (bad, why)

    with open(OS, "w", encoding="utf-8", newline="\n") as f:
        f.write(out)

    print("[write] index.html  %.1f KB（加层前 %.1f KB）"
          % (len(out.encode("utf-8")) / 1024, len(src.encode("utf-8")) / 1024))
    print("[style] scrim %.2f · card_back %.2f · sub_color %s · 背景位移 %s"
          % (SCRIM, CARD_BACK, SUB_COLOR, "开（码率 ×4！）" if PARALLAX else "关（推荐）"))
    n_tw = 0 if NO_TWINKLE else len(live)
    n_hd = 0 if NO_TWINKLE else len(heroes) * len(HERO_LAYERS)
    print("[tween] 星点闪烁 %d 条 + hero %d 条 = %d 条（实测上限 ~110，超了 snapshot 会超时）"
          % (n_tw, n_hd, n_tw + n_hd))
    print("[done] 下一步：check → render（顺序见 SKILL.md「第 6 步」）")


if __name__ == "__main__":
    main()
