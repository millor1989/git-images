#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cleanup_project.py —— 行情视频工程「收尾清理」（2026-10-02 新增，skill share-market-video 第 7 步）

目的：一期视频交付完成后，把工程目录里除「交付物 + 行情数据 md」之外的
QA 抽帧、日志、临时脚本、中间产物全部清掉，避免每期堆几十 MB 垃圾。

保留（任何模式都保留）：
  - out-*.mp4                 成片
  - cover-*.png               封面（片头末帧）
  - video-summary-*.txt       概述文档（发布用文案；2026-10-16 起只出 txt，
                              旧工程的 .md 也一并保留以免误删）
  - data/                     行情数据 md（做视频的依据，含来源清单）
  - automation-state.json     看门狗判活依据（--drop-automation 才删）

两档清理：
  --mode safe（默认档之外的保守档）
      只删 QA / 日志 / 临时脚本 / __pycache__ / hyperframes transaction 目录 / render.done
      保留工程源码（build_cards.py、index.html、audio/、env.json、build.sh…）
      → 还能直接改一版重渲
  --mode deliverables（默认）
      在 safe 基础上再删工程源码与音频，只留上面 5 类
      → 想要再出一版必须从 init_project.py 重建（行情 md 还在，数据不丢）

用法：
  python cleanup_project.py --project <PROJ>                 # 默认 dry-run，只列清单
  python cleanup_project.py --project <PROJ> --apply         # 真删
  python cleanup_project.py --project <PROJ> --mode safe --apply
  python cleanup_project.py --project <PROJ> --keep-audio --apply
  python cleanup_project.py --project <PROJ> --drop-automation --apply

安全设计：
  1. 默认 dry-run，必须显式 --apply 才会动文件；
  2. 只在本工程目录内操作，路径一律 resolve 后校验前缀，绝不越界；
  3. 目录里既没有 data/market-*.md 又没有 out-*.mp4 时拒绝执行（--force 才放行），
     防止把别的目录当工程清掉；
  4. 用 --drop-automation 之前确认看门狗窗口已过，否则 B 任务找不到 state 会误判接管。
"""

import argparse
import os
import re
import shutil
import sys
from pathlib import Path

# ---------------- 分类规则 ----------------

RE_DELIVERABLE = [
    re.compile(r'^out-.*\.mp4$', re.I),
    re.compile(r'^cover-.*\.png$', re.I),
    re.compile(r'^video-summary-.*\.(md|txt)$', re.I),
]

# 任何档位都删的「垃圾」：QA 抽帧、日志、临时脚本、缓存、渲染过程残留
JUNK_DIR_NAMES = {'qa', '__pycache__', '.pytest_cache'}
JUNK_FILE_SUFFIXES = ('.log', '.pyc', '.tmp', '.bak')
JUNK_FILE_NAMES = {'render.done', '.DS_Store'}
JUNK_FILE_PATTERNS = [
    re.compile(r'^_patch_.*\.py$'),
    re.compile(r'^_wy\.py$'),
    re.compile(r'^_sleep\.ps1$'),
    re.compile(r'^ff_stdin_shim.*\.log$'),
]
# hyperframes 渲染事务目录：.out-1002.hf-transaction-XXXX
RE_JUNK_DIR = [
    re.compile(r'^\.out-.*\.hf-transaction-'),
]
# 改版式验证时手工拷的临时 html（_b.html / _b2.html …）
RE_TEMP_HTML = re.compile(r'^_[A-Za-z0-9]+\.html$')

# automation 证据（默认保留，--drop-automation 才删）
AUTOMATION_FILES = {'automation-state.json', 'automation-run.log'}
AUTOMATION_STATE = 'automation-state.json'


def is_deliverable(name: str) -> bool:
    return any(p.match(name) for p in RE_DELIVERABLE)


def is_junk(entry: Path) -> bool:
    """safe 档就删的：QA / 日志 / 临时脚本 / 缓存 / 渲染残留。"""
    n = entry.name
    if entry.is_dir():
        if n in JUNK_DIR_NAMES:
            return True
        return any(p.match(n) for p in RE_JUNK_DIR)
    if n in JUNK_FILE_NAMES:
        return True
    if n.endswith(JUNK_FILE_SUFFIXES):
        return True
    if any(p.match(n) for p in JUNK_FILE_PATTERNS):
        return True
    if n.endswith('.html') and RE_TEMP_HTML.match(n):
        return True
    return False


def dir_size(p: Path) -> int:
    if p.is_file():
        return p.stat().st_size
    total = 0
    for f in p.rglob('*'):
        try:
            if f.is_file():
                total += f.stat().st_size
        except OSError:
            pass
    return total


def human(n: float) -> str:
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n < 1024 or unit == 'GB':
            return f'{n:.1f} {unit}' if unit != 'B' else f'{int(n)} B'
        n /= 1024.0
    return f'{n:.1f} GB'


def main() -> int:
    ap = argparse.ArgumentParser(description='行情视频工程收尾清理')
    ap.add_argument('--project', '--proj', dest='project', required=True,
                    help='工程目录（如 E:/workbuddy/hfVideos/market-20260930）')
    ap.add_argument('--mode', choices=('safe', 'deliverables'), default='deliverables',
                    help='safe=只删 QA/日志/临时；deliverables=只留交付物+行情md（默认）')
    ap.add_argument('--apply', action='store_true',
                    help='真删；不加则只列清单（dry-run）')
    ap.add_argument('--keep-audio', action='store_true',
                    help='保留 audio/ 与 narration-script-*.md（默认在 deliverables 档删掉）')
    ap.add_argument('--drop-automation', action='store_true',
                    help='连 automation-state.json / automation-run.log 一起删（确认看门狗窗口已过再用）')
    ap.add_argument('--force', action='store_true',
                    help='目录不像工程（无 data/market-*.md 且无 out-*.mp4）时也放行')
    args = ap.parse_args()

    proj = Path(args.project).expanduser().resolve()
    if not proj.is_dir():
        print(f'✗ 工程目录不存在：{proj}')
        return 2

    entries = sorted(proj.iterdir(), key=lambda p: p.name.lower())
    has_md = any((proj / 'data').is_dir() and list((proj / 'data').glob('market-*.md')))
    has_mp4 = any(p.is_file() and p.name.startswith('out-') and p.suffix == '.mp4' for p in entries)
    if not (has_md or has_mp4) and not args.force:
        print(f'✗ {proj} 里既没有 data/market-*.md 也没有 out-*.mp4 —— 不像工程目录。'
              f'确认无误再加 --force。')
        return 2

    keep, delete = [], []
    for e in entries:
        n = e.name
        if n == 'data' and e.is_dir():
            keep.append((e, '行情数据 md（做片依据）'))
            continue
        if e.is_file() and is_deliverable(n):
            keep.append((e, '交付物'))
            continue
        if args.keep_audio and (n == 'audio' or (e.is_file() and n.startswith('narration-script-'))):
            keep.append((e, '音频/播音稿（--keep-audio）'))
            continue
        if e.is_file() and n in AUTOMATION_FILES:
            if not args.drop_automation:
                keep.append((e, '自动化证据（默认保留）'))
                continue
            delete.append((e, '自动化证据（--drop-automation）'))
            continue
        if is_junk(e):
            delete.append((e, 'QA/日志/临时'))
            continue
        if args.mode == 'deliverables':
            delete.append((e, '工程源码/中间产物'))
        else:
            keep.append((e, '工程源码（safe 档保留）'))

    del_bytes = sum(dir_size(p) for p, _ in delete)
    keep_bytes = sum(dir_size(p) for p, _ in keep)

    print(f'工程：{proj}')
    print(f'档位：{args.mode}   模式：{"APPLY（真删）" if args.apply else "DRY-RUN（只列清单）"}')
    print()
    print('【保留】')
    for p, why in keep:
        print(f'  KEEP   {p.name:<46} {human(dir_size(p)):>10}   {why}')
    print()
    print('【删除】')
    for p, why in delete:
        print(f'  DEL    {p.name:<46} {human(dir_size(p)):>10}   {why}')
    print()
    print(f'删除 {len(delete)} 项 / 释放 {human(del_bytes)}；保留 {len(keep)} 项 / {human(keep_bytes)}')

    if not args.apply:
        print('\n（dry-run，未改动任何文件；加 --apply 才会真删）')
        return 0

    if not delete:
        print('\n没有需要删除的东西。')
        return 0

    ok, fail = 0, 0
    for p, _ in delete:
        try:
            # 越界二次校验：绝不允许删到工程目录之外
            rp = p.resolve()
            if proj not in rp.parents and rp != proj:
                print(f'  ✗ 越界，跳过：{rp}')
                fail += 1
                continue
            if rp.is_dir():
                shutil.rmtree(rp)
            else:
                rp.unlink()
            ok += 1
        except Exception as ex:  # noqa: BLE001
            print(f'  ✗ 删除失败 {p.name}: {ex}')
            fail += 1

    print(f'\n✅ 已删除 {ok} 项 / 释放 {human(del_bytes)}' + (f'；失败 {fail} 项' if fail else ''))
    left = sorted(x.name for x in proj.iterdir())
    print('剩余：' + ', '.join(left))
    return 0 if fail == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
