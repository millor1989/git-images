# -*- coding: utf-8 -*-
"""预渲染 QA —— 基于 hyperframes snapshot，**不渲染成片**。

拷到工程的 `qa/` 下运行（或任意位置配 `--proj <工程根>`）。
本文件**自包含**，不依赖工程里的 qa_cards.py。

为什么内容层 QA 可以前移（2026-09-17 实测）：
  · `snapshot --at` 是「精确 seek + 截图」；同一时刻抓两次**字节级一致**（max diff = 0）
  · 像素判据的量级与成片 QA 完全一致：真换页 diff_px 7.3 万~65.8 万，真静止 0
  · 成片那层 h264 对**静止/近静止画面走 skip 宏块**，帧间噪声恒在 0~83 —— 它没提供
    额外信息，只是多花十几分钟渲染

只有「编码层」必须看成片，而那些 ffprobe 秒级可得（见 qa_post.py）：
  分辨率 / 帧率 / 实际帧数 / 音轨 / 可解码 / 与旁白是否对齐

用法（工程根目录下）：
    python qa/qa_pre.py                    # 跑完清理 PNG，只留对照图
    python qa/qa_pre.py --keep             # 保留 snap-pre/ 全部帧
    python qa/qa_pre.py --sec sec2         # 只查某一段（调版式时用）
    python qa/qa_pre.py --no-snapshot      # 复用已有 snap-pre/，秒级复判（改了判据逻辑时用）
"""
import argparse
import glob
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent

# ⚠ 不要把外部二进制写成常量：换机器后 node 版本目录 hash、npx 缓存 hash 都会变，
#   ffmpeg 也挪过位置（node 目录 → binaries/ffmpeg/<build>/bin/）—— 写死就静默跑不起来
#   （表现为 FFPROBE 探测直接抛 FileNotFoundError）。
#   解析顺序：<proj>/env.json（preflight 产物） → 同名环境变量 → 内置回退 → PATH。
#   内置回退**按运行时 home 目录 + glob 通配**求值，不写死用户名/版本 hash。
NODE = "node"
FFPROBE = "ffprobe"
HF = ""


def _wb_home():
    """定位 .workbuddy 根目录（默认 ~/.workbuddy，可用 WORKBUDDY_HOME 覆盖）。"""
    for k in ("WORKBUDDY_HOME", "WB_HOME"):
        v = os.environ.get(k)
        if v and os.path.isdir(v):
            return Path(v)
    return Path.home() / ".workbuddy"


def _first_existing(patterns):
    """按顺序取第一个真实存在的文件；支持 glob 通配（版本目录 hash 会变）。"""
    for pat in patterns:
        for hit in sorted(glob.glob(str(pat))):
            if os.path.isfile(hit):
                return hit
    return None


def _fallback_bins():
    wb = _wb_home()
    ff = _first_existing([wb / "binaries/ffmpeg/*/bin/ffmpeg.exe",
                          wb / "binaries/ffmpeg/*/bin/ffmpeg"])
    fp = _first_existing([wb / "binaries/ffmpeg/*/bin/ffprobe.exe",
                          wb / "binaries/ffmpeg/*/bin/ffprobe"])
    if not fp and ff:                       # ffprobe 通常与 ffmpeg 同目录
        for name in ("ffprobe.exe", "ffprobe"):
            sib = Path(ff).with_name(name)
            if sib.is_file():
                fp = str(sib)
                break
    return {
        "node": _first_existing([wb / "binaries/node/versions/*/node.exe",
                                 wb / "binaries/node/versions/*/node"]),
        "ffprobe": fp,
        "hyperframes_cli": _first_existing([
            wb / "tmp/npm-cache/_npx/*/node_modules/hyperframes/bin/hyperframes.mjs",
            Path.home() / ".npm/_npx/*/node_modules/hyperframes/bin/hyperframes.mjs",
        ]),
    }


_FALLBACK = {k: v for k, v in _fallback_bins().items() if v}


def load_bins(proj):
    """把 NODE / FFPROBE / HF 解析成真实可执行路径（工程 env.json 优先）。"""
    global NODE, FFPROBE, HF
    cfg = {}
    for cand in (Path(proj) / "env.json", HERE.parent / "env.json"):
        try:
            if cand.exists():
                cfg = json.loads(cand.read_text(encoding="utf-8"))
                break
        except Exception:                                   # noqa: BLE001
            pass

    def pick(key, env_name, fallback):
        for v in (os.environ.get(env_name), cfg.get(key),
                  _FALLBACK.get(key), fallback):
            if v and (Path(v).exists() or v in ("node", "ffprobe")):
                return v
        return fallback

    NODE = pick("node", "HF_NODE", "node")
    FFPROBE = pick("ffprobe", "FFPROBE", "ffprobe")
    HF = pick("hyperframes_cli", "HF_CLI", _FALLBACK.get("hyperframes_cli", ""))
    print(f"  bins: node={Path(NODE).name}  ffprobe={Path(FFPROBE).name}  "
          f"cli={Path(HF).name}")

FPS = 30
DOT_W, DOT_GAP = 18, 16   # .dot 18px + gap 16px（与模板 CSS 对应）

PRE_CUT = 0.45        # 量到切点前 0.45s：换场动画在「切点−0.32s」就起，必须排除
MIN_SETTLED = 1.5     # 每屏完整态最少停留
STEP = 0.4            # 倒推采样步长（与成片 QA 一致，便于横向比对）
TAIL_PROBES = 6       # 每屏尾部采样点数 → 覆盖 2.0s（即读数上限）

# ⚠ 阈值**不能照搬成片 QA 的值**（2026-09-17 实测踩到，白跑一轮）：
#   成片 QA 用 2000，那是为「h264 解码帧」定的 —— 编码器对静止/近静止画面走 skip
#   宏块，连动画收尾的亚像素抗锯齿残差一起抹平，实测帧间差恒在 0~83。
#   snapshot 是无损 PNG，同样的收尾残差会留下 ~3,557px（0.17% 画面）。
#   照搬 2000 → 把「动画尾巴」误判成「还在动」→ 停留时长低报 0.4s → 假 fail。
#   实测三级分布：真静止 0 ｜ 动画收尾 3,557 ｜ 动画中段 84,805 ｜ 换屏 7 万~65.8 万
#   → 取 10,000（≈0.5% 画面）才能干净切开「收尾」与「中段」。
#
# ⚠⚠ 2026-09-30 追加（星空背景层转默认，本条不改就是**全屏假 fail**）：
#   上面那套三级分布是**无背景层**时标的。星空层（第 5D 步，`bash build.sh` 默认加）
#   含 12 颗闪烁星（repeat 49~196）+ 6 层 hero 主星呼吸（半周期 1.14~2.8s，repeat 39~96）
#   —— **整片永不静止**。实测其帧间贡献：全帧 8,500~12,000px、边缘无卡片区也有
#   1,500~6,800px，且残差峰值高达 135~182（不是「亚像素抗锯齿」那种弱残差）。
#   → 10,000 这个阈值正好落进背景噪声带中间 → 11 屏全部随机报 0.0~0.8s（假 fail）。
#   实证：同一批时刻，**把 #hfbg 子树摘掉再抓帧，帧间差精确为 0**（逐帧 0/0/0）。
#   → 唯一正确修法 = 抓帧前摘掉背景层（见 strip_bg_layer / run_snapshot 的临时副本），
#     让「完整态停留」量的是**卡片层**的运动。别去调大 DIFF_MOVED：
#     背景带与卡片带已重叠，任何单一像素阈值都分不开（实测卡片入场增量仅 ~3,000px）。
DIFF_MOVED = 10000    # 「画面确实在动」—— 0.5% 画面的变化（**仅在摘掉背景层后有效**）
DIFF_PAGE = 20000     # 「确实换页了」（实测两屏终态差 7.3 万~65.8 万，余量充足）
                       # ⚠ 换页判定同样必须在摘掉背景层后做，否则背景噪声会垫高基线


# ------------------------------------------------- 像素判据（自包含，与 qa_cards.py 同源）
def probe(p):
    r = subprocess.run([FFPROBE, "-v", "error", "-show_entries", "format=duration",
                        "-of", "default=noprint_wrappers=1:nokey=1", str(p)],
                       capture_output=True, text=True, check=True, encoding="utf-8")
    return float(r.stdout.strip())


def arr(png):
    return np.asarray(Image.open(png).convert("RGB"), dtype=np.int16)


def diff_px(a, b, thr=8):
    """两帧差 >thr 的像素个数。"""
    return int(np.count_nonzero(np.abs(a - b).max(axis=2) > thr))


def color_stats(a):
    r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    red = int(((r > 200) & (g < 120) & (b < 120)).sum())
    green = int(((g > 150) & (r < 100) & (b < 180)).sum())
    return red, green


def dots_box(n):
    """.dots 是 flex 右对齐（right:78px）→ 组宽 = 34n-16，左边缘 = 1018-34n。"""
    left = 1018 - 34 * n
    return (left - 12, 175, 1020, 215), left


def dot_index(a, n):
    """页点区里青色像素的 x 质心 → 第几个点（0-based），无青色返回 None。"""
    box, left = dots_box(n)
    sub = a[box[1]:box[3], box[0]:box[2]]
    r, g, b = sub[:, :, 0], sub[:, :, 1], sub[:, :, 2]
    m = (b > 170) & (g > 140) & (r < 130)
    xs = np.nonzero(m)[1]
    if xs.size == 0:
        return None
    cx = box[0] + xs.mean()
    return round((cx - (left + DOT_W / 2.0)) / (DOT_W + DOT_GAP))


# --------------------------------------------------------------- 解析工程
def parse_sections(proj):
    """从 index.html 读各 section 的 [起, 止, 换页点]，替代硬编码 SECTIONS。

    ⚠ 别像 qa_cards.py 那样手抄一份 SECTIONS —— 换页点一改就漂移，
      「QA 说 1.2s、生成器说 1.6s」就是两边各写一份的后果。
    """
    html = (proj / "index.html").read_text(encoding="utf-8")
    found = {}
    for m in re.finditer(
            r'id="(sec\d)"[^>]*?data-start="([\d.]+)"[^>]*?data-duration="([\d.]+)"', html):
        found[m.group(1)] = (float(m.group(2)), float(m.group(2)) + float(m.group(3)))
    if not found:
        raise SystemExit("[error] index.html 里没解析到 sec 段，检查生成器输出")

    breaks = parse_breaks(proj)
    out = []
    for name in sorted(found, key=lambda k: int(k[3:])):
        s, e = found[name]
        out.append((name, s, e, list(breaks.get(name, []))))
    return out


def parse_breaks(proj):
    """从生成器抠 PAGE_BREAKS —— 生成器是唯一事实源。找不到就返回空（每段一屏）。"""
    for fn in ("build_cards.py", "build_index.py"):
        f = proj / fn
        if not f.exists():
            continue
        src = f.read_text(encoding="utf-8")
        m = re.search(r"PAGE_BREAKS\s*=\s*\{(.*?)\n\}", src, re.S)
        if not m:
            continue
        body = re.sub(r"#[^\n]*", "", m.group(1))      # 去注释
        out = {}
        for sec, arr_s in re.findall(r'"(sec\d)"\s*:\s*\[([^\]]*)\]', body):
            out[sec] = [float(x) for x in re.findall(r"[\d.]+", arr_s)]
        return out
    print("  ~ 没找到 PAGE_BREAKS（build_cards.py / build_index.py），按「每段一屏」处理")
    return {}


def plan(secs):
    """列出 (段, 屏号, 屏数, 起, 止, 终态时刻, [倒推采样点...])。"""
    rows = []
    for name, s, e, bks in secs:
        bounds = [s] + bks + [e]
        for i in range(len(bounds) - 1):
            p0, p1 = bounds[i], bounds[i + 1]
            t_end = round(p1 - PRE_CUT, 3)
            pts = [round(t_end - STEP * k, 3) for k in range(TAIL_PROBES)]
            pts = [t for t in pts if t > p0 + 0.30]
            rows.append((name, i, len(bounds) - 1, p0, p1, t_end, pts))
    return rows


# --------------------------------------------------------------- 抓帧
def clean_dir(d):
    """清空目录 —— **必须走单条 shell 命令**。

    ⚠ 宿主的 safe-delete 保护是按「**本回合累计删除的文件数**」计数的
    （`{"count":50,"threshold":50,"scope":"turn"}`），阈值 50。所以：

      * `shutil.rmtree()` → 94 次 unlink → 第 50 个就被拦，**进程直接终止**；
      * 即使 `path.unlink()` 循环「每批 40」**也照样被拦** —— 计数是跨批累计的，
        分批完全无效（2026-09-18 先踩一次、2026-09-19 二次复现，两次都白查一轮）。

    症状固定为：**QA 逐项全部通过，却 exit=1，且末尾『== 结论 ==』两行不打印** ——
    极容易被误判成「QA 失败」。

    正确做法：整目录交给一条 `rm -rf` / `rmdir /s /q` —— 对宿主而言只算 **1 个**
    删除目标，稳定通过。返回删除的文件数（尽力而为，失败返回 0）。
    """
    d = Path(d)
    if not d.exists():
        return 0
    n = sum(1 for p in d.rglob("*") if p.is_file())
    if os.name == "nt":
        cmd = ["cmd", "/c", "rmdir", "/s", "/q", str(d)]
    else:
        cmd = ["rm", "-rf", str(d)]
    try:
        subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    except Exception:  # noqa: BLE001
        pass
    return 0 if d.exists() else n


def strip_bg_layer(html):
    """摘掉星空背景层子树（#hfbg），返回 (新 html, 是否摘掉)。

    ⚠ 为什么必须摘（2026-09-30 实测，见文件头 DIFF_MOVED 处）：
      #hfbg 内含常驻闪烁星 + hero 主星呼吸，**整片永不静止**，帧间贡献
      8,500~12,000px，正好盖过 10,000 的阈值 → 11 屏全报假 fail。
      摘掉后同一批时刻帧间差**精确为 0**，卡片层运动才量得准。

    ⚠ 别用「去掉 <body class="hfbg">」代替：`#hfbg` 的 CSS 未加 body.hfbg 作用域
      （只有可读性微调加了），去掉 class 只会拿掉遮罩，星空照旧 render。
      必须整棵子树摘掉。

    只作用于 **QA 抓帧用的临时副本**，绝不回写 index.html —— 版式探针/换页/页点
    用无背景帧即可，成片仍带背景。用「深度计数的 div 配对」精确取子树边界，
    比正则贪婪匹配稳（`#hfbg` 内嵌套 3 层 div + 一个 #stars）。
    """
    key = '<div id="hfbg">'
    i = html.find(key)
    if i < 0:
        return html, False
    j, depth = i, 0
    pat = re.compile(r"<div\b|</div>")
    while True:
        m = pat.search(html, j)
        if not m:
            return html, False                  # 括号不配 → 原样返回，宁可不摘
        if m.group(0).startswith("</"):
            depth -= 1
            if depth == 0:
                end = m.end()
                break
        else:
            depth += 1
        j = m.end()
    return html[:i] + "<!-- QA: #hfbg removed -->" + html[end:], True


def run_snapshot(proj, times, outdir):
    outdir = proj / outdir
    if outdir.exists():
        clean_dir(outdir)

    # ★ 抓帧前把 index.html 换成「摘掉背景层」的临时副本，抓完立刻还原。
    #   实现在 try/finally 里，异常也不留脏 index.html（否则会污染后续渲染）。
    idx = proj / "index.html"
    real = idx.read_text(encoding="utf-8")
    stripped, did = strip_bg_layer(real)
    if did:
        idx.write_text(stripped, encoding="utf-8")
        print("  （已临时摘掉 #hfbg 背景层抓帧 —— 只影响本次 QA，抓完自动还原）")
    else:
        print("  （index.html 里没有 #hfbg —— 按无背景层判，阈值直接可用）")

    cmd = [NODE, HF, "snapshot", "--no-browser-gpu", "--no-end",
           "--timeout", "90000", "-o", str(outdir),
           "--at", ",".join(f"{t:.3f}" for t in times)]
    t0 = time.time()
    try:
        r = subprocess.run(cmd, cwd=str(proj), capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
    finally:
        if did:
            idx.write_text(real, encoding="utf-8")
    dt = time.time() - t0
    if r.returncode != 0:
        print(r.stdout[-2000:])
        print(r.stderr[-2000:], file=sys.stderr)
        raise SystemExit(f"[error] snapshot 失败（exit={r.returncode}）")

    # 帧名里的秒数会被**截断**（15.0 → "15s"、177.0 → "177s"），
    # 所以只能按「序号 ↔ 传入顺序」配对，**别用文件名里的数字反查时刻**。
    pngs = sorted(outdir.glob("frame-*.png"),
                  key=lambda p: int(re.search(r"frame-(\d+)", p.name).group(1)))
    if len(pngs) != len(times):
        raise SystemExit(f"[error] 期望 {len(times)} 帧，实得 {len(pngs)} 帧")
    print(f"  snapshot 抓 {len(pngs)} 帧，耗时 {dt:.0f}s -> {outdir.name}/")
    return pngs


# --------------------------------------------------------------- 主流程
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--proj", default="", help="工程根目录（默认：脚本上一级）")
    ap.add_argument("--sec", default="", help="只查这一段，如 sec2")
    ap.add_argument("--keep", action="store_true", help="保留抓下的 PNG")
    ap.add_argument("--no-snapshot", action="store_true",
                    help="复用已有 snap-pre/（改了判定逻辑时用，秒级）")
    args = ap.parse_args()

    proj = Path(args.proj).resolve() if args.proj else HERE.parent
    if not (proj / "index.html").exists():
        raise SystemExit(f"[error] {proj} 下没有 index.html，用 --proj 指定工程根")
    load_bins(proj)

    secs = parse_sections(proj)
    if args.sec:
        secs = [s for s in secs if s[0] == args.sec]
        if not secs:
            raise SystemExit(f"[error] 没有 {args.sec} 这一段")
    rows = plan(secs)
    fails = []

    # ---- 1. 时长（读工程声明 vs 旁白，秒级，不用成片）
    print("== 1. 时长 / 屏数（读 index.html 声明，无需成片）==")
    html = (proj / "index.html").read_text(encoding="utf-8")
    m = re.search(r'data-composition-id="main"[^>]*data-duration="([\d.]+)"', html)
    total = float(m.group(1)) if m else None
    nar = proj / "assets" / "narration.mp3"
    if not nar.exists():  # 版本命名约定（narration-v1.mp3 / -v2…）→ 取最新一份
        cands = sorted((proj / "assets").glob("narration*.mp3"))
        nar = cands[-1] if cands else nar
    n = probe(nar) if nar.exists() else None
    if total is not None and n is not None:
        print(f"  工程声明总时长 {total:.2f}s ｜ 旁白 {n:.2f}s ｜ 差 {total - n:+.2f}s")
        if abs(total - n) >= 0.05:
            fails.append(f"工程时长与旁白差 {total - n:+.2f}s（≥0.05s）→ 渲出来必歪")
    elif total is None:
        print("  ~ 没读到 data-composition-id=\"main\" 的 data-duration")

    # ---- 抓帧
    print(f"\n== 抓帧（{len(rows)} 屏，snapshot，不渲染）==")
    want, seen = [], {}
    for _, _, _, _, _, t_end, pts in rows:
        for t in [t_end] + pts:
            if t not in seen:
                seen[t] = len(want)
                want.append(t)
    if args.no_snapshot:
        pngs = sorted((proj / "snap-pre").glob("frame-*.png"),
                      key=lambda p: int(re.search(r"frame-(\d+)", p.name).group(1)))
        if len(pngs) != len(want):
            raise SystemExit(f"[error] snap-pre/ 里有 {len(pngs)} 帧，本次需要 {len(want)} 帧"
                             "（换了时段/段就别用 --no-snapshot）")
        print(f"  复用 snap-pre/ 的 {len(pngs)} 帧")
    else:
        pngs = run_snapshot(proj, want, "snap-pre")

    cache = {}

    def img(t):
        if t not in cache:
            cache[t] = arr(pngs[seen[t]])
        return cache[t]

    # ---- 2~4. 逐屏
    print("\n== 2~4. 逐屏（换页 / 页点 / 完整态停留）==")
    finals, dotseq = {}, {}
    for name, i, ndots, p0, p1, t_end, pts in rows:
        end_a = img(t_end)
        finals[(name, i)] = end_a
        run, prev = 0, end_a
        for t in pts[1:]:                      # 从尾往前数连续静止
            if diff_px(img(t), prev) >= DIFF_MOVED:
                break
            run += 1
            prev = img(t)
        settle = run * STEP
        di = dot_index(end_a, ndots)
        dotseq.setdefault(name, []).append((i, di, ndots))
        ok = settle >= MIN_SETTLED
        print(f"  {name} 屏{i + 1}  [{p0:6.2f}~{p1:6.2f} {p1 - p0:5.1f}s] 终态t={t_end:6.2f} "
              f"页点={di}  切屏前静止 {settle:4.1f}s  {'' if ok else '!! 停留过短'}")
        if not ok:
            fails.append(f"{name} 屏{i + 1} 完整态仅停留 {settle:.1f}s < {MIN_SETTLED}s")

    for name in [s[0] for s in secs]:
        idxs = [d for (_, d, _) in sorted(dotseq[name])]
        n_dots = dotseq[name][0][2]
        for i in range(len(idxs) - 1):
            d = diff_px(finals[(name, i)], finals[(name, i + 1)])
            print(f"      {name} 屏{i + 1}↔屏{i + 2} 画面差 {d}px  "
                  f"{'OK 确实换页' if d > DIFF_PAGE else '!! 几乎相同'}")
            if d <= DIFF_PAGE:
                fails.append(f"{name} 屏{i + 1}→屏{i + 2} 画面几乎没变（{d}px）")
        real = [x for x in idxs if x is not None]
        mono = real == sorted(real) and len(set(real)) == len(real)
        print(f"      {name} 页点序列 {idxs}（共{n_dots}点）  "
              f"{'OK 逐个右移' if mono else '!! 未单调推进'}")
        if not mono:
            fails.append(f"{name} 页点未单调推进：{idxs}")

    # ---- 5. 涨跌色（用各屏终态帧，等价于成片 QA 的逐屏采样）
    print("\n== 5. 涨跌色齐备（整片累计；单屏只涨或只跌正常）==")
    tot_r = tot_g = 0
    for a in finals.values():
        red, green = color_stats(a)
        tot_r += red
        tot_g += green
    print(f"  {len(finals)} 屏合计 红{tot_r} / 绿{tot_g}")
    if tot_r == 0 or tot_g == 0:
        fails.append(f"整片缺涨跌色（红{tot_r}/绿{tot_g}）")

    # ---- 6. 对照图
    print("\n== 6. 对照图 ==")
    make_sheet(finals, proj / "qa" / "overview-pre.jpg", proj.name)

    if not args.keep:
        n = clean_dir(proj / "snap-pre")
        print(f"  （已清理 snap-pre/ 的 {n} 个文件；加 --keep 保留）")

    print("\n== 结论 ==")
    if fails:
        for f in fails:
            print(f"  !! {f}")
        print("  存在未通过项 —— 先修再渲染")
        return 1
    print("  全部通过 —— 可以渲染")
    return 0


def make_sheet(finals, out, name=""):
    from PIL import ImageDraw
    items = sorted(finals.items())
    SW, SH, PAD, TOP, LBL, COLS = 300, 533, 12, 54, 30, 6
    rows = (len(items) + COLS - 1) // COLS
    W = PAD * (COLS + 1) + SW * COLS
    H = TOP + (SH + LBL + PAD) * rows
    sheet = Image.new("RGB", (W, H), (14, 18, 24))
    d = ImageDraw.Draw(sheet)
    d.text((PAD, 20), f"预渲染 QA · {name} · {len(items)} 屏终态", fill=(0, 212, 255))
    for k, ((sec, i), a) in enumerate(items):
        r, c = divmod(k, COLS)
        x = PAD + c * (SW + PAD)
        y = TOP + r * (SH + LBL + PAD)
        sheet.paste(Image.fromarray(a.astype(np.uint8)).resize((SW, SH), Image.LANCZOS),
                    (x, y))
        d.rectangle([x - 1, y - 1, x + SW, y + SH], outline=(52, 62, 76))
        d.text((x + 2, y + SH + 6), f"{sec} 屏{i + 1}", fill=(200, 210, 224))
    out.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(out, quality=90)
    print(f"  saved -> {out}  {sheet.size}")


if __name__ == "__main__":
    raise SystemExit(main())
