# -*- coding: utf-8 -*-
"""导出「片头末帧」截图 —— 每期固定产物，用作视频封面。

为什么用**片头末帧**而不是 t=0 首帧：
    t=0 首帧虽然「六要素齐备」（不黑屏），但那一刻日期还停在放大态、数字刚开始
    count-up——是**动效中途**，不是设计上的稳态。片头末帧则是**全部入场动效落定**
    的稳定态（三层入场 + 一次性 pulse 都已结束），又**不含任何后续板块内容**，
    所以它是整片唯一「完整且静止」的画面。平台封面首选它。

实现：
    1. 从 <PROJ>/index.html 解析 `#intro` 段的 data-start / data-duration
       —— 片头段长随旁白实测时长浮动（本期 4.48s / 上期 4.79s），**绝不能写死**
    2. t = start + duration − lead（lead 默认 0.10s：避开段末切场那一两帧）
    3. ffmpeg 从成片精确抽 1 帧 → 无损 PNG
    4. 自检：尺寸 == 合成画布、且非黑帧（均亮 > 10）——防「抽到黑屏还当封面交出去」

用法（工程根目录下跑，或显式给 --project）：
    python qa/export_cover.py                            # → cover-<日期>.png
    python qa/export_cover.py --project <PROJ>
    python qa/export_cover.py --video out-us-0925.mp4 --name cover-0925.png
    python qa/export_cover.py --lead 0.30                # 想再往前退一点
    python qa/export_cover.py --dry-run                  # 只打印算出的时刻，不抽帧

日期取自 `data/market-YYYYMMDD.md`（本技能约定文件名），找不到则回退成片文件名。
退出码：0 = 已生成；2 = 找不到 intro 段 / 成片；3 = ffmpeg 失败 / 自检不过。
"""
import argparse
import glob
import os
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

# ⚠ 外部二进制不要写死（换机器后 ffmpeg 版本目录会变）。解析顺序：
#   <proj>/env.json → 内置回退 → PATH。内置回退**按运行时 home + glob 通配**求值。
FFMPEG = "ffmpeg"


def _fallback_ffmpeg():
    """按 ~/.workbuddy（可用 WORKBUDDY_HOME 覆盖）+ glob 通配找 ffmpeg。"""
    wb = Path.home() / ".workbuddy"
    for k in ("WORKBUDDY_HOME", "WB_HOME"):
        v = os.environ.get(k)
        if v and os.path.isdir(v):
            wb = Path(v)
            break
    for pat in ("binaries/ffmpeg/*/bin/ffmpeg.exe", "binaries/ffmpeg/*/bin/ffmpeg"):
        for hit in sorted(glob.glob(str(wb / pat))):
            if os.path.isfile(hit):
                return hit
    return None


def load_ffmpeg(proj):
    """把 FFMPEG 解析成真实可执行路径（工程 env.json 优先）。"""
    global FFMPEG
    import json
    for cand in (Path(proj) / "env.json", HERE.parent / "env.json"):
        try:
            cfg = json.loads(cand.read_text(encoding="utf-8"))
        except Exception:
            continue
        for key in ("ffmpeg", "ffmpeg_bin", "FFMPEG"):
            v = cfg.get(key)
            if isinstance(v, str) and v:
                p = Path(v)
                if p.is_dir():
                    p = p / "ffmpeg.exe"
                if p.exists():
                    FFMPEG = str(p)
                    return FFMPEG
    p = _fallback_ffmpeg()
    if p:
        FFMPEG = p
    return FFMPEG


def intro_window(proj):
    """解析 index.html 里 #intro 段的 (start, duration)。找不到返回 None。"""
    html = (Path(proj) / "index.html").read_text(encoding="utf-8", errors="ignore")
    m = re.search(r"<section\b[^>]*\bid=\"intro\"[^>]*>", html)
    if not m:
        return None
    tag = m.group(0)

    def attr(name):
        a = re.search(name + r'="([\d.]+)"', tag)
        return float(a.group(1)) if a else None

    start, dur = attr("data-start"), attr("data-duration")
    if start is None or dur is None:
        # 退化：只给了 duration 时按 track 0 从 0 起算
        if dur is not None:
            return 0.0, dur
        return None
    return start, dur


def canvas_size(proj):
    """解析合成画布尺寸（默认 1080x1920），用于自检。"""
    html = (Path(proj) / "index.html").read_text(encoding="utf-8", errors="ignore")
    w = re.search(r'data-width="(\d+)"', html)
    h = re.search(r'data-height="(\d+)"', html)
    return (int(w.group(1)) if w else 1080, int(h.group(1)) if h else 1920)


def pick_video(proj, given):
    """--video 优先；否则取工程根最新的 out-*.mp4。"""
    if given:
        p = Path(given)
        if not p.is_absolute():
            p = Path(proj) / p
        return p if p.exists() else None
    cands = sorted(Path(proj).glob("out-*.mp4"), key=lambda p: p.stat().st_mtime)
    return cands[-1] if cands else None


def pick_date(proj):
    """data/market-YYYYMMDD.md → YYYY-MM-DD；找不到返回 None。"""
    ms = sorted(Path(proj).glob("data/market-*.md"))
    if not ms:
        return None
    m = re.search(r"market-(\d{4})(\d{2})(\d{2})", ms[-1].name)
    return f"{m.group(1)}-{m.group(2)}-{m.group(3)}" if m else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default=".", help="工程根目录（默认当前目录）")
    ap.add_argument("--video", default=None, help="成片路径（默认为工程根最新 out-*.mp4）")
    ap.add_argument("--out", "--name", dest="name", default=None,
                    help="输出文件名（默认 cover-<日期>.png，落在工程根）")
    ap.add_argument("--lead", type=float, default=0.10,
                    help="距片头段末的回退秒数（默认 0.10s，避开切场边界）")
    ap.add_argument("--dry-run", action="store_true", help="只打印时刻，不抽帧")
    args = ap.parse_args()

    proj = Path(args.project).resolve()
    if not (proj / "index.html").exists():
        print(f"✗ {proj} 下没有 index.html（用 --project 指工程根）")
        return 2

    win = intro_window(proj)
    if not win:
        print("✗ index.html 里没找到 id=\"intro\" 的段落，无法定位片头末帧")
        return 2
    start, dur = win
    t_end = start + dur
    t = round(t_end - args.lead, 4)
    if t <= start:
        print(f"✗ --lead={args.lead} 把时刻推到片头起点之前（段 {start}~{t_end}）")
        return 2

    video = pick_video(proj, args.video)
    if not video:
        print("✗ 没找到成片（out-*.mp4）；先渲染，或显式 --video")
        return 2

    name = args.name or (f"cover-{pick_date(proj)}.png" if pick_date(proj) else "cover.png")
    out = Path(name)
    if not out.is_absolute():
        out = proj / out

    print(f"片头段 {start}s ~ {t_end}s（{dur}s）→ 末帧时刻 t = {t}s（lead {args.lead}s）")
    print(f"成片   {video}  ({video.stat().st_size / 1048576:.1f} MB)")
    print(f"输出   {out}")
    if args.dry_run:
        return 0

    load_ffmpeg(proj)
    # 输出侧 -ss（放在 -i 之后）→ 精确到帧，不靠关键帧对齐
    cmd = [FFMPEG, "-v", "error", "-y", "-i", str(video),
           "-ss", f"{t}", "-frames:v", "1", "-pix_fmt", "rgb24",
           "-compression_level", "9", str(out)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not out.exists():
        print("✗ ffmpeg 抽帧失败：")
        print((r.stderr or "").strip()[:800])
        return 3

    # 自检：尺寸 + 非黑帧（防「抽到黑屏还当封面交出去」）
    w_can, h_can = canvas_size(proj)
    try:
        from PIL import Image
        import numpy as np
        im = Image.open(out).convert("RGB")
        arr = np.asarray(im, dtype=np.float32)
        mean = float(arr.mean())
        lum = float((arr @ np.array([0.299, 0.587, 0.114], dtype=np.float32)).mean())
        ok_size = im.size == (w_can, h_can)
        print(f"自检   尺寸 {im.size[0]}x{im.size[1]}（画布 {w_can}x{h_can}）"
              f"{'✓' if ok_size else ' ✗ 尺寸不符'}")
        print(f"       平均亮度 {lum:.1f}/255 {'✓' if lum > 10 else ' ✗ 疑似黑帧'}"
              f"  平均色值 {mean:.1f}")
        if not ok_size or lum <= 10:
            print("✗ 自检未过，请检查 --lead 与成片")
            return 3
    except ImportError:
        print("（无 PIL/numpy，跳过自检）")

    print(f"✓ 封面已生成：{out}  ({out.stat().st_size / 1024:.0f} KB)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
