# -*- coding: utf-8 -*-
"""片头旁白时长实测探针 —— 把「片头播报控制在 3s 左右」翻译成可执行字数。

为什么需要它：中文 TTS 的字数与时长**不是线性可估**的 —— 同一字数不同断句实测能差
0.9s；且片头短句比整段长文本更慢（4.02 字/秒 vs 4.3 字/秒）。凭字数估算必然翻车。

用法：
    # 直接给候选（推荐：一次给 2~3 个，选落进目标区间的）
    python probe_intro_len.py "加息落地，半导体逆势收涨。" "美联储加息，三大指数收跌。"

    # 或从文件读（每行一条，# 开头为注释）
    python probe_intro_len.py --file candidates.txt

    # 改目标区间
    python probe_intro_len.py --target 3.0-3.3 "候选..."

输出：每条候选的字数 / 实测秒数 / 语速 / 片头总长（= 语音 + gap），并标出是否命中目标区间。
合成结果缓存到系统临时目录，重复跑同一文本不会重复请求 TTS。

实测基线（zh-CN-XiaoxiaoNeural +8%，2026-09-17）：
    3.0~3.3s → 11~12 字 ｜ 3.5s → 14 字 ｜ 3.8~4.0s → 15~17 字
    含完整日期「2026年9月16日」单独吃 ~1.9s；「9月16日」只占 ~0.9s
"""
import argparse
import asyncio
import glob
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile

import edge_tts

VOICE = os.environ.get("TTS_VOICE", "zh-CN-XiaoxiaoNeural")
RATE = os.environ.get("TTS_RATE", "+8%")
GAP = 0.30  # 片头末尾留白，与 intro-lab / 主工程一致

def _resolve_ffprobe() -> str:
    """env → PATH → ~/.workbuddy 下的通配查找。

    ⚠ 别在这里写死单一常量：node 版本目录 hash 换过（22.22.2-2 已删除），
    ffmpeg 也从 node 目录搬到了 binaries/ffmpeg/<build>/bin/（见 MEMORY §3）。
    所以内置回退一律**按运行时 home 目录 + glob 通配**求值，不写死用户名与版本串。
    """
    p = os.environ.get("FFPROBE")
    if p and os.path.exists(p):
        return p
    p = shutil.which("ffprobe")
    if p:
        return p
    wb = os.path.expanduser("~/.workbuddy")
    for k in ("WORKBUDDY_HOME", "WB_HOME"):
        v = os.environ.get(k)
        if v and os.path.isdir(v):
            wb = v
            break
    for pat in (
        "binaries/ffmpeg/*/bin/ffprobe.exe",
        "binaries/ffmpeg/*/bin/ffprobe",
        "binaries/node/versions/*/ffprobe.exe",
    ):
        for hit in sorted(glob.glob(os.path.join(wb, pat))):
            if os.path.isfile(hit):
                return hit
    return "ffprobe"


FFPROBE = _resolve_ffprobe()

CACHE = os.path.join(tempfile.gettempdir(), "share-market-video-intro-len")


def probe(path):
    r = subprocess.run(
        [FFPROBE, "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", path],
        capture_output=True, text=True)
    if r.returncode != 0 or not r.stdout.strip():
        raise RuntimeError(f"ffprobe 失败: {r.stderr.strip()[:120]}")
    return float(r.stdout.strip())


async def synth(text, out):
    for attempt in range(3):
        try:
            await edge_tts.Communicate(text, VOICE, rate=RATE).save(out)
            return
        except Exception as e:  # noqa: BLE001
            print(f"    retry {attempt + 1}: {e}", file=sys.stderr)
            await asyncio.sleep(2)
    raise RuntimeError(f"TTS 失败: {text[:20]}")


def count_chars(text):
    """有效字数：去掉标点与空白（标点不算发声字数，但会带来停顿）。"""
    return len(re.sub(r"[，。、？！；：,.;?!\s]", "", text))


async def measure(text):
    os.makedirs(CACHE, exist_ok=True)
    key = hashlib.md5(f"{VOICE}|{RATE}|{text}".encode("utf-8")).hexdigest()[:16]
    p = os.path.join(CACHE, f"{key}.mp3")
    if not os.path.exists(p):
        await synth(text, p)
    d = probe(p)
    return count_chars(text), d


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("texts", nargs="*", help="候选旁白文本")
    ap.add_argument("--file", help="从文件读候选，每行一条")
    ap.add_argument("--target", default="3.0-3.3",
                    help="目标语音秒数区间，默认 3.0-3.3")
    ap.add_argument("--gap", type=float, default=GAP, help="片头尾部留白，默认 0.30")
    a = ap.parse_args()

    texts = list(a.texts)
    if a.file:
        with open(a.file, encoding="utf-8") as f:
            texts += [ln.strip() for ln in f
                      if ln.strip() and not ln.strip().startswith("#")]
    if not texts:
        ap.error("请给至少一条候选文本（位置参数或 --file）")

    try:
        lo, hi = (float(x) for x in a.target.split("-"))
    except ValueError:
        ap.error("--target 格式应为 lo-hi，如 3.0-3.3")

    print(f"voice={VOICE} rate={RATE}  gap={a.gap}  目标语音 {lo}~{hi}s\n")
    print(f"{'#':<4}{'字数':>5}{'秒/字':>8}{'语音':>9}{'片头总长':>10}{'':>5}文本")
    hits = []
    for i, t in enumerate(texts, 1):
        n, d = await measure(t)
        ok = lo <= d <= hi
        if ok:
            hits.append((i, t, d))
        flag = "  ✅命中" if ok else ""
        print(f"{i:<4}{n:>5}{n / d:>7.2f}字/s{d:>8.2f}s{d + a.gap:>9.2f}s{flag}   {t}")

    print()
    if hits:
        print(f"命中 {lo}~{hi}s 的候选：")
        for i, t, d in hits:
            print(f"  #{i}  {d:.2f}s (片头 {d + a.gap:.2f}s)  {t}")
        print("\n→ 选定后写进 build_intro.py / gen_narration.py 的 intro 段，"
              f"片头 data-duration = {hits[0][2] + a.gap:.2f}")
    else:
        print(f"⚠ 没有候选落进 {lo}~{hi}s。→ 砍字（3.0~3.3s 对应 11~12 字），"
              f"或把完整日期改成短日期「9月16日」形式。")
        return

    # 附带提醒：日期形式的代价
    for i, t, d in hits:
        if re.search(r"\d{4}年|\d{1,2}月\d{1,2}日", t):
            print(f"  ⓘ #{i} 含日期读数：完整「YYYY年M月D日」约耗 1.9s，短写「M月D日」约 0.9s。")


if __name__ == "__main__":
    asyncio.run(main())
