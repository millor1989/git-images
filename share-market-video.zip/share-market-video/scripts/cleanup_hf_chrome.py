# -*- coding: utf-8 -*-
"""hyperframes 渲染收尾动作 —— 清理残留的 headless chrome 进程。

为什么要做这件事
----------------
hyperframes 起浏览器用的是 `@puppeteer/browsers`，它把子进程设成
`detached: true`（→ `DETACHED_PROCESS`），父进程退出后**子进程不会被回收**。
于是每次 `check` / `snapshot` / `render` / `preview` 跑完，都可能在系统里
留下若干孤儿 `chrome-headless-shell.exe`：

- 每个还占着一个 `127.0.0.1` 随机 CDP 端口 + 几十 MB 内存；
- 实测一次积了 **9 个**，最早的一个挂了一整天（三个孤儿主进程 +
  六个 gpu-process / network 子进程）；
- 下一轮渲染时这些陈旧的浏览器会让资源竞争变严重（本机 8.1 GB 内存）。

所以把它固定成**每次渲染的收尾动作**：渲完就跑一次，几十毫秒的事。

用法
----
从 Git Bash / PowerShell / cmd 都能调：

    python cleanup_hf_chrome.py                  # 扫描并清理（默认）
    python cleanup_hf_chrome.py --dry-run        # 只报告，不杀
    python cleanup_hf_chrome.py --all             # 连非 hyperframes 路径的 headless chrome 也清
    python cleanup_hf_chrome.py --include-node    # 连残留的 hyperframes node 进程（render/studio 孤儿）一起清
    python cleanup_hf_chrome.py --quiet           # 无残留时不输出
    python cleanup_hf_chrome.py --self-test       # 自检枚举功能（改过脚本后跑一次）

默认只杀**属于 hyperframes 的** `chrome-headless-shell.exe`（可执行文件路径或
命令行里含 `hyperframes` —— 沙箱子进程读不到路径，只靠命令行判定）；
加 `--all` 才不限归属、杀掉所有同类进程。

安全边界
--------
- **绝不碰 `node.exe`**，除非显式 `--include-node`；且即便开了，也只杀命令行
  里含 `hyperframes.mjs` 的（渲染 / studio 孤儿），**常驻的平台 MCP 服务
  （`sheetagent/.../mcp/start.mjs`、`weixinpay/.../mcp-server.mjs`）永远不动**。
- 只按进程名 + 路径判定，不做模糊匹配，不删任何文件。

退出码
------
0 = 执行完毕（本来就没残留，或残留已清干净）
1 = 运行环境不支持（非 Windows / 找不到 PowerShell）
2 = 清理后仍有残留（通常是权限不足）
"""
from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys

CHROME_NAME = "chrome-headless-shell.exe"
NODE_NAME = "node.exe"
HF_MARK = "hyperframes"          # 浏览器缓存路径里的标记
HF_CLI_MARK = "hyperframes.mjs"  # 渲染 / studio node 进程命令行的标记
# 常驻的平台 MCP 服务 —— 无论如何都不杀
MCP_MARKS = ("sheetagent", "weixinpay", "mcp/start.mjs", "mcp-server.mjs", "mcp\\start.mjs")


def _run_ps(script: str) -> tuple[int, str, str]:
    try:
        p = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True, text=True, timeout=120,
        )
    except FileNotFoundError:
        return 127, "", "找不到 powershell"
    except subprocess.TimeoutExpired:
        return 124, "", "powershell 超时"
    return p.returncode, p.stdout or "", p.stderr or ""


def _enum(name: str) -> list[dict]:
    """枚举指定映像名的进程 → [{pid, path, created, cmdline}]。"""
    # ⚠ 过滤器必须写成 Name='<名>' —— 拼字符串时漏掉闭合单引号会被
    #   $ErrorActionPreference='SilentlyContinue' 静默吞掉，表现为「永远返回空」，
    #   即「明明有残留却报无残留」。改这行务必用 _self_test() 验证。
    script = (
        "$ErrorActionPreference='SilentlyContinue';"
        "Get-CimInstance Win32_Process -Filter \"Name='" + name + "'\" | "
        "ForEach-Object { 'PROC|' + $_.ProcessId + '|' + $_.ExecutablePath + '|' + "
        "$_.CreationDate + '|' + $_.CommandLine }"
    )
    code, out, err = _run_ps(script)
    if code == 127:
        raise RuntimeError(err or "powershell 不可用")
    rows = []
    for line in out.splitlines():
        line = line.strip()
        if not line.startswith("PROC|"):
            continue
        parts = line.split("|", 4)
        if len(parts) < 5:
            continue
        _, pid, path, created, cmdline = parts
        try:
            pid_i = int(pid)
        except ValueError:
            continue
        rows.append({
            "pid": pid_i,
            "path": "" if path in ("", "None") else path,
            "created": "" if created in ("", "None") else created,
            "cmdline": "" if cmdline in ("", "None") else cmdline,
        })
    return rows


def _kill(pids: list[int]) -> None:
    if not pids:
        return
    ids = ",".join(str(p) for p in pids)
    _run_ps("Stop-Process -Id " + ids + " -Force -ErrorAction SilentlyContinue")


def _self_test() -> int:
    """自检：能否枚举到本进程。

    本脚本最危险的失效模式是「**静默返回空**」—— 枚举一旦坏掉（如过滤器引号拼错），
    它就永远报「无残留」，看起来一切正常、实际一个都没清。所以内置这个自检：
    枚举自身映像名，断言命中自己的 PID。
    """
    name = os.path.basename(sys.executable)
    me = os.getpid()
    try:
        rows = _enum(name)
    except RuntimeError as e:
        print(f"[self-test] ❌ 枚举失败：{e}")
        return 1
    hit = [r for r in rows if r["pid"] == me]
    if not hit:
        print(f"[self-test] ❌ 枚举 {name} 得到 {len(rows)} 条，但**未命中自身 PID {me}**"
              f" —— 枚举失效（检查 PowerShell 过滤器的引号是否闭合）")
        return 1
    if hit[0]["path"]:
        print(f"[self-test] ✅ 枚举正常：{name} {len(rows)} 条，命中自身 PID {me}，"
              f"ExecutablePath 可读")
        return 0
    print(f"[self-test] ⚠ 枚举命中自身 PID {me}，但 ExecutablePath 为空 —— "
          f"路径过滤会失效（残留会被归入 skipped 而不清理），请检查权限")
    return 0


def _is_hf(p: dict) -> bool:
    """是否属于 hyperframes 起的浏览器。

    优先看 `ExecutablePath`；**但它经常读不到** —— Chrome 的沙箱子进程
    （`--type=gpu-process` / `--type=utility`）会降权，WMI 返回空的
    ExecutablePath（实测同一批 5 个进程里有 2 个如此）。所以再加一层兜底：
    命令行里也带着 exe 的完整路径，`hyperframes` 标记同样能命中。
    """
    if p["path"] and HF_MARK in p["path"].lower():
        return True
    return HF_MARK in p["cmdline"].lower()


def _created_short(s: str) -> str:
    """把 WMI 的 CreationDate（20260916190849.500000+480，或 09/16/2026 19:35:33）压短。"""
    if len(s) >= 14 and s[:14].isdigit():
        return f"{s[4:6]}-{s[6:8]} {s[8:10]}:{s[10:12]}:{s[12:14]}"
    return s or "?"


def _kind(p: dict) -> str:
    """从命令行猜进程角色：主进程 / gpu-process / utility / renderer。"""
    m = re.search(r"--type=([A-Za-z\-]+)", p["cmdline"])
    if m:
        return f"  [{m.group(1)}]"
    return "  [主进程]" if p["cmdline"] else "  [?]"


def _is_mcp(cmdline: str) -> bool:
    low = cmdline.lower().replace("/", "\\")
    return any(m.lower().replace("/", "\\") in low for m in MCP_MARKS)


def main() -> int:
    ap = argparse.ArgumentParser(
        description="清理 hyperframes 残留的 headless chrome（渲染收尾动作）")
    ap.add_argument("--dry-run", action="store_true", help="只报告，不杀进程")
    ap.add_argument("--all", action="store_true",
                    help="不限路径：杀掉所有 chrome-headless-shell.exe（默认只杀路径含 hyperframes 的）")
    ap.add_argument("--include-node", action="store_true",
                    help="连带清理残留的 hyperframes node 进程（命令行含 hyperframes.mjs）")
    ap.add_argument("--quiet", action="store_true", help="无残留时不输出")
    ap.add_argument("--self-test", action="store_true",
                    help="自检枚举是否正常工作（断言能枚举到自身进程）")
    a = ap.parse_args()

    if a.self_test:
        return _self_test()

    if sys.platform != "win32":
        print("[cleanup] 非 Windows，跳过（hyperframes 残留问题只在 Windows 上出现）")
        return 0

    try:
        chromes = _enum(CHROME_NAME)
    except RuntimeError as e:
        print(f"[cleanup] 无法枚举进程：{e}")
        return 1

    targets, skipped = [], []
    for p in chromes:
        if a.all or _is_hf(p):
            targets.append(p)
        else:
            skipped.append(p)

    nodes = []
    if a.include_node:
        for p in _enum(NODE_NAME):
            if HF_CLI_MARK in p["cmdline"] and not _is_mcp(p["cmdline"]):
                nodes.append(p)

    if not targets and not nodes:
        if skipped:
            print(f"[cleanup] 未发现 hyperframes 残留；但系统里有 {len(skipped)} 个"
                  f"路径不含 hyperframes 的 headless chrome（未处理，如确需清掉加 --all）：")
            for p in skipped:
                print(f"           PID {p['pid']:<7} {p['path'] or '(路径不可读)'}")
        elif not a.quiet:
            print("[cleanup] ✅ 无残留 headless chrome / hyperframes node 进程")
        return 0

    if targets:
        print(f"[cleanup] 发现 {len(targets)} 个残留 chrome-headless-shell：")
        for p in targets:
            print(f"           PID {p['pid']:<7} 启动 {_created_short(p['created'])}"
                  f"{_kind(p)}")
            print(f"           {p['path'] or p['cmdline'][:120] or '(路径不可读)'}")
    if skipped:
        print(f"[cleanup] 另有 {len(skipped)} 个路径与命令行都不含 hyperframes（未处理，"
              f"如确需清掉加 --all）：")
        for p in skipped:
            print(f"           PID {p['pid']:<7} {p['path'] or '(路径不可读)'}")
    if nodes:
        print(f"[cleanup] 发现 {len(nodes)} 个残留 hyperframes node 进程：")
        for p in nodes:
            print(f"           PID {p['pid']:<7} {p['cmdline'][:110]}")

    if a.dry_run:
        print("[cleanup] --dry-run：未做任何改动")
        return 0

    pids = [p["pid"] for p in targets] + [p["pid"] for p in nodes]
    _kill(pids)
    print(f"[cleanup] 已终止 {len(pids)} 个进程")

    left = [p for p in _enum(CHROME_NAME) if a.all or _is_hf(p)]
    if left:
        print(f"[cleanup] ⚠ 仍有 {len(left)} 个残留（可能权限不足）："
              + "、".join(str(p["pid"]) for p in left))
        return 2
    print("[cleanup] ✅ chrome-headless-shell 残留已清零")
    return 0


if __name__ == "__main__":
    sys.exit(main())
