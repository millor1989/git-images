#!/usr/bin/env node
/**
 * wrap_probe.mjs — 「折行 / 水平溢出」探针（渲染前必跑，秒级）。
 *
 * 为什么需要：卡片文案有硬宽度上限（见 SKILL「卡片文案硬宽度上限」一节），
 *   超一个字就掉行，而掉行**不会**被 seek_pages.mjs 的底部越界判据抓到
 *   （卡本身是 flex 自适应高度，折行只是把卡撑高 —— 只要没越过 1620 就"通过"）。
 *   所以折行必须单独量：按**视觉行数**判定。
 *
 * 判定方式：
 *   · 折行   —— Range.getClientRects() 按 top 归并出的视觉行数 ≥ 2
 *   · 溢出   —— scrollWidth > clientWidth + 1（文字戳出容器）
 *
 * 用法（工程根目录）：
 *   node qa/wrap_probe.mjs sec1 18.0 33.0
 *   退出码：0 通过 / 4 有折行或溢出
 */
import { createRequire } from "node:module";
import { spawn } from "node:child_process";
import fs from "node:fs";
import http from "node:http";
import os from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";

// ws 模块所在目录（hyperframes 的 npx 缓存）——**不要写死**：npx 缓存 hash 会变。
// 解析顺序：环境变量 WS_BASE → ~/.workbuddy 与 ~/.npm 下的通配查找。
function findWsBase() {
  const roots = [
    path.join(os.homedir(), ".workbuddy", "tmp", "npm-cache", "_npx"),
    path.join(os.homedir(), ".npm", "_npx"),
  ];
  if (process.env.LOCALAPPDATA) {
    roots.push(path.join(process.env.LOCALAPPDATA, "npm-cache", "_npx"));
  }
  for (const root of roots) {
    let dirs = [];
    try { dirs = fs.readdirSync(root).sort(); } catch { continue; }
    for (const d of dirs) {
      const nm = path.join(root, d, "node_modules");
      if (fs.existsSync(path.join(nm, "ws"))) return nm;
    }
  }
  return null;
}

const WS_BASE = process.env.WS_BASE || findWsBase();
if (!WS_BASE) {
  console.error("未找到 ws 模块目录：请设 WS_BASE 指向含 ws 的 node_modules"
    + "（如 ~/.workbuddy/tmp/npm-cache/_npx/<hash>/node_modules）");
  process.exit(1);
}
const require = createRequire(pathToFileURL(path.join(WS_BASE, "anchor.js")).href);
const WebSocket = require("ws");

const CHROME = process.env.HYPERFRAMES_BROWSER_PATH;
if (!CHROME) { console.error("请设置 HYPERFRAMES_BROWSER_PATH"); process.exit(1); }

const SEC = process.argv[2] || "sec1";
const TIMES = (process.argv.slice(3).length ? process.argv.slice(3) : ["18"]).map(Number);

const CWD = process.cwd();
const URL_ = pathToFileURL(path.join(CWD, "index.html")).href;
const PORT = Number(process.env.PROBE_PORT || 9351);

const proc = spawn(CHROME, [
  `--remote-debugging-port=${PORT}`, "--headless=new", "--no-sandbox",
  "--disable-gpu", "--window-size=1080,1920", "about:blank",
], { stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function getJson(p) {
  return new Promise((resolve, reject) => {
    http.get({ host: "127.0.0.1", port: PORT, path: p }, (res) => {
      let d = ""; res.on("data", (c) => (d += c));
      res.on("end", () => { try { resolve(JSON.parse(d)); } catch (e) { reject(e); } });
    }).on("error", reject);
  });
}

let targets;
for (let i = 0; i < 60; i++) {
  try { targets = await getJson("/json/list"); if (targets?.length) break; } catch {}
  await sleep(500);
}
if (!targets?.length) { console.error("chrome 未就绪"); process.exit(1); }

const socket = new WebSocket(targets.find((t) => t.type === "page").webSocketDebuggerUrl);
let id = 0; const pending = new Map();
socket.on("message", (raw) => {
  const m = JSON.parse(raw);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
});
const send = (method, params = {}) => new Promise((res) => {
  const i = ++id; pending.set(i, res);
  socket.send(JSON.stringify({ id: i, method, params }));
});

await new Promise((r) => socket.on("open", r));
await send("Page.enable");
await send("Page.addScriptToEvaluateOnNewDocument", { source: "window.__timelines = {};" });
await send("Page.navigate", { url: URL_ });
await sleep(5000);

const SEL = [
  ".pc-title", ".pc-badge", ".pg-lead",
  ".pcn", ".pcv", ".pcs",
  ".idx-name", ".idx-val", ".idx-pct", ".idx-note",
  ".intro-hook-main", ".intro-note", ".intro-sub",
];

const expr = (t) => `(() => {
  const tl = (window.__timelines && window.__timelines["main"]);
  if (!tl) return JSON.stringify({ err: "NO_TIMELINE" });
  tl.pause(); tl.time(${t});
  const sec = document.getElementById("${SEC}");
  if (!sec) return JSON.stringify({ err: "NO_SECTION" });
  const linesOf = (el) => {
    const rg = document.createRange();
    rg.selectNodeContents(el);
    const tops = [];
    for (const r of rg.getClientRects()) {
      if (r.width < 0.5 || r.height < 0.5) continue;
      if (!tops.some((y) => Math.abs(y - r.top) < 5)) tops.push(r.top);
    }
    return tops.length;
  };
  const out = [];
  // ★ 2026-09-29 修补：原实现只扫 .page 子元素，片头（intro-hook）根本没有 .page，
  //   导致 .intro-note / .intro-hook-main 的折行永远不会被量到 —— 09-29 期片头注解
  //   就因此带着一个「领涨」孤字折行渲染了出去。此处若无 .page（片头/片尾类
  //   非卡片段落）则把 section 本身当作扫描范围。
  const scopes = [...sec.querySelectorAll(".page")];
  if (!scopes.length) scopes.push(sec);
  scopes.forEach((p, pi) => {
    if (+getComputedStyle(p).opacity < 0.5) return;
    for (const sel of ${JSON.stringify(SEL)}) {
      for (const el of p.querySelectorAll(sel)) {
        const txt = (el.textContent || "").trim();
        if (!txt) continue;
        // ★ 2026-09-29 修补：flex + nowrap 容器（如片头主线「名称+三角+涨跌幅」）
        //   按 Range.getClientRects() 数行会因各子项字号不同 / baseline 对齐而
        //   误报多行（实测把单行的主线报成 4 行）。nowrap 的 flex 行在水平方向
        //   不可能折行，只可能水平溢出 —— 所以此类容器只做溢出判据。
        const cs = getComputedStyle(el);
        const nowrapFlex = cs.display.includes("flex") && cs.flexWrap === "nowrap";
        const n = nowrapFlex ? 1 : linesOf(el);
        const ovf = el.scrollWidth > el.clientWidth + 1;
        if ((!nowrapFlex && n >= 2) || ovf) {
          out.push({ pi, sel, txt: txt.slice(0, 34), lines: n, ovf });
        }
      }
    }
  });
  return JSON.stringify({ bad: out });
})()`;

let bad = 0;
console.log(`===== ${SEC}  采样 ${TIMES.join(", ")} =====`);
for (const t of TIMES) {
  const r = await send("Runtime.evaluate", { expression: expr(t), returnByValue: true });
  const v = r.result?.result?.value;
  if (!v) { console.log(`t=${t}  EVAL_ERR`); continue; }
  const parsed = JSON.parse(v);
  if (parsed.err) { console.log(`t=${t}  ${parsed.err}`); continue; }
  if (!parsed.bad.length) { console.log(`  t=${t}  OK 无折行 / 无溢出`); continue; }
  for (const b of parsed.bad) {
    bad++;
    console.log(`  t=${t}  !! p${b.pi} ${b.sel}  行数=${b.lines}${b.ovf ? " 且水平溢出" : ""}  「${b.txt}」`);
  }
}
console.log(bad ? `\n!! ${SEC} 共 ${bad} 处折行/溢出 —— 必须改文案宽度后再渲染`
                : `\nOK ${SEC} 无折行 / 无溢出`);
socket.close(); proc.kill(); process.exit(bad ? 4 : 0);
