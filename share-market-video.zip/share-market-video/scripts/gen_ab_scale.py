# -*- coding: utf-8 -*-
"""DATE_SCALE A/B 对照图（intro-lab 一次性工具）。

把两个 snap 目录的 t=0 首帧并排，直观看日期放大态的相对大小：
    python gen_ab_scale.py snap4 1.45 snap5 1.25
"""
import os
import sys

from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
W, H, BAR = 540, 960, 34


def main():
    a_dir, a_lab, b_dir, b_lab = sys.argv[1:5]
    a = Image.open(os.path.join(HERE, a_dir, "frame-00-at-0s.png")).convert("RGB")
    b = Image.open(os.path.join(HERE, b_dir, "frame-00-at-0s.png")).convert("RGB")
    sheet = Image.new("RGB", (W * 2, H + BAR), (10, 14, 22))
    sheet.paste(a.resize((W, H), Image.LANCZOS), (0, BAR))
    sheet.paste(b.resize((W, H), Image.LANCZOS), (W, BAR))
    d = ImageDraw.Draw(sheet)
    d.text((12, 11), f"DATE_SCALE {a_lab}  (t=0)", fill=(0, 212, 255))
    d.text((W + 12, 11), f"DATE_SCALE {b_lab}  (t=0)", fill=(0, 212, 255))
    d.line([(W, 0), (W, H + BAR)], fill=(60, 70, 85), width=2)
    out = os.path.join(HERE, "ab-date-scale.png")
    sheet.save(out)
    print(f"A/B 对照 -> {out}")


if __name__ == "__main__":
    main()
