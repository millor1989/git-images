# -*- coding: utf-8 -*-
"""片头「动效层次」像素级验收（intro-lab）。

验三件事：
  1. 日期行颜色 = 纯白（≈ #ffffff）
  2. 日期行宽度随时间**收缩**（由大变小），且 t=0.75s 仍是放大态
     —— 即「核心内容先动、日期后动」的层次真的成立
  3. 核心行（主线下落）在 0.0→0.3s 之间发生明显位移

用法（在工程目录下跑）：
    python qa_intro_layers.py [snap_dir]     # 默认 snap4，相对当前目录解析
"""
import os
import sys

from PIL import Image, ImageDraw

_arg = sys.argv[1] if len(sys.argv) > 1 else "snap4"
SNAP = _arg if os.path.isabs(_arg) else os.path.join(os.getcwd(), _arg)
OUTDIR = os.getcwd()
THRESH = 110          # 文字亮度阈值（深底白字）


def bands(img, top=0, bottom=None, min_px=6):
    """返回自上而下的「文字带」列表 [(y0, y1, x0, x1, mean_rgb)]。"""
    w, h = img.size
    bottom = bottom or h
    px = img.convert("RGB").load()
    rows = []
    for y in range(top, bottom):
        xs = [x for x in range(w) if max(px[x, y]) > THRESH]
        rows.append(xs)
    out, cur = [], None
    for i, xs in enumerate(rows):
        if len(xs) >= min_px:
            if cur is None:
                cur = [i, i, xs]
            else:
                cur[1] = i
                cur[2] += xs
        else:
            if cur is not None and cur[1] - cur[0] >= 3:
                out.append(cur)
            cur = None
    if cur is not None and cur[1] - cur[0] >= 3:
        out.append(cur)
    res = []
    for y0, y1, xs in out:
        cols = [px[x, y] for x in xs]
        n = len(cols)
        res.append((y0, y1, min(xs), max(xs),
                    tuple(sum(c[i] for c in cols) // n for i in range(3))))
    return res


def sharpest_color(img, y0, y1):
    """带宽内「最亮」像素的色值 —— 抗抗锯齿，取字芯颜色。"""
    px = img.convert("RGB").load()
    w, _ = img.size
    best, bv = None, -1
    for y in range(y0, y1 + 1):
        for x in range(w):
            c = px[x, y]
            v = sum(c)
            if v > bv:
                bv, best = v, c
    return best


def main():
    frames = sorted(f for f in os.listdir(SNAP) if f.endswith(".png") and f.startswith("frame-"))
    if not frames:
        raise SystemExit(f"[error] {SNAP} 里没有 frame-*.png")
    print(f"{'时刻':<8}{'日期行宽':>10}{'日期高':>8}{'日期字芯':>12}{'核心行y':>10}{'日期底y':>10}")
    print("-" * 62)
    rows_out = []
    for fn in frames:
        t = fn.split("-at-")[-1].replace("s.png", "")
        img = Image.open(os.path.join(SNAP, fn))
        bs = bands(img, top=0, bottom=img.size[1] // 2)
        if len(bs) < 2:
            print(f"{t:<8}  [warn] 只识别到 {len(bs)} 个文字带")
            continue
        d = bs[0]                                  # 最上方 = 日期行
        core = bs[2] if len(bs) > 2 else bs[-1]     # 核心行（日期/线/核心/概述）
        wid = d[3] - d[2]
        col = sharpest_color(img, d[0], d[1])
        rows_out.append((t, wid, col))
        print(f"{t:<8}{wid:>10}{d[1]-d[0]:>8}{str(col):>12}{core[0]:>10}{d[1]:>10}")

    if len(rows_out) >= 2:
        w0, wl = rows_out[0][1], rows_out[-1][1]
        print("-" * 62)
        print(f"日期行宽 {w0}px (t={rows_out[0][0]}) → {wl}px (t={rows_out[-1][0]})"
              f"  收缩 {w0 - wl}px / {w0/max(wl,1):.2f}×")
        c = rows_out[-1][2]
        ok = min(c) > 220
        print(f"日期落位色 {c} → {'✅ 纯白' if ok else '❌ 非白（仍偏灰）'}")

    # 对照图：把 6 帧日期行局部竖排拼一张，直接看收缩
    imgs = [Image.open(os.path.join(SNAP, f)) for f in frames]
    crop_w, crop_h = 1080, 150
    sheet = Image.new("RGB", (crop_w, crop_h * len(imgs)), (10, 14, 22))
    dr = ImageDraw.Draw(sheet)
    for i, (im, fn) in enumerate(zip(imgs, frames)):
        t = fn.split("-at-")[-1].replace("s.png", "")
        bs = bands(im, top=0, bottom=im.size[1] // 2)
        if not bs:
            continue
        y0, y1 = bs[0][0], bs[0][1]
        top = max(0, y0 - 22)
        sheet.paste(im.crop((0, top, crop_w, top + crop_h)), (0, i * crop_h))
        dr.text((14, i * crop_h + 6), f"t={t}", fill=(0, 212, 255))
    out = os.path.join(OUTDIR, "qa-layers-date-row.png")
    sheet.save(out)
    print(f"\n日期行逐帧对照 -> {out}")


if __name__ == "__main__":
    main()
