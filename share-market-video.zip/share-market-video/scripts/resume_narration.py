# -*- coding: utf-8 -*-
"""断点续跑：只补合成缺失/损坏的 seg_*.mp3，然后重新拼装 narration。

edge-tts 偶发 wss 连接超时（2026-09-23 实测：outro 连挂 3 次重试，
整脚本退化成 RuntimeError）。此时前几段其实已经合成好了，
重跑整个 gen_narration.py 要重合成全部 6 段（约 4 分钟）且可能再撞上抖动。

本脚本复用 gen_narration.py 的 SEGMENTS / 常量 / synthesize / probe_duration，
把已存在且体积达标的段直接跳过，只补缺失的，最后按同一规则重新拼装
（segments.json + assets/narration-v1.mp3）。

用法（在 audio/ 目录下）：
    # Git Bash 需先 export FFMPEG / FFPROBE 指向真实可执行文件
    python resume_narration.py
"""
import asyncio
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import gen_narration as G  # noqa: E402  （SEGMENTS / GAP / VOICE / RATE 复用）

MIN_BYTES = 2000  # 小于这个体积基本是空壳/半截文件


async def main() -> None:
    if not G.FFMPEG or not G.FFPROBE:
        print("[error] 找不到 ffmpeg/ffprobe（先 export FFMPEG / FFPROBE）",
              file=sys.stderr)
        sys.exit(1)

    durations = {}
    for name, text in G.SEGMENTS:
        p = os.path.join(HERE, f"seg_{name}.mp3")
        if os.path.exists(p) and os.path.getsize(p) >= MIN_BYTES:
            durations[name] = G.probe_duration(p)
            print(f"[keep]  {name:6s} {durations[name]:6.2f}s  (已存在，跳过)")
            continue
        print(f"[synth] {name} ...（缺失/损坏，重合成）")
        await G.synthesize(name, text, p)
        durations[name] = G.probe_duration(p)
        print(f"        {name}: {durations[name]:.2f}s")

    timeline = []
    start = 0.0
    for name, _ in G.SEGMENTS:
        d = durations[name]
        timeline.append({"name": name, "start": round(start, 3),
                         "duration": round(d + G.GAP, 3)})
        start += d + G.GAP
    total = round(start, 3)

    inputs = []
    for name, _ in G.SEGMENTS:
        inputs += ["-i", os.path.join(HERE, f"seg_{name}.mp3")]
    parts = [f"[{i}]apad=pad_dur={G.GAP}[a{i}]" for i in range(len(G.SEGMENTS))]
    parts.append("".join(f"[a{i}]" for i in range(len(G.SEGMENTS)))
                 + f"concat=n={len(G.SEGMENTS)}:v=0:a=1[out]")
    narration = os.path.join(HERE, "narration.mp3")
    print("[mux] concat narration ...")
    subprocess.run([G.FFMPEG, "-y", *inputs, "-filter_complex", ";".join(parts),
                    "-map", "[out]", "-c:a", "libmp3lame", "-b:a", "128k",
                    narration], capture_output=True, text=True, check=True)
    dst = os.path.join(HERE, "..", "assets", "narration-v1.mp3")
    shutil.copy2(narration, dst)

    with open(os.path.join(HERE, "segments.json"), "w", encoding="utf-8") as f:
        json.dump({"total": total, "gap": G.GAP, "voice": G.VOICE,
                   "rate": G.RATE, "segments": timeline}, f,
                  ensure_ascii=False, indent=2)

    print("\n===== TIMELINE =====")
    print(f"total = {total:.2f}s")
    for t in timeline:
        print(f"{t['name']:6s}  start={t['start']:7.2f}  dur={t['duration']:6.2f}")
    print(f"narration -> {os.path.abspath(dst)}")


if __name__ == "__main__":
    asyncio.run(main())
