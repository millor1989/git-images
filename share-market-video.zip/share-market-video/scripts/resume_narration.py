# -*- coding: utf-8 -*-
"""断点续跑：只补合成缺失 / 损坏的 seg_*.mp3，然后重新拼装 narration。

什么时候需要它
--------------
TTS 偶尔会中途挂掉（2026-09-23 实测：outro 连挂 3 次重试，整脚本退化成
RuntimeError；2026-10-12 之后 edge-tts 新端点还多一个 **429 限流**的死法）。
此时前面几段其实已经合成好了，重跑整个 `gen_narration.py` 要重合成全部段
（数分钟）且可能再撞上同样的抖动。

本脚本只是 `gen_narration.py --resume` 的薄壳，**复用**它的 `SEGMENTS` /
引擎链 / `parts_dur` / `concat_parts` / 时间轴与 `page_breaks` 计算 ——
两边的分段规则永远一致，不会漂移。

用法（在 audio/ 目录下）：
    # Git Bash 需先 export FFMPEG / FFPROBE 指向真实可执行文件
    python resume_narration.py

判据：已存在且**体积达标 + ffprobe 量得到时长**的段直接跳过；否则重合成。
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import gen_narration as G  # noqa: E402  （SEGMENTS / 常量 / run 复用）


if __name__ == "__main__":
    print(f"[resume] 复用 {os.path.basename(G.__file__)}"
          f"（engine={G.ENGINE}，{len(G.SEGMENTS)} 段）")
    sys.exit(G.run(resume=True))
