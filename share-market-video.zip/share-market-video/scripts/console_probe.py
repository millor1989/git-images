# -*- coding: utf-8 -*-
"""Windows 控制台窗口探针 —— 查「谁弹了黑框」。

背景
----
hyperframes 每次渲染 / 刷新 studio 都会弹出若干 `chrome-headless-shell.exe`
命令行窗口。原因是 Windows `CreateProcess` 的
`CREATE_NO_WINDOW`（Node 的 `windowsHide: true`）**在同时给了
`DETACHED_PROCESS`（`detached: true`）时会被系统忽略**（MSDN 明文），
而 `chrome-headless-shell.exe` 又是 CONSOLE 子系统、且 `DETACHED_PROCESS`
不继承父控制台 → 系统给它新分配一个可见控制台窗口。

本探针用 `EnumWindows` 枚举顶层窗口，挑出类名为 `ConsoleWindowClass`
的可见窗口，再查出它属于哪个进程 —— 于是「弹了几个黑框、是谁弹的」
变成可测量的数字，可用于打补丁前后的 A/B 对比。

用法
----
    python console_probe.py                      # 静默观察 20 秒
    python console_probe.py --seconds 60
    python console_probe.py --only chrome         # 只关心含该关键字的进程

输出：周期性采样行 + 末尾汇总（峰值个数、涉及进程、出现的窗口标题）。
"""
from __future__ import annotations

import argparse
import ctypes
import subprocess
import sys
import time
from ctypes import wintypes

u32 = ctypes.WinDLL("user32", use_last_error=True)
k32 = ctypes.WinDLL("kernel32", use_last_error=True)

WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
CONSOLE_CLASS = "ConsoleWindowClass"

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


def _pid_image(pid: int) -> str:
    """取进程映像名（失败返回空串）。"""
    h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return ""
    try:
        size = wintypes.DWORD(1024)
        buf = ctypes.create_unicode_buffer(size.value)
        if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return buf.value.rsplit("\\", 1)[-1]
        return ""
    finally:
        k32.CloseHandle(h)


def console_windows() -> list[tuple[int, str, str]]:
    """返回所有「可见的控制台窗口」：(pid, 映像名, 标题)。"""
    found: list[tuple[int, str, str]] = []

    def cb(hwnd, _lparam):
        if not u32.IsWindowVisible(hwnd):
            return True
        cls = ctypes.create_unicode_buffer(256)
        if not u32.GetClassNameW(hwnd, cls, 256) or cls.value != CONSOLE_CLASS:
            return True
        pid = wintypes.DWORD()
        u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        title = ctypes.create_unicode_buffer(512)
        u32.GetWindowTextW(hwnd, title, 512)
        found.append((pid.value, _pid_image(pid.value), title.value))
        return True

    u32.EnumWindows(WNDENUMPROC(cb), 0)
    return found


def main() -> None:
    if sys.platform != "win32":
        print("[error] 仅 Windows 可用", file=sys.stderr)
        sys.exit(1)

    ap = argparse.ArgumentParser(description="统计弹出的控制台黑框")
    ap.add_argument("--seconds", type=float, default=20.0, help="观察时长（秒）")
    ap.add_argument("--interval", type=float, default=0.5, help="采样间隔（秒）")
    ap.add_argument("--only", default="", help="只看映像名含该关键字的进程")
    ap.add_argument("--quiet", action="store_true", help="只打印汇总")
    a = ap.parse_args()

    t0 = time.time()
    peak = 0
    peak_at = 0.0
    seen_pids: dict[int, str] = {}
    seen_titles: set[str] = set()
    samples = 0

    while time.time() - t0 < a.seconds:
        wins = console_windows()
        if a.only:
            wins = [w for w in wins if a.only.lower() in w[1].lower()]
        n = len(wins)
        samples += 1
        for pid, img, title in wins:
            seen_pids[pid] = img
            if title:
                seen_titles.add(title)
        if n > peak:
            peak, peak_at = n, time.time() - t0
        if not a.quiet:
            who = ",".join(sorted({w[1] + "#" + str(w[0]) for w in wins})) or "-"
            print(f"[{time.time() - t0:6.1f}s] 控制台窗口 {n} 个  {who}")
        time.sleep(a.interval)

    print("\n===== 汇总 =====")
    print(f"观察时长 {time.time() - t0:.1f}s，采样 {samples} 次")
    print(f"**峰值可见控制台窗口：{peak} 个**（第 {peak_at:.1f}s）")
    if seen_pids:
        for pid, img in sorted(seen_pids.items()):
            print(f"  弹窗进程  pid={pid}  {img}")
    else:
        print("  观察期内没有任何可见控制台窗口 ✅")
    if seen_titles:
        for t in sorted(seen_titles):
            print(f"  窗口标题  {t!r}")
    sys.exit(0 if peak == 0 else 3)


if __name__ == "__main__":
    main()
