# -*- coding: utf-8 -*-
"""找出每个板块内的「换页候选点」—— 用实测停顿定位，不靠字数估算。

原理：edge-tts 在句号/分号处会真的留出停顿，用 ffmpeg silencedetect 量出来，
取段内最长的几处作为换页点，就能在不重跑 TTS、不动 segments.json 的前提下
把一段长旁白切成多屏。

用法（在工程根目录下跑，或显式给 --project）：
    python <SKILL>/scripts/page_breaks.py                      # 每段 2 个候选（拆 3 屏）
    python <SKILL>/scripts/page_breaks.py --per-sec 1          # 每段 1 个候选（拆 2 屏）
    python <SKILL>/scripts/page_breaks.py --sections sec1      # 只分析某段
    python <SKILL>/scripts/page_breaks.py --sections all --json # 输出 JSON 供生成器直接读
    python <SKILL>/scripts/page_breaks.py --project <PROJ>     # 不在工程目录时指定根目录

依赖解析（都不写死机器路径）：
    ffmpeg   CLI --ffmpeg > 环境变量 FFMPEG > <PROJ>/env.json > PATH
    旁白     CLI --narration > <PROJ>/assets 下最新的 narration*.mp3
             （自动认版本名，配合「音频改内容必换 -vN 文件名」的约定）
    段表     <PROJ>/audio/segments.json

输出：
    各段停顿表 + 候选换页点（绝对时刻 / 段内相对秒 / 归一化占比 / 停顿时长）

⚠️ 最后一步必须人工校对：最长停顿「通常」等于内容分组边界，但不总是。
   实例：sec4 最长的是导语句末的 0.63s，但语义上该句应与「加密」同屏，
   真正该切的是第 3 长的 0.61s（中概 → 科技）。所以脚本给候选，人来定夺。
   另：改过旁白后必须对新音频重跑本脚本，不要拿旧值做算术平移（实测能差 0.03s）。
"""
import argparse
import io
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()          # 工程根目录；用 --project 覆盖。脚本装在 skill/scripts/ 下，
                           # 所以绝不能拿 __file__ 反推工程位置。


def _resolve_ffmpeg(explicit: str | None = None) -> str:
    """ffmpeg 路径优先级：CLI 参数 > FFMPEG 环境变量 > 工程 env.json > PATH。

    别把机器绝对路径硬编码进来 —— 换机就跑不动了。
    """
    import os
    import shutil
    if explicit:
        return explicit
    if os.environ.get("FFMPEG"):
        return os.environ["FFMPEG"]
    env_json = ROOT / "env.json"
    if env_json.exists():
        try:
            data = json.loads(env_json.read_text(encoding="utf-8"))
            for key in ("ffmpeg", "ffmpeg_path"):
                v = data.get(key) or (data.get("tools") or {}).get(key)
                if v and Path(v).exists():
                    return v
        except Exception:
            pass
    return shutil.which("ffmpeg") or "ffmpeg"


def _find_narration(explicit: str | None = None) -> Path:
    """找旁白整段 mp3。默认取 assets/ 下最新修改的 narration*.mp3。

    为什么要「找」而不是写死：音频内容一改就必须换文件名跟版本号（防止
    studio/浏览器按 URL 命中旧缓存），所以 assets/ 里可能躺着 narration-v2.mp3
    这类带版本后缀的文件，写死 narration.mp3 会一直分析到过期的那一份。
    """
    if explicit:
        return Path(explicit)
    cands = sorted(
        (ROOT / "assets").glob("narration*.mp3"),
        key=lambda p: p.stat().st_mtime, reverse=True)
    return cands[0] if cands else ROOT / "assets" / "narration.mp3"


NARRATION = None      # main() 里按 --project / --narration 解析
SEGMENTS = None

NOISE_DB = -40.0      # 静音判定阈值
MIN_DUR = 0.12        # 最短静音时长
SENT_DUR = 0.28       # 视为「句级停顿」的门槛


def detect_pauses(ffmpeg: str, audio: Path, noise_db: float, min_dur: float):
    """返回 [(start, end, duration), ...]，单位秒。"""
    p = subprocess.run(
        [ffmpeg, "-i", str(audio), "-af",
         f"silencedetect=noise={noise_db}dB:d={min_dur}", "-f", "null", "-"],
        capture_output=True, text=True, errors="replace")
    txt = (p.stdout or "") + (p.stderr or "")
    found = re.findall(
        r"silence_start: ([0-9.]+).*?silence_end: ([0-9.]+) \| silence_duration: ([0-9.]+)",
        txt, re.S)
    return [(float(a), float(b), float(d)) for a, b, d in found]


def main() -> int:
    global ROOT, NARRATION, SEGMENTS
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default=None, help="工程根目录（默认 = 当前工作目录）")
    ap.add_argument("--sections", default="sec2,sec3,sec4",
                    help="要分析的段名，逗号分隔；all = segments.json 里除 intro/outro 外全部")
    ap.add_argument("--per-sec", type=int, default=2, help="每段取几个换页候选")
    ap.add_argument("--sent-dur", type=float, default=SENT_DUR, help="句级停顿门槛(秒)")
    ap.add_argument("--ffmpeg", default=None, help="ffmpeg 路径（默认自动解析）")
    ap.add_argument("--narration", default=None, help="旁白 mp3（默认取 assets/ 下最新的 narration*.mp3）")
    ap.add_argument("--json", action="store_true", help="输出 JSON（供 build_index 直接读）")
    args = ap.parse_args()

    if args.project:
        ROOT = Path(args.project).resolve()
    SEGMENTS = ROOT / "audio" / "segments.json"
    narration = _find_narration(args.narration)
    if not narration.exists():
        print(f"[error] 找不到 {narration}", file=sys.stderr)
        return 1
    ffmpeg = _resolve_ffmpeg(args.ffmpeg)

    segs = json.load(io.open(SEGMENTS, encoding="utf-8"))["segments"]
    if args.sections.strip() == "all":
        want = [s["name"] for s in segs if s["name"] not in ("intro", "outro")]
    else:
        want = [x.strip() for x in args.sections.split(",") if x.strip()]

    pauses = detect_pauses(ffmpeg, narration, NOISE_DB, MIN_DUR)

    result = {}
    for s in segs:
        name = s["name"]
        if name not in want:
            continue
        a, dur = s["start"], s["duration"]
        inner = [(st - a, st - a, d) for st, en, d in pauses
                 if st >= a - 0.05 and en <= a + dur + 0.05]
        sent = [x for x in inner if x[2] >= args.sent_dur]
        # 候选：按停顿时长降序取前 N，再按时间排序
        cand = sorted(sorted(sent, key=lambda x: -x[2])[:args.per_sec],
                      key=lambda x: x[0])

        if not args.json:
            print(f"\n===== {name}  {a:.2f} → {a + dur:.2f}  ({dur:.2f}s) =====")
            print(f"  段内停顿 {len(inner)} 处；句级(≥{args.sent_dur}s) {len(sent)} 处")
            print(f"  {'段内秒':>8} {'绝对秒':>9} {'占比':>7} {'停顿':>6}   标记")
            for rel, abs_t, d in inner:
                mark = ""
                if any(abs(x[0] - rel) < 1e-6 for x in cand):
                    mark = "  <== 候选换页点"
                elif d >= args.sent_dur:
                    mark = "  (句级)"
                print(f"  {rel:>8.2f} {abs_t + a:>9.2f} {rel / dur:>7.3f} {d:>5.2f}s{mark}")
            print("  候选：" + ", ".join(
                f"+{rel:.2f}s(绝对{abs_t + a:.2f}, 停顿{d:.2f}s)" for rel, abs_t, d in cand))

        result[name] = {
            "start": a, "duration": dur,
            "breaks": [{"rel": round(rel, 3), "abs": round(abs_t + a, 3),
                        "frac": round(rel / dur, 4), "pause": d} for rel, abs_t, d in cand],
            "pause_count": len(inner),
            "sentence_pauses": len(sent),
        }

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=1))
    else:
        print("\n⚠️  候选只是「最长停顿」，最终切点还需按语义分组校对。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
