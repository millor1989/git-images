# -*- coding: utf-8 -*-
"""把旁白稿导出成可读的 markdown「播音稿」文档。

为什么需要这个脚本：旁白正文**只存在于** `<PROJ>/audio/gen_narration.py` 的
`SEGMENTS` 常量里（那是唯一真源，改文案＝改它），工程里从来没有单独的播音稿
文件。要给人看稿子时，临时从代码里翻很不方便，所以统一由本脚本导出。

实现要点：用 `ast` **静态解析** `SEGMENTS`（不 import 模块 —— 一 import 就会
拉起 edge_tts，慢且可能因缺依赖直接失败）；实际时长一律取 `segments.json`
里的**实测值**，不按字数估算。

用法（在工程根目录下跑，或显式给 --project）：
    python export_narration.py                       # 输出 <PROJ>/narration-script-<日期>.md
    python export_narration.py --project <PROJ>
    python export_narration.py --out 播音稿.md        # 相对 --project 或绝对路径
    python export_narration.py --stdout              # 只打印，不落盘

日期取自 `data/market-YYYYMMDD.md`（本技能的约定文件名），找不到则用今天。
"""
import argparse
import ast
import datetime as _dt
import json
import re
import sys
from pathlib import Path

# a-share 新结构（2026-09-24 用户重订）：5 板块 = 大盘 / 概述 / A股综述 /
# 港股综述 / 日韩综述；**概述找不到跨市场共性时整段省略 → 段名跳过 sec2**（不顺移）。
A_SHARE_LABELS = {
    "intro": "片头",
    "sec1": "大盘",
    "sec2": "概述",
    "sec3": "A股综述",
    "sec4": "港股综述",
    "sec5": "日韩综述",
    "sec6": "其他",
    "outro": "片尾 · CTA",
}

# us 模式固定 4 段（2026-09-18 定）：sec1 大盘 / sec2 当日主线 / sec3 龙头与中概
# / sec4 承压的一面。除非用户明确要求精简，不要压成 2 段。
US_LABELS = {
    "intro": "片头",
    "sec1": "美股大盘",
    "sec2": "当日主线",
    "sec3": "龙头与中概",
    "sec4": "承压的一面",
    "outro": "片尾 · CTA",
}

# 各段真实标题（可直接读生成器里写的主题，比默认标签准）。
# 优先取 index.html 里 `id="secN-title"` 的文本 —— 生成器改标题时本文件自动跟上，
# 不用两边各维护一份（2026-09-18 修：原先只有一套 A股 LABELS，做美股视频时
# 段名被错标成「A股大盘 / 港股行情」）。
_TITLE_RE = re.compile(
    r'id="(sec\d)-title"[^>]*>\s*<span[^>]*>(.*?)</span>', re.S)


def resolve_labels(proj: Path) -> dict[str, str]:
    """段名映射：index.html 的真实标题 > 模式默认标签。"""
    is_us = "us" in proj.name.lower().split("-")
    labels = dict(US_LABELS if is_us else A_SHARE_LABELS)
    idx = proj / "index.html"
    if idx.exists():
        html = idx.read_text(encoding="utf-8", errors="replace")
        for sec, raw in _TITLE_RE.findall(html):
            txt = re.sub(r"<[^>]+>", "", raw)
            txt = re.sub(r"\s+", "", txt)
            if txt:
                labels[sec] = txt
    labels["_title"] = "隔夜美股行情" if is_us else "今日股市行情"
    return labels

# 「具体点位读数」检测。**别只用 `[零一二三四五六七八九]点[零一二三四五六七八九]`**
# —— 那会把「百分之零点五四」「成交一点六一万亿元」也判成点位（实测 9/15 六段全被误标）。
# 真正的点位有两个可辨认特征，命中任一即算：
#   ① 带播报动词：「恒生指数报两万四千六百六十七点二四」；
#   ② 小数点前有 万/千 量级词（点位都在 4 位以上）。
# 刻意**不匹配**「重返六千七百点」这类关口表述（点后面不接数字）—— 关口是允许保留的。

POINT_READING = re.compile(
    r"(?:报收|报|收于)[^，。；]{0,14}?[零一二三四五六七八九]点[零一二三四五六七八九]"
    r"|[万亿][^，。；]{0,12}?[零一二三四五六七八九]点[零一二三四五六七八九]"
)


def parse_segments(proj: Path) -> list[tuple[str, str]]:
    """从 gen_narration.py 里静态取出 SEGMENTS（保序）。"""
    src = (proj / "audio" / "gen_narration.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        names = [t.id for t in node.targets if isinstance(t, ast.Name)]
        if "SEGMENTS" not in names:
            continue
        data = ast.literal_eval(node.value)
        return [(str(a), str(b)) for a, b in data]
    raise SystemExit("[error] gen_narration.py 里找不到 SEGMENTS 常量")


def guess_date(proj: Path) -> str:
    """日期优先取自 data/market-YYYYMMDD.md，否则用今天。"""
    cands = sorted((proj / "data").glob("market-*.md")) if (proj / "data").exists() else []
    if cands:
        m = re.search(r"(\d{8})", cands[-1].name)
        if m:
            d = m.group(1)
            return f"{d[:4]}-{d[4:6]}-{d[6:]}"
    return _dt.date.today().isoformat()


def build(proj: Path) -> str:
    segs = parse_segments(proj)
    meta = json.loads((proj / "audio" / "segments.json").read_text(encoding="utf-8"))
    times = {s["name"]: s for s in meta["segments"]}
    date = guess_date(proj)
    labels = resolve_labels(proj)

    o = [f"# {labels['_title']} · 播音稿（{date}）", ""]
    o.append(f"- 音色 `{meta.get('voice', '?')}` · 语速 `{meta.get('rate', '?')}` · "
             f"段间隔 {meta.get('gap', '?')}s")
    o.append(f"- 旁白总时长 **{meta['total']:.2f}s**")
    o.append("- 口播规则：**指数一律只报涨跌幅、不报点位**（点位只上画面）；"
             "每板块最多 3 项或 ≤3 句。")
    o.append("- 「点位读数」列由正文自动检测：「报/收于 + X点Y」或「万/千 + …X点Y」两种写法才算"
             "（`百分之零点五四`、`成交一点六一万亿元` 不算）。✅ ＝ 该段念了具体点位 —— "
             "新规范下应为空，历史片子若未遵守会标出来；「重返六千七百点」这类**关口表述**不算点位。")
    o.append(f"- 真源：`audio/gen_narration.py` 的 `SEGMENTS`（本文件由 "
             f"`scripts/export_narration.py` 导出，改稿请改脚本后重跑 TTS 再重新导出）")
    o.append("")
    o.append("| # | 板块 | 起始 | 时长 | 结束 | 字数 | 点位读数 |")
    o.append("|---|---|---|---|---|---|---|")
    for i, (name, text) in enumerate(segs):
        t = times.get(name, {})
        st, du = t.get("start", 0.0), t.get("duration", 0.0)
        label = labels.get(name, name)
        flag = "✅" if POINT_READING.search(text) else "—"
        o.append(f"| {i} | {label} | {st:.2f}s | {du:.2f}s | {st + du:.2f}s | {len(text)} | {flag} |")
    o.append("")
    for i, (name, text) in enumerate(segs):
        t = times.get(name, {})
        st, du = t.get("start", 0.0), t.get("duration", 0.0)
        label = labels.get(name, name)
        cps = len(text) / du if du else 0
        mark = "　⚠ 含点位读数" if POINT_READING.search(text) else ""
        o.append(f"## {i}. {label}（`{name}` {st:.2f}~{st + du:.2f}s，{du:.2f}s，"
                 f"{len(text)} 字 / {cps:.1f} 字·秒⁻¹）{mark}")
        o.append("")
        o.append(text)
        o.append("")
        o.append("---")
        o.append("")
    return "\n".join(o).rstrip() + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default=".")
    ap.add_argument("--out", default=None, help="默认 <PROJ>/narration-script-<日期>.md")
    ap.add_argument("--stdout", action="store_true", help="只打印不落盘")
    args = ap.parse_args()

    proj = Path(args.project).resolve()
    if not (proj / "audio" / "gen_narration.py").exists():
        print(f"[error] 不是工程目录（缺 audio/gen_narration.py）：{proj}", file=sys.stderr)
        return 1

    doc = build(proj)
    if args.stdout:
        sys.stdout.buffer.write(doc.encode("utf-8"))
        return 0

    out = Path(args.out) if args.out else proj / f"narration-script-{guess_date(proj)}.md"
    if not out.is_absolute():
        out = proj / out
    out.write_text(doc, encoding="utf-8")
    print(f"written -> {out}  ({len(doc)} chars)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
