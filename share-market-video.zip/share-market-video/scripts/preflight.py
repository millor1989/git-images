# -*- coding: utf-8 -*-
"""Environment self-check for the share-market-video skill.

Runs on any machine (Windows / macOS / Linux) and reports whether every
dependency the pipeline needs is present. Resolved absolute paths are
optionally written to a JSON file so later steps can consume them.

Usage:
    python preflight.py                 # human-readable report
    python preflight.py --json env.json # same + machine-readable paths
"""
import argparse
import glob
import json
import os
import shutil
import subprocess
import sys


def _which(name):
    return shutil.which(name) or None


def _first_existing(patterns):
    for p in patterns:
        for hit in glob.glob(p):
            if os.path.exists(hit):
                return os.path.abspath(hit)
    return None


def check_python():
    return {"path": sys.executable, "version": sys.version.split()[0]}


def check_module(mod):
    try:
        __import__(mod)
        return True
    except Exception:  # noqa: BLE001
        return False


def check_node():
    candidates = [os.environ.get("NODE_BIN"), _which("node"), _which("node.exe")]
    for base in (
        os.path.expanduser("~/.workbuddy/binaries/node/versions"),
        "/usr/local/bin",
    ):
        if os.path.isdir(base):
            try:
                sub = sorted(os.listdir(base))
            except OSError:
                sub = []
            for d in sub:
                candidates.append(os.path.join(base, d, "node"))
                candidates.append(os.path.join(base, d, "node.exe"))
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


def _sibling(ff, name):
    """Find `name` next to an ffmpeg binary, honouring the .exe suffix."""
    if not ff:
        return None
    for cand in (name, name + ".exe"):
        p = os.path.join(os.path.dirname(ff), cand)
        if os.path.exists(p):
            return p
    return None


def check_ffmpeg():
    ff = os.environ.get("FFMPEG") or _which("ffmpeg")
    fp = os.environ.get("FFPROBE") or _which("ffprobe") or _sibling(ff, "ffprobe")
    if not ff:
        pattern = os.path.expanduser("~/.workbuddy/binaries/ffmpeg/**/bin/ffmpeg*")
        ff = _first_existing([pattern])
        fp = fp or _sibling(ff, "ffprobe")
    return ff, fp


def check_hyperframes_cli():
    """Locate the hyperframes CLI. Falls back to npx (network) if absent."""
    caches = [
        os.path.expanduser("~/.npm/_npx"),
        os.path.expanduser("~/.workbuddy/tmp/npm-cache/_npx"),
    ]
    local = os.environ.get("LOCALAPPDATA")
    if local:
        caches.append(os.path.join(local, "npm-cache", "_npx"))
    try:
        out = subprocess.run(["npm", "config", "get", "cache"],
                             capture_output=True, text=True, timeout=20)
        if out.returncode == 0 and out.stdout.strip():
            caches.append(os.path.join(out.stdout.strip(), "_npx"))
    except Exception:  # noqa: BLE001
        pass

    for c in caches:
        hit = _first_existing([
            os.path.join(c, "*", "node_modules", "hyperframes", "bin", "hyperframes.mjs")
        ])
        if hit:
            return hit
    if os.environ.get("HYPERFRAMES_CLI") and os.path.exists(os.environ["HYPERFRAMES_CLI"]):
        return os.path.abspath(os.environ["HYPERFRAMES_CLI"])
    return None


def _browser_launches(path):
    """Smoke-test a chrome binary: `--version` must exit 0 within 15s.

    比"猜哪个版本能用"更可靠 —— 版本号与可用性在本机并不挂钩
    （152 曾经报 0xC000013B，现在正常；131 只是当时的临时解法）。
    """
    try:
        kw = {}
        if os.name == "nt":
            kw["creationflags"] = 0x08000000  # CREATE_NO_WINDOW：别闪控制台
        out = subprocess.run([path, "--version"], capture_output=True, text=True,
                             timeout=15, **kw)
        blob = (out.stdout or "") + (out.stderr or "")
        return out.returncode == 0 and "Chrome" in blob
    except Exception:  # noqa: BLE001
        return False


def check_browser():
    """解析出一个**真能启动**的 chrome，外加被淘汰的候选。

    返回 `(browser, rejected)`。**不含任何版本偏好**：候选按字典序逐个 `--version`
    冒烟测试，第一个退出码 0 的胜出 —— 所以 preflight 打印出来的路径可以直接喂给
    `HYPERFRAMES_BROWSER_PATH`，不需要人工挑版本。全都不启动则返回 None，
    交给 hyperframes 自己联网下载。
    """
    roots = [os.path.expanduser("~/.cache/hyperframes/chrome/chrome-headless-shell")]
    local = os.environ.get("LOCALAPPDATA")
    if local:
        roots.append(os.path.join(local, "hyperframes", "chrome", "chrome-headless-shell"))
    pattern = "chrome-headless-shell*"
    hits = []
    for r in roots:
        hits += glob.glob(os.path.join(r, "*", "*", pattern))
        hits += glob.glob(os.path.join(r, "*", pattern))
    hits = [h for h in hits if os.path.isfile(h)]
    if os.name == "nt":
        hits = [h for h in hits if h.endswith(".exe")]
    if not hits:
        # puppeteer / system chrome is also acceptable
        for c in ("chrome-headless-shell", "chromium", "google-chrome",
                  "chrome", "Google Chrome"):
            p = _which(c)
            if p:
                hits.append(p)

    hits = sorted(set(hits))          # 确定性顺序（字典序），不做版本偏好
    rejected = []
    for h in hits:
        if _browser_launches(h):
            return h, rejected        # rejected = 排在前面、实测启动失败的
        rejected.append(h)
    return None, rejected


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", dest="json_out", help="write resolved paths here")
    args = ap.parse_args()

    node = check_node()
    ffmpeg, ffprobe = check_ffmpeg()
    cli = check_hyperframes_cli()
    browser, browser_rejected = check_browser()
    edge = check_module("edge_tts")
    numpy = check_module("numpy")
    pillow = check_module("PIL")

    rows = [
        ("Python", sys.executable, bool(sys.executable)),
        ("edge-tts (python module)", "import edge_tts", edge),
        ("numpy (BGM 合成)", "import numpy", numpy),
        ("Pillow (qa_pre/qa_post 抽帧比对)", "import PIL", pillow),
        ("Node.js", node, bool(node)),
        ("ffmpeg", ffmpeg, bool(ffmpeg)),
        ("ffprobe", ffprobe, bool(ffprobe)),
        ("hyperframes CLI", cli or "未缓存（首次渲染时 npx 会联网拉取）", True),
        ("chrome-headless-shell", browser or "未找到（hyperframes 会自动下载）", True),
    ]

    print("===== share-market-video 环境自检 =====")
    missing = []
    for name, path, ok in rows:
        flag = "OK  " if ok else "MISS"
        print(f"[{flag}] {name:28s} {path}")
        if not ok:
            missing.append(name)

    if missing:
        print("\n缺失项处理建议：")
        tips = {
            "edge-tts (python module)": "pip install edge-tts",
            "numpy (BGM 合成)": "pip install numpy",
            "Pillow (qa_pre/qa_post 抽帧比对)": "pip install pillow",
            "Node.js": "安装 Node.js 22+（https://nodejs.org），或设 NODE_BIN 指向 node 可执行文件",
            "ffmpeg": "安装 ffmpeg 并加入 PATH，或设 FFMPEG / FFPROBE 环境变量指向可执行文件",
            "ffprobe": "随 ffmpeg 一起提供即可",
        }
        for m in missing:
            print(f"  - {m}: {tips.get(m, '请安装后重试')}")
        print("\n缺失项为必需依赖，装好后重跑本脚本。")
    else:
        print("\n全部必需依赖就绪，可以开始生成视频。")

    if browser is None and browser_rejected:
        print("\n⚠ 找到 chrome 可执行文件，但**全都没能启动**（`--version` 非 0）—— 版本与本机不兼容：")
        for r in browser_rejected:
            print(f"  - {r}")
        print("  → 让 hyperframes 自动下载一份，或手动设 HYPERFRAMES_BROWSER_PATH 指向能跑的版本。")

    if args.json_out:
        out_path = os.path.abspath(args.json_out)
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        data = {
            "python": sys.executable,
            "node": node,
            "ffmpeg": ffmpeg,
            "ffprobe": ffprobe,
            "hyperframes_cli": cli,
            "browser": browser,
            "browser_rejected": browser_rejected,
            "edge_tts": edge,
            "numpy": numpy,
            "pillow": pillow,
            "missing": missing,
        }
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"\nresolved paths -> {out_path}")

    return 1 if missing else 0


if __name__ == "__main__":
    sys.exit(main())
