# -*- coding: utf-8 -*-
"""把一个**真实工程**回灌成 skill 自带的模板（`assets/templates/<mode>/`）。

为什么需要它
----
模板过去靠人工从工程里零散挑文件拷，结果是**包内模板长期滞后**：
2026-09-30 排查「换台机器出旧模板」时发现，包内模板竟还是 **2026-08-28 的工程快照**
（段名还是旧结构「A股大盘 / A股热门 / A股热门股票 / 港股行情 / 韩日股市」），
而当前版式（卡片分页 + 新 5 段结构 + 片头模板）只存在于工作区工程里。原因有两条：

  1. 包内 `assets/templates/<mode>/index.html` 没人更新；
  2. 更要命的是**引擎根本没打包** —— 真正的版式载体是 `build_cards.py`，
     而它当时读的是 `../market-20260914/index.html` 这种**跨工程相对路径**。
     换台机器那条路不存在 → agent 拿不到基线 → 只能退回包内旧模板。

它做四件事
----
  1. 抽出「版式基座」→ `<模板>/_base-head.html`
     （= 基座工程 index.html 的 `<head>` 到 `<body>` 为止）
  2. 把工程的 `build_cards.py` 拷进模板，并把 BASE 改成读**同目录**的 `_base-head.html`，
     顺带补 `TITLE`（页面标题跟本期一致，不再残留基座里的旧日期）。**可重复执行（幂等）**。
  3. 用「模板自身的 build_cards.py + 工程的 `audio/segments.json`」重新生成 `index.html` 落进模板
     —— 保证模板自洽：新工程里跑的引擎与随包页面由同一份代码产出。
  4. 拷 `hyperframes.json` / `package.json` / `meta.json` / `assets/gsap.min.js`。

并做一层**回归护栏**：把重新生成的 `index.html` 与原工程的 `index.html` 逐行 diff，
除 `<title>` 外若还有差异就大声报出来（说明你不止改了 BASE/TITLE，版式被动了）。

用法
----
    python scripts/sync_template_from_project.py --mode a-share \\
        --project <工作区>/market-<YYYYMMDD> \\
        --base    <工作区>/market-<基座日期>/index.html

    python scripts/sync_template_from_project.py --mode us \\
        --project <工作区>/market-us-<YYYYMMDD> \\
        --base    <工作区>/market-us-<基座日期>/index.html

`--base` 可省略：脚本会先尝试从工程 `build_cards.py` 里读它原来的 BASE 路径
（前提是那份引擎还没被本脚本改过）。`--title` 也可省略，默认按 `--project` 目录名推。

回灌完请顺手核对两处文档：`SKILL.md` 的「引擎基线」引用、以及 `references/template.md`
的模板清单 —— 基线路径变了，文档里的相对路径会失效。
"""
import argparse
import difflib
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATE_DIRS = {
    "a-share": SKILL_DIR / "assets" / "templates" / "a-share",
    "us": SKILL_DIR / "assets" / "templates" / "us",
}
COPY_FROM_PROJECT = ["hyperframes.json", "package.json", "meta.json"]

HEAD_BLOCK = '''HERE = os.path.dirname(os.path.abspath(__file__))

# 版式基座随模板携带（`_base-head.html`），**不再引用同级工程** ——
# 旧写法 `../market-XXXX/index.html` 是跨工程相对路径，换台机器/换工作区即失效，
# 症状是「拿不到基线 → 退回包内旧模板」（2026-09-30 排查确认）。别改回去。
BASE = os.path.join(HERE, "_base-head.html")
if not os.path.isfile(BASE):
    raise SystemExit("[error] 版式基座缺失：" + BASE + "（应与 build_cards.py 同目录，勿删）")
with open(BASE, encoding="utf-8") as fh:
    head = fh.read()
'''

TITLE_BLOCK = '''
# 页面 <title>（只影响浏览器标签 / Studio 列表，不进画面）。
# 不显式替换就永远显示版式基座里那个旧日期。
TITLE = {title!r}
'''

TITLE_APPLY = '''
_p = re.sub(r"<title>.*?</title>", "<title>" + TITLE + "</title>", head, count=1)
assert _p != head, "版式基座的 <title> 替换未生效"
head = _p
'''

HEADER = '''# -*- coding: utf-8 -*-
"""卡片式轮播版 index.html 生成器 —— **{mode_label}** 模板（skill 自带）。

════════════════════════════════════════════════════════════════════════
⚠ 这是**模板**，不是某一期的工程。`init_project.py` 会把它和 `_base-head.html`
  一起复制进新工程；你在新工程里改本文件即可。
  示例数据 = {date_cn} 的真实行情，**仅作格式参考，逐段替换**。
  本文件由 `scripts/sync_template_from_project.py` 从工程同步而来，
  版式要改就改工程再回灌，别在这里零散手工改（否则下次回灌会被覆盖）。
════════════════════════════════════════════════════════════════════════

运行前置：`audio/segments.json` 必须已存在（由 `audio/gen_narration.py` 生成）。
    python build_cards.py          # 写出 index.html

⚠ 版式基座 `_base-head.html` 必须与本文件**同目录**（= 基座工程 index.html 的
  `<head>` 到 `<body>`）。旧版本文件这里写的是 `../market-XXXX/index.html` ——
  跨工程相对路径，换台机器就找不到，直接导致「只能退回旧模板」。**别改回去。**

★ 结构改动只改下面 `SECTIONS` + 各段 `SEC*_PAGES`，**引擎逻辑不动**。
  改造验证法：`cp index.html _b.html` → 改 → 重跑 → `diff _b.html index.html` **必须为空**。
{struct}

画面细节（2026-09-16 起的卡片式轮播）：
    整屏分页 `.page` + 段标题常驻 `.sec-title`（「大标题 + 一屏一屏切」靠它）
    换页点落在 `scripts/page_breaks.py` 实测的句末停顿上
    底部 emoji 图标与底部进度点均已删除；卡内文字一律 font-weight 400

片头（唯一模板；本期取「涨跌对立」情形：两条主线 + A/B/C 动效）：
    四行 t=0 全出（**首帧即封面**）：日期小字 / 主线1 / 主线2 / 概述小字
    主线**名称青蓝 #00d4ff**；涨跌幅数字与方向三角按涨跌上色（涨红 #ff4d4f / 跌绿 #00c48c）
    A 涨跌上色 + 50px 方向三角 ｜ B 数字 count-up（只改 textContent，**绝不动 opacity**）
    C 一次性 pulse（**不能改成循环** —— 循环会把 static-dedup 复用率从 ~50% 打到 ~13%）
    入场分三层：核心 0.00 → 装饰线 0.22 / 行2 0.26 / 概述 0.52 → 日期 0.78
    ⚠ 所有 `fromTo` / `from` 必须显式 `immediateRender: false`。

分页依据：`PAGE_BREAKS` 取 `scripts/page_breaks.py`（ffmpeg silencedetect -40dB/0.12s）
对 `assets/narration-v*.mp3` 实测的句末停顿，**不要按字数估**。
"""
'''

STRUCT = {
    "a-share": '''
★ 新内容结构（2026-09-24 用户重订）：
    ① 大盘（2 屏）    屏1 A股 4 指数 / 屏2 港韩日 3 指数 —— 画面与旁白都**只含指数**
    ② 概述（2 屏）    只装横跨 ≥2 个市场的同向驱动；找不到就**整段省略**（段名跳 sec2）
    ③ A股综述（3 屏） 总成交 + 成交额前三 + 领涨 3 板块 + 领跌 3 板块
    ④ 港股综述（1 屏）南向资金净买入 + 领涨/领跌各 1 板块各 1 代表股
    ⑤ 日韩综述（1 屏）日/韩各自领涨/领跌各 1 板块各 1 代表股
    **铁律：概述讲横向共性、各市场段讲纵向个体，同一件事只许出现在一处。**
    段名用固定语义名（大盘=sec1 … 日韩=sec5），省略板块**跳号不顺移**，track 连续。
    韩国统一写「韩国综指」；**不做中国台湾市场**。
    **含指数卡的页必须写 `mini_at`**（漏写 → KeyError，是有意的配置校验，别改成 .get()）。''',
    "us": '''
★ 结构（美股模式）：
    ① 大盘 / ② 当日主线 / ③ 龙头与中概 / ④ 承压与分化  —— 4 段 / 4 进度点 / 6 段旁白
    面板 = 道指 / 标普500 / 纳指 / 费半(SOX)，**四个都进旁白**
    指数一律**只报涨跌幅、不报点位**（点位留在画面上）
    **含指数卡的页必须写 `mini_at`**（漏写 → KeyError，是有意的配置校验，别改成 .get()）。''',
}

MODE_LABEL = {"a-share": "A股 / 港韩日 5 板块", "us": "美股 4 板块"}


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def extract_head(base_index: Path) -> str:
    """取 index.html 到 `<body>` 为止的部分（含该行）。"""
    lines = read(base_index).splitlines(keepends=True)
    idx = next((i for i, ln in enumerate(lines) if ln.strip() == "<body>"), None)
    if idx is None:
        raise SystemExit(f"[error] {base_index} 里找不到独立的 <body> 行")
    head = "".join(lines[: idx + 1])
    if not head.rstrip().endswith("<body>"):
        raise SystemExit(f"[error] head 截取异常，末尾是 {head[-60:]!r}")
    return head


def infer_base_from_engine(text: str) -> Path | None:
    """从还没被本脚本改过的 build_cards.py 里读出原 BASE 路径。"""
    m = re.search(r'BASE = os\.path\.normpath\(os\.path\.join\(HERE, "\.\.",\s*"([^"]+)"', text)
    if not m:
        return None
    return Path(m.group(1))


def patch_engine(text: str, title: str, header: str) -> tuple[str, list[str]]:
    """把工程引擎改造成「基座随包 + 标题可配」的模板引擎。幂等。"""
    notes = []

    # 0) 换掉整个文件头 docstring（模板专用说明；工程里的当期叙事不该留在模板里）
    first = text.find('"""')
    second = text.find('"""', first + 3)
    if first == -1 or second == -1:
        raise SystemExit("[error] 引擎文件头缺少 docstring，无法替换")
    text = header + text[second + 3 :].lstrip("\n")
    notes.append("docstring 已换成模板专用版")

    # 1) 保证 import re
    if not re.search(r"^import re$", text, re.M):
        m = re.search(r"^import os\n", text, re.M)
        if not m:
            raise SystemExit("[error] 找不到 `import os`，无法补 import re")
        text = text[: m.end()] + "import re\n" + text[m.end() :]
        notes.append("补 import re")

    # 2) BASE：同目录 _base-head.html
    pat = re.compile(
        r'HERE = os\.path\.dirname\(os\.path\.abspath\(__file__\)\)\n'
        r'.*?'
        r'(assert head\.rstrip\(\)\.endswith\("<body>"\)[^\n]*\n)',
        re.S,
    )
    m = pat.search(text)
    if not m:
        raise SystemExit("[error] 定位不到 BASE/head 读取块，请检查引擎头部结构")
    text = text[: m.start()] + HEAD_BLOCK + m.group(1) + text[m.end() :]
    notes.append("BASE 改为同目录 _base-head.html")

    # 3) TITLE 常量
    if not re.search(r"^TITLE = ", text, re.M):
        anchor = re.search(r'^f2 = lambda v: f"\{v:\.2f\}"\n', text, re.M)
        if not anchor:
            raise SystemExit("[error] 找不到 `f2 = lambda ...` 锚点，无法插入 TITLE")
        text = text[: anchor.end()] + TITLE_BLOCK.format(title=title) + text[anchor.end() :]
        notes.append(f"插入 TITLE = {title!r}")

    # 4) 应用 TITLE（在 CSS 注入之后）
    if "版式基座的 <title> 替换未生效" not in text:
        m = re.search(
            r'(_p = head\.replace\("    </style>", CSS \+ "    </style>", 1\)\n'
            r'assert _p != head, "CSS 注入锚点[^\n]*\n'
            r'head = _p\n)',
            text,
        )
        if not m:
            raise SystemExit("[error] 找不到 CSS 注入块，无法追加 <title> 替换")
        text = text[: m.end()] + TITLE_APPLY + text[m.end() :]
        notes.append("追加 <title> 替换")

    return text, notes


def run_engine(engine_text: str, head_text: str, segments: Path, workdir: Path) -> str:
    """在临时目录里跑模板引擎，返回生成的 index.html 内容。"""
    workdir.mkdir(parents=True, exist_ok=True)
    (workdir / "build_cards.py").write_text(engine_text, encoding="utf-8")
    (workdir / "_base-head.html").write_text(head_text, encoding="utf-8")
    (workdir / "audio").mkdir(exist_ok=True)
    shutil.copy2(segments, workdir / "audio" / "segments.json")
    r = subprocess.run(
        [sys.executable, "build_cards.py"],
        cwd=workdir, capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    if r.returncode != 0:
        print(r.stdout[-2000:])
        print(r.stderr[-2000:], file=sys.stderr)
        raise SystemExit("[error] 模板引擎运行失败")
    return read(workdir / "index.html")


def _normalize_line(ln: str) -> str:
    """抹掉 hyperframes 事后标注留下的噪声，只留「真的改了版式」才有意义的差异。

    `hyperframes check` / Studio 会把缺的 `data-hf-id` 补全并把 SVG 自闭合标签
    规范成 `" />`，于是工程里的 index.html 往往**不是**引擎的原始输出
    （2026-09-30 实测：美股工程 index.html 有 28 处这种标注，A股工程恰好没有）。
    这类差异对画面零影响，不该被护栏报成「你动了版式」。
    """
    ln = re.sub(r'\s*data-hf-id="[^"]*"', "", ln)
    ln = ln.replace('" />', '"/>')
    ln = re.sub(r"[ \t]{2,}", " ", ln)
    return ln.strip()


def diff_report(old_path: Path, new_text: str) -> list[str]:
    """与原工程 index.html 逐行 diff（先抹掉 <title> 与 hyperframes 标注噪声）。

    返回真正「版式被动了」的差异行 —— 正常回灌应为 **0**。
    """
    def prep(s: str) -> list[str]:
        return [_normalize_line(ln) for ln in s.splitlines()
                if not re.match(r"\s*<title>", ln)]      # <title> 本次有意替换

    noise = []
    for ln in difflib.unified_diff(prep(read(old_path)), prep(new_text),
                                   lineterm="", n=0):
        if ln.startswith(("---", "+++", "@@")):
            continue
        noise.append(ln)
    return noise


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=True, choices=sorted(TEMPLATE_DIRS))
    ap.add_argument("--project", required=True, help="源工程目录（已交付、版式最新的那一期）")
    ap.add_argument("--base", default=None,
                    help="版式基座工程的 index.html（省略则从工程引擎里读原 BASE）")
    ap.add_argument("--title", default=None, help="页面标题（默认按工程目录名推）")
    ap.add_argument("--note", default=None, help="模板示例数据的补充说明（写进文件头）")
    args = ap.parse_args()

    proj = Path(args.project).resolve()
    tdir = TEMPLATE_DIRS[args.mode]
    engine_src = proj / "build_cards.py"
    segments = proj / "audio" / "segments.json"
    index_src = proj / "index.html"
    for p in (engine_src, segments, index_src):
        if not p.is_file():
            raise SystemExit(f"[error] 源工程缺文件：{p}")

    engine_text = read(engine_src)

    # 基准日期：优先取 data/market-*.md 的名字，退回工程目录名
    date = None
    m = re.search(r"(\d{4})(\d{2})(\d{2})", proj.name)
    if m:
        date = f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
    if not date:
        raise SystemExit(f"[error] 无法从工程目录名推出日期：{proj.name}")

    base = Path(args.base).resolve() if args.base else None
    if base is None:
        rel = infer_base_from_engine(engine_text)
        if rel is None:
            raise SystemExit("[error] 引擎里已无原 BASE 路径，请显式传 --base <基座 index.html>")
        base = (proj / ".." / rel).resolve()
    if not base.is_file():
        raise SystemExit(f"[error] 基座 index.html 不存在：{base}")

    title = args.title or (
        f"今日股市行情 {date.replace('-', '.')}" if args.mode == "a-share"
        else f"隔夜美股行情 {date.replace('-', '.')}"
    )
    y, mo, d = date.split("-")
    header = HEADER.format(
        mode_label=MODE_LABEL[args.mode],
        date_cn=f"{y}年{int(mo)}月{int(d)}日",
        struct=STRUCT[args.mode],
    )
    if args.note:
        header = header.replace(
            "  示例数据 = ", f"  说明 = {args.note}\n  示例数据 = ", 1
        )

    print(f"源工程   : {proj}")
    print(f"版式基座 : {base}（取到 <body> 为止）")
    print(f"目标模板 : {tdir}")
    print(f"页面标题 : {title}")

    head_text = extract_head(base)
    engine_new, notes = patch_engine(engine_text, title, header)
    print("引擎改造 : " + "；".join(notes))

    with tempfile.TemporaryDirectory(prefix="tplgen-") as tmp:
        index_new = run_engine(engine_new, head_text, segments, Path(tmp) / "g")

    noise = diff_report(index_src, index_new)
    print(f"回归护栏 : 与原工程 index.html 相比，除 <title> 外差异 {len(noise)} 行")
    if noise:
        for ln in noise[:20]:
            print("    " + ln[:160])
        print("    ⚠ 上面这些说明你改的不止 BASE/TITLE —— 确认是有意的再继续。")

    tdir.mkdir(parents=True, exist_ok=True)
    (tdir / "_base-head.html").write_text(head_text, encoding="utf-8")
    (tdir / "build_cards.py").write_text(engine_new, encoding="utf-8")
    (tdir / "index.html").write_text(index_new, encoding="utf-8")
    (tdir / "assets").mkdir(exist_ok=True)
    shutil.copy2(proj / "assets" / "gsap.min.js", tdir / "assets" / "gsap.min.js")
    for f in COPY_FROM_PROJECT:
        src = proj / f
        if src.is_file():
            shutil.copy2(src, tdir / f)
        else:
            print(f"[warn] 源工程缺 {f}（init 会自己重写这两个 json，不影响）")

    # 二次生成自证：模板自身跑两遍必须一致（确定性）
    with tempfile.TemporaryDirectory(prefix="tplchk-") as tmp:
        again = run_engine(read(tdir / "build_cards.py"), read(tdir / "_base-head.html"),
                           segments, Path(tmp) / "g")
    if again != read(tdir / "index.html"):
        raise SystemExit("[error] 模板自洽校验失败：重跑生成的 index.html 与随包不一致")

    print("\n[ok] 模板已回灌：")
    for f in sorted(tdir.rglob("*")):
        if f.is_file():
            print(f"    {f.relative_to(tdir)!s:26s} {f.stat().st_size:>8,} B")
    print("\n下一步：核对 SKILL.md 里引用旧基线路径的地方（搜 `build_cards.py`）与"
          " references/template.md 的模板清单。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
