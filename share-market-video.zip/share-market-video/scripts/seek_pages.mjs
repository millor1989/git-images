#!/usr/bin/env node
/**
 * seek_pages.mjs — 轮播结构专用 seek 探针（配合 qa/../build_cards.py 的 .page 版式）。
 *
 * 为什么不用 skills/share-market-video/scripts/seek_probe.mjs：
 *   那个探针按「同类元素的位置下标」比对，适合内容固定的单屏版式。
 *   轮播版每屏 3 个 .page 同名轮转，下标会错位 → 必然误报「所有元素都不可见」；
 *   且 .page 是 inset:0 的全屏容器，底边恒为 1920 → 必然误报「内容越界」。
 *   本探针改为：先找出每帧「真正在显示的那一页」，只量它的直接子元素。
 *
 * 用法（工程根目录，index.html 同级）：
 *   node qa/seek_pages.mjs sec2 50 55 65 75 80
 *
 * 退出码：
 *   0 = 通过；2 = 有元素在自己那一页显示时仍不可见；3 = 内容越过安全区下边界
 */
import { createRequire } from "node:module";
import { spawn } from "node:child_process";
import fs from "node:fs";
import http from "node:http";
import os from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";

// ws 模块所在目录（hyperframes 的 npx 缓存）——**不要写死**：npx 缓存 hash 会变。
// 解析顺序：环境变量 WS_BASE → ~/.workbuddy 与 ~/.npm 下的通配查找。
function findWsBase() {
  const roots = [
    path.join(os.homedir(), ".workbuddy", "tmp", "npm-cache", "_npx"),
    path.join(os.homedir(), ".npm", "_npx"),
  ];
  if (process.env.LOCALAPPDATA) {
    roots.push(path.join(process.env.LOCALAPPDATA, "npm-cache", "_npx"));
  }
  for (const root of roots) {
    let dirs = [];
    try { dirs = fs.readdirSync(root).sort(); } catch { continue; }
    for (const d of dirs) {
      const nm = path.join(root, d, "node_modules");
      if (fs.existsSync(path.join(nm, "ws"))) return nm;
    }
  }
  return null;
}

const WS_BASE = process.env.WS_BASE || findWsBase();
if (!WS_BASE) {
  console.error("未找到 ws 模块目录：请设 WS_BASE 指向含 ws 的 node_modules"
    + "（如 ~/.workbuddy/tmp/npm-cache/_npx/<hash>/node_modules）");
  process.exit(1);
}
const require = createRequire(pathToFileURL(path.join(WS_BASE, "anchor.js")).href);
const WebSocket = require("ws");

const CHROME = process.env.HYPERFRAMES_BROWSER_PATH;
if (!CHROME) { console.error("请设置 HYPERFRAMES_BROWSER_PATH"); process.exit(1); }

const SEC = process.argv[2] || "sec2";
const TIMES = (process.argv.slice(3).length ? process.argv.slice(3) : ["50", "65", "80"]).map(Number);
const SAFE_BOTTOM = Number(process.env.SAFE_BOTTOM || 1620);

const CWD = process.cwd();
const URL_ = pathToFileURL(path.join(CWD, "index.html")).href;
const PORT = Number(process.env.PROBE_PORT || 9346);

const proc = spawn(CHROME, [
  `--remote-debugging-port=${PORT}`, "--headless=new", "--no-sandbox",
  "--disable-gpu", "--window-size=1080,1920", "about:blank",
], { stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function getJson(p) {
  return new Promise((resolve, reject) => {
    http.get({ host: "127.0.0.1", port: PORT, path: p }, (res) => {
      let d = ""; res.on("data", (c) => (d += c));
      res.on("end", () => { try { resolve(JSON.parse(d)); } catch (e) { reject(e); } });
    }).on("error", reject);
  });
}

let targets;
for (let i = 0; i < 60; i++) {
  try { targets = await getJson("/json/list"); if (targets?.length) break; } catch {}
  await sleep(500);
}
if (!targets?.length) { console.error("chrome 未就绪"); process.exit(1); }

const socket = new WebSocket(targets.find((t) => t.type === "page").webSocketDebuggerUrl);
let id = 0; const pending = new Map();
socket.on("message", (raw) => {
  const m = JSON.parse(raw);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
});
const send = (method, params = {}) => new Promise((res) => {
  const i = ++id; pending.set(i, res);
  socket.send(JSON.stringify({ id: i, method, params }));
});

await new Promise((r) => socket.on("open", r));
await send("Page.enable");
await send("Page.addScriptToEvaluateOnNewDocument", { source: "window.__timelines = {};" });
await send("Page.navigate", { url: URL_ });
await sleep(5000);

const expr = (t) => `(() => {
  const tl = (window.__timelines && window.__timelines["main"]);
  if (!tl) return JSON.stringify({ err: "NO_TIMELINE" });
  tl.pause(); tl.time(${t});
  const sec = document.getElementById("${SEC}");
  if (!sec) return JSON.stringify({ err: "NO_SECTION" });
  const pages = [...sec.querySelectorAll(".page")];
  const out = [];
  pages.forEach((p, pi) => {
    const pop = +(+getComputedStyle(p).opacity).toFixed(3);
    const kids = [...p.children].map((c, ci) => {
      const st = getComputedStyle(c);
      const r = c.getBoundingClientRect();
      return {
        ci, cls: (c.className || c.tagName).split(" ")[0],
        op: +(+st.opacity).toFixed(3),
        top: Math.round(r.top), bottom: Math.round(r.bottom), h: Math.round(r.height),
      };
    });
    out.push({ pi, pop, kids });
  });
  return JSON.stringify({ pages: out });
})()`;

const seen = new Map();     // key -> 是否曾在本页显示时可见
let maxBottom = -1, maxWho = "", overrun = null, activeFrames = 0;

for (const t of TIMES) {
  const r = await send("Runtime.evaluate", { expression: expr(t), returnByValue: true });
  const v = r.result?.result?.value;
  if (!v) { console.log(`t=${t}  EVAL_ERR`); continue; }
  const parsed = JSON.parse(v);
  if (parsed.err) { console.log(`t=${t}  ${parsed.err}`); continue; }
  const act = parsed.pages.filter((p) => p.pop > 0.5);
  console.log(`t=${t}   活动屏 = ${act.map((p) => "p" + p.pi).join(",") || "无(过渡中)"}`);
  for (const p of act) {
    activeFrames++;
    for (const k of p.kids) {
      const key = `p${p.pi}#${k.ci}`;
      if (!seen.has(key)) seen.set(key, { cls: k.cls, ok: false });
      if (k.op >= 0.9) seen.get(key).ok = true;
      const tag = k.op >= 0.9 ? "OK" : "<== 本页显示中却不可见!";
      console.log(`      p${p.pi} ${k.cls.padEnd(8)} op=${k.op.toFixed(2)} top=${k.top} bot=${k.bottom} h=${k.h}  ${tag}`);
      if (k.bottom > maxBottom) { maxBottom = k.bottom; maxWho = `p${p.pi}.${k.cls}`; }
      if (k.bottom > SAFE_BOTTOM && !overrun) overrun = `p${p.pi}.${k.cls} 底边 ${k.bottom} > 安全区 ${SAFE_BOTTOM}`;
    }
  }
}

console.log(`\n== 汇总（${SEC}）==`);
if (!activeFrames) {
  console.log("!! 所有采样点都没有处于显示状态的屏 —— 采样时间可能不在本段范围内");
  process.exitCode = 2;
}
const dead = [...seen.entries()].filter(([, v]) => !v.ok);
console.log(`  在页可见性检查：${seen.size} 个子元素，其中 ${dead.length} 个从未在自己那页可见`);
if (dead.length) {
  dead.forEach(([k, v]) => console.log(`    !! ${k} (${v.cls}) 始终不可见`));
  process.exitCode = 2;
}
console.log(`  内容底边最高 ${maxBottom} / 安全区 ${SAFE_BOTTOM}`);
if (overrun) { console.log(`  !! 越界：${overrun}`); process.exitCode = 3; }
else if (!process.exitCode) console.log("  OK 无越界");
if (!process.exitCode && !dead.length && activeFrames) console.log(`OK ${SEC} 全部通过`);

socket.close(); proc.kill(); process.exit(process.exitCode || 0);
