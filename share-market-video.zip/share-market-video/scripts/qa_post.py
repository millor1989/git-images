# -*- coding: utf-8 -*-
"""成片终检（L2）—— 只查渲染/编码层，秒级完成。

与 `qa_pre.py`（渲染前，查内容层）分工：
    内容层（换页 / 页点 / 停留 / 涨跌色 / 布局）  → qa_pre.py，渲染前跑，不用成片
    编码层（分辨率 / 帧数 / 码率 / 音轨 / 可解码） → 本脚本，渲染后跑，纯 ffprobe

为什么不再逐屏抽帧复核：那 200+ 次 ffmpeg 抽帧量的是像素，本质与 qa_pre.py 重复，
只是多了一层 h264 噪声，还每次多花十几分钟等渲染。本脚本只验「渲染这一道工序
有没有做对」—— 编码参数、音视频是否都在、画面能不能解码出内容。

用法：python qa/qa_post.py [--video out-0917-cards.mp4]
"""
import argparse
import glob
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent

# ⚠ 同 qa_pre.py：外部二进制不要写死（换机器后 ffmpeg 版本目录会变）。
#   解析顺序：<proj>/env.json → 同名环境变量 → 内置回退 → PATH。
#   内置回退**按运行时 home 目录 + glob 通配**求值，不写死用户名/版本。
FFMPEG = "ffmpeg"
FFPROBE = "ffprobe"


def _wb_home():
    """定位 .workbuddy 根目录（默认 ~/.workbuddy，可用 WORKBUDDY_HOME 覆盖）。"""
    for k in ("WORKBUDDY_HOME", "WB_HOME"):
        v = os.environ.get(k)
        if v and os.path.isdir(v):
            return Path(v)
    return Path.home() / ".workbuddy"


def _first_existing(patterns):
    """按顺序取第一个真实存在的文件；支持 glob 通配（版本目录 hash 会变）。"""
    for pat in patterns:
        for hit in sorted(glob.glob(str(pat))):
            if os.path.isfile(hit):
                return hit
    return None


def _fallback_bins():
    wb = _wb_home()
    return {
        "ffmpeg": _first_existing([wb / "binaries/ffmpeg/*/bin/ffmpeg.exe",
                                   wb / "binaries/ffmpeg/*/bin/ffmpeg"]),
        "ffprobe": _first_existing([wb / "binaries/ffmpeg/*/bin/ffprobe.exe",
                                    wb / "binaries/ffmpeg/*/bin/ffprobe"]),
    }


_FALLBACK = {k: v for k, v in _fallback_bins().items() if v}


def load_bins(proj):
    """把 FFMPEG / FFPROBE 解析成真实可执行路径（工程 env.json 优先）。"""
    global FFMPEG, FFPROBE
    cfg = {}
    for cand in (Path(proj) / "env.json", HERE.parent / "env.json"):
        try:
            if cand.exists():
                cfg = json.loads(cand.read_text(encoding="utf-8"))
                break
        except Exception:                                   # noqa: BLE001
            pass

    def pick(key, env_name, fallback):
        for v in (os.environ.get(env_name), cfg.get(key),
                  _FALLBACK.get(key), fallback):
            if v and (Path(v).exists() or v in ("ffmpeg", "ffprobe")):
                return v
        return fallback

    FFMPEG = pick("ffmpeg", "FFMPEG", "ffmpeg")
    FFPROBE = pick("ffprobe", "FFPROBE", "ffprobe")
    print(f"  bins: ffmpeg={Path(FFMPEG).name}  ffprobe={Path(FFPROBE).name}")

WANT_W, WANT_H, WANT_FPS = 1080, 1920, 30


def probe(p):
    r = subprocess.run([FFPROBE, "-v", "error", "-show_entries", "format=duration",
                        "-of", "default=noprint_wrappers=1:nokey=1", str(p)],
                       capture_output=True, text=True, check=True, encoding="utf-8")
    return float(r.stdout.strip())


def probe_stream(vid, sel):
    """按选择器读**单条**流的属性。

    ⚠ 别用「读全部流再按空行分块」的写法：ffprobe 加了 `noprint_wrappers=1` 之后
      流与流之间**没有任何分隔行**，解析出来会混成一坨。第一版就这么踩的 ——
      音频流把视频流的字段全盖掉，误报「没有视频流」。
      按 v:0 / a:0 分开调，各取所需，无歧义。
    """
    r = subprocess.run(
        [FFPROBE, "-v", "error", "-select_streams", sel, "-show_entries",
         "stream=codec_name,width,height,r_frame_rate,nb_frames,duration",
         "-of", "default=noprint_wrappers=1", str(vid)],
        capture_output=True, text=True, encoding="utf-8", errors="replace")
    d = {}
    for line in r.stdout.splitlines():
        if "=" in line:
            k, _, v = line.partition("=")
            d[k] = v
    return d


def black_ratio(png):
    a = np.asarray(Image.open(png).convert("RGB"), dtype=np.int16)
    lum = a.mean(axis=2)
    return float((lum < 22).mean()), a.shape


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", default="out-0917-cards.mp4")
    ap.add_argument("--proj", default="", help="工程根目录（默认：脚本上一级）")
    ap.add_argument("--skip-audio", action="store_true")
    args = ap.parse_args()

    proj = Path(args.proj).resolve() if args.proj else HERE.parent
    load_bins(proj)
    vid = Path(args.video)
    if not vid.is_absolute():
        vid = proj / args.video
    if not vid.exists() or vid.stat().st_size == 0:
        print(f"[error] 成片不存在或为空：{vid}")
        return 1

    # 旁白用「版本命名」约定（narration-v1.mp3 / -v2 …），别硬编码 narration.mp3 ——
    # 音频改内容必须换名（否则 preview/studio 命中旧缓存），2026-09-18 实测成片
    # 因找不到固定名而静默跳过了音画对齐检查。优先取 assets/ 下最新改动的 narr*。
    nars = sorted((proj / "assets").glob("narr*.mp3"), key=lambda p: p.stat().st_mtime)
    if not nars:
        nars = sorted((proj / "audio").glob("narration*.mp3"), key=lambda p: p.stat().st_mtime)
    nar = nars[-1] if nars else proj / "assets" / "narration.mp3"
    fails, warns = [], []

    print("== 1. 基本参数 ==")
    dur = probe(vid)
    mb = vid.stat().st_size / 1e6
    print(f"  {vid.name}  {mb:.1f} MB  {dur:.2f}s")

    vs = probe_stream(vid, "v:0")
    au = probe_stream(vid, "a:0")
    if not vs:
        fails.append("没有视频流")
        print("  !! 没有视频流")
    else:
        w, h = int(vs["width"]), int(vs["height"])
        num, _, den = vs.get("r_frame_rate", "0/1").partition("/")
        fps = float(num) / float(den) if float(den or 1) else 0
        nf = int(vs.get("nb_frames") or -1)
        print(f"  视频 {vs.get('codec_name')} {w}x{h} {fps:g}fps "
              f"帧数 {nf}（期望 ≈{round(dur * WANT_FPS)}）")
        if (w, h) != (WANT_W, WANT_H):
            fails.append(f"分辨率 {w}x{h} ≠ {WANT_W}x{WANT_H}")
        if abs(fps - WANT_FPS) > 0.01:
            fails.append(f"帧率 {fps:g} ≠ {WANT_FPS}")
        if nf > 0 and abs(nf - dur * WANT_FPS) > WANT_FPS * 1.5:
            fails.append(f"帧数 {nf} 与 时长×{WANT_FPS}={round(dur * WANT_FPS)} 不符")

    if not au:
        fails.append("没有音轨 —— 旁白/BGM 没混进去")
        print("  !! 没有音轨")
    else:
        adur = float(au.get("duration") or 0)
        print(f"  音轨 {au.get('codec_name')} 时长 {adur:.2f}s")
        if adur and abs(adur - dur) > 0.15:
            warns.append(f"音轨时长 {adur:.2f}s 与视频 {dur:.2f}s 差 >0.15s")

    print("\n== 2. 与旁白对齐（音画同步的总闸门）==")
    if nar.exists():
        n = probe(nar)
        print(f"  旁白 {n:.2f}s ｜ 成片 {dur:.2f}s ｜ 差 {dur - n:+.2f}s")
        if abs(dur - n) >= 0.05:
            fails.append(f"成片与旁白时长差 {dur - n:+.2f}s ≥ 0.05s → 音画必然错位")
    else:
        warns.append("找不到 assets/narr*.mp3，跳过对齐检查")

    print("\n== 3. 抽 3 帧确认可解码且非空屏 ==")
    # ⚠ 阈值分两档（2026-09-23 修）：**片头/片尾是纯文字页**（深底 + 几行字，无卡片
    #   面板），近黑占比天然达 96%~98%。尤其「**两行纯文字主线**」版式没有超大青色
    #   数字与光晕，亮像素面积比数值版更小 —— 实测踩到 97.5%，被旧的一刀切
    #   `>0.97` 误判成「渲染丢帧或版式塌了」，逼人白抽一轮帧去目视。
    #   真正的丢帧/全黑是**几乎 100% 近黑**（一个字都没有），故分档：
    #     > 0.995 → fail（真全黑）
    #     > 0.970 → 仅提示（文字页属正常，需目视确认确有文字）
    #
    # ⚠ 抽帧落盘位置（2026-09-30 修）：**必须用临时文件，不许写进 skill 的 scripts/**。
    #   旧写法 `out = HERE / "_post.png"` 把 193 KB 的帧直接丢在 scripts/ 里，
    #   且**从不清理**（本文件全文没有任何 unlink）→ 每跑一次终检就往 skill 包里沉积一个文件。
    #   改用 TemporaryDirectory：跑完自动回收，skill 目录保持干净。
    with tempfile.TemporaryDirectory(prefix="qa-post-") as _tmpd:
        for frac, tag in [(0.02, "头"), (0.5, "中"), (0.97, "尾")]:
            t = max(1.0, dur * frac)
            out = Path(_tmpd) / "_post.png"
            subprocess.run([FFMPEG, "-v", "error", "-y", "-ss", f"{t:.3f}",
                            "-i", str(vid), "-frames:v", "1", str(out)], check=True)
            ratio, shape = black_ratio(out)
            print(f"  t={t:6.2f}s {tag}帧  {shape[1]}x{shape[0]}  近黑像素 {ratio * 100:5.1f}%")
            if ratio > 0.995:
                fails.append(f"{tag}帧近全黑（{ratio * 100:.1f}%）—— 渲染丢帧或版式塌了")
            elif ratio > 0.97:
                warns.append(f"{tag}帧近黑 {ratio * 100:.1f}% —— 纯文字片头/片尾属正常，"
                             f"请目视确认该帧确有文字内容")

    if not args.skip_audio and au:
        print("\n== 4. 音轨非静音 ==")
        # -vn：只解音频。不加会把整条视频也解一遍（6 分钟片要多花几十秒）
        r = subprocess.run([FFMPEG, "-v", "info", "-i", str(vid), "-vn",
                            "-af", "volumedetect", "-f", "null", "-"],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace")
        m = re.search(r"mean_volume:\s*(-?[\d.]+) dB", r.stderr)
        mx = re.search(r"max_volume:\s*(-?[\d.]+) dB", r.stderr)
        if m:
            print(f"  mean {m.group(1)} dB ｜ max {mx.group(1) if mx else '?'} dB")
            if float(m.group(1)) < -50:
                fails.append(f"音轨平均音量 {m.group(1)} dB 过低，疑似静音轨")
        else:
            warns.append("volumedetect 没读到 mean_volume")

    print("\n== 结论 ==")
    for w in warns:
        print(f"  ~ {w}")
    if fails:
        for f in fails:
            print(f"  !! {f}")
        return 1
    print("  编码层全部通过（内容层请看 qa_pre.py 的结论）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
