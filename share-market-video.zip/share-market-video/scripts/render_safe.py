#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""render_safe.py — 「只让 CLI 抓帧，编码自己来」的稳定渲染器（2026-10-26 定稿）

## 为什么要这个脚本（根因，2026-10-26 实测）

hyperframes CLI 的 **ffmpeg 子进程有 10 分钟硬超时**（`ffmpegEncodeTimeout`
默认 `6e5` ms，可由 `FFMPEG_ENCODE_TIMEOUT_MS` 覆盖，见 CLI dist 内那段
"FFmpeg killed after exceeding ffmpegEncodeTimeout ... set
PRODUCER_ENABLE_CHUNKED_ENCODE=true" 的告警）。超时后 ffmpeg 被 SIGKILL：

- 产物 `video-only.mp4` 有 `ftyp`+`mdat` 但**没有 `moov`**（ffprobe 报
  `moov atom not found`）→ 无法播放、无法封装；
- CLI 父进程在子进程被杀后**不退出**，日志停在
  `captureOperation:"encode"` + `"message":"stage still running"`，
  只能靠 20 分钟级 watchdog 打印 heartbeat 干等。

2026-10-26 那期 129.24s / 3878 帧，A 连跑 3 次全部死在这里（抓帧 2~3.7 帧/s
时，ffmpeg 生命周期 = 整个抓帧时长 17~32 分钟，必然 >10 分钟）。

## 本脚本的做法

把「抓帧」和「编码」彻底解耦，让长连接的 ffmpeg 管道根本不存在：

1. 关掉流式编码（`PRODUCER_ENABLE_STREAMING_ENCODE=false`），CLI 变成纯抓帧器，
   帧以 JPEG 落盘到 `<TMP>/hf-render-*/captured-frames/frame_%06d.jpg`；
2. 监视日志的 `@hf-progress`，等 `done == total` 且磁盘帧数稳定；
3. **主动杀掉 CLI**（它的 encode 阶段反正会挂，不等它）；
4. 自己用 ffmpeg 编码（`-framerate <fps> -i frame_%06d.jpg -i audio.m4a`），
   并做 4 项硬校验：帧数精确、帧连续、末帧可解码、成片有 `moov` 且帧数吻合。

抓帧速度反而更快：流式 2~3.7 帧/s → 磁盘抓帧实测 **8.4 帧/s**。

## 磁盘（Windows 不要吃 C 盘）

临时目录走 `TMP`/`TEMP` → Node `os.tmpdir()`，可用 `--tmp-root` 指定。
默认 `E:\\workbuddy\\hfVideos\\_hftmp`。实测 3878 帧 JPEG ≈ **4.6 GB**
（≈1.2 MB/帧），启动前会做剩余空间预检。

## 用法

    # 完整流程（抓帧 + 编码）
    python render_safe.py --proj E:/workbuddy/hfVideos/market-20261026 --output out-1026.mp4

    # 只编码：CLI 已抓完帧但被杀 / 上次编码失败，直接复用落盘帧，不重抓
    python render_safe.py --from-frames <帧目录> --audio <audio.m4a> --output out-1026.mp4

    # 只看会执行什么
    python render_safe.py --proj <dir> --dry-run

退出码：0 成功；2 预检不过；3 抓帧停滞（chrome 冻死，需重试）；4 帧校验失败；
5 编码/封装失败。
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone

TZ = timezone(timedelta(hours=8))
HOME = os.path.expanduser("~")                    # C:\Users\WML
BASE = os.path.join(HOME, ".workbuddy")           # 本机 binaries / npm-cache 都在 ~/.workbuddy 下
_CANDIDATE_BASES = [BASE, HOME]


def log(msg: str) -> None:
    print(f"[{datetime.now(TZ).strftime('%H:%M:%S')}] {msg}", flush=True)


# ---------------------------------------------------------------- 二进制解析
def _first(paths):
    for p in paths:
        if p and os.path.exists(p):
            return p
    return None


def _search(*rel_parts, reverse=True):
    """在 ~/.workbuddy 与 ~ 两个基座下按相对模式搜索，返回排序后的绝对路径列表。"""
    hits = []
    for base in _CANDIDATE_BASES:
        hits += glob.glob(os.path.join(base, *rel_parts))
    return sorted(set(hits), reverse=reverse)


def resolve_bins(proj: str) -> dict:
    """env.json 优先，但里面的路径可能是旧版本目录 → 一律验证存在性 + 兜底搜索。"""
    env = {}
    for cand in (os.path.join(proj, "env.json"),):
        if os.path.exists(cand):
            try:
                env = json.load(open(cand, encoding="utf-8-sig"))
            except Exception:
                env = {}

    node = _first([
        env.get("node"),
        *_search("binaries", "node", "versions", "*", "node.exe"),
    ])

    ffmpeg = _first([
        env.get("ffmpeg"),
        *_search("binaries", "ffmpeg", "*", "bin", "ffmpeg.exe"),
        *_search("binaries", "node", "versions", "*", "ffmpeg.exe"),
    ])
    ffprobe = _first([
        env.get("ffprobe"),
        (ffmpeg or "").replace("ffmpeg.exe", "ffprobe.exe"),
        *_search("binaries", "ffmpeg", "*", "bin", "ffprobe.exe"),
        *_search("binaries", "node", "versions", "*", "ffprobe.exe"),
    ])

    cli = _first([
        env.get("hyperframes_cli"),
        *_search("AppData", "Local", "npm-cache", "_npx", "*", "node_modules",
                 "hyperframes", "bin", "hyperframes.mjs"),
        *_search("tmp", "npm-cache", "_npx", "*", "node_modules",
                 "hyperframes", "bin", "hyperframes.mjs"),
    ])
    return {"node": node, "ffmpeg": ffmpeg, "ffprobe": ffprobe, "hyperframes_cli": cli}


# ---------------------------------------------------------------- 小工具
def free_gb(path: str) -> float:
    p = path
    while p and not os.path.exists(p):
        p = os.path.dirname(p)
    if not p:
        return 0.0
    try:
        return shutil.disk_usage(p).free / 2**30
    except Exception:
        return 0.0


def kill_tree(pid: int) -> None:
    try:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                       capture_output=True, text=True, timeout=30)
    except Exception as e:
        log(f"   ! taskkill {pid} 失败: {e}")


def probe(ffprobe: str, path: str) -> dict:
    try:
        out = subprocess.run(
            [ffprobe, "-v", "error", "-show_entries", "format=duration",
             "-show_entries", "stream=codec_type,nb_frames", "-of", "json", path],
            capture_output=True, text=True, timeout=120).stdout
        return json.loads(out or "{}")
    except Exception:
        return {}


def has_moov(path: str) -> bool:
    """MP4 是否正常收尾。ffmpeg 被 SIGKILL 的典型特征就是没有 moov。"""
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as f:
            head = f.read(4 * 1024 * 1024)
            if b"moov" in head:
                return True
            if size > 4096:
                f.seek(max(0, size - 4096))
                return b"moov" in f.read()
    except Exception:
        pass
    return False


# ---------------------------------------------------------------- 抓帧
class Capture:
    """起 CLI 抓帧，解析 @hf-progress，等 done==total 且落盘稳定。"""

    PROGRESS = re.compile(r'@hf-progress\s+(\{.*?\})')

    def __init__(self, cli, node, proj, log_path, tmp_root, fps, workers,
                 protocol_timeout_ms, extra_env=None):
        self.cli, self.node, self.proj = cli, node, proj
        self.log_path = log_path
        self.tmp_root = tmp_root
        self.fps = fps
        self.workers = workers
        self.protocol_timeout_ms = protocol_timeout_ms
        self.extra_env = extra_env or {}
        self.proc = None
        self.done = 0
        self.total = 0
        self.work_dir = None
        self.frames_dir = None

    def start(self):
        env = dict(os.environ)
        env["NODE_OPTIONS"] = ""                     # 本机必须清空，否则 CLI 起不来
        env["PATH"] = os.path.dirname(self.node) + os.pathsep + env.get("PATH", "")
        env["TMP"] = self.tmp_root                    # ★ 临时目录搬到非 C 盘
        env["TEMP"] = self.tmp_root
        env["TMPDIR"] = self.tmp_root
        # 关流式编码：CLI 退化成纯抓帧器，长连接 ffmpeg 管道根本不会建立
        env["PRODUCER_ENABLE_STREAMING_ENCODE"] = "false"
        env["PRODUCER_STREAMING_ENCODE_DURATION_CAP_ENABLED"] = "true"
        env["PRODUCER_STREAMING_ENCODE_MAX_DURATION_SECONDS"] = "60"
        env["HF_CAPTURE_PARALLEL_STREAM"] = "false"
        env.update({k: str(v) for k, v in self.extra_env.items()})

        cmd = [
            self.node, self.cli, "render",
            "--quality", "high",
            "--no-browser-gpu",
            "--workers", str(self.workers),
            "--protocol-timeout", str(self.protocol_timeout_ms),
            "--output", "_capture_only.mp4",   # 占位：这个文件永远不会被用
        ]
        self.logf = open(self.log_path, "w", encoding="utf-8", errors="ignore")
        log(f"启动 CLI 抓帧（workers={self.workers}, TMP={self.tmp_root}）")
        self.proc = subprocess.Popen(
            cmd, cwd=self.proj, env=env,
            stdout=self.logf, stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
        )
        log(f"  pid={self.proc.pid}  log={self.log_path}")
        return self.proc.pid

    def tail(self):
        try:
            with open(self.log_path, "r", encoding="utf-8", errors="ignore") as f:
                f.seek(max(0, os.path.getsize(self.log_path) - 200_000))
                return f.read()
        except Exception:
            return ""

    def scan(self) -> None:
        text = self.tail()
        for m in self.PROGRESS.finditer(text):
            try:
                d = json.loads(m.group(1))
            except Exception:
                continue
            if d.get("code") == "capture":
                self.total = max(self.total, int(d.get("total") or 0))
                self.done = max(self.done, int(d.get("done") or 0))

    def locate_work_dir(self) -> str | None:
        pats = sorted(glob.glob(os.path.join(self.tmp_root, "hf-render-*")),
                      key=os.path.getmtime, reverse=True)
        for d in pats:
            fr = os.path.join(d, "captured-frames")
            if os.path.isdir(fr):
                self.work_dir = d
                self.frames_dir = fr
                return fr
        return None

    def frames_on_disk(self) -> int:
        if not self.frames_dir or not os.path.isdir(self.frames_dir):
            self.locate_work_dir()
        if not self.frames_dir or not os.path.isdir(self.frames_dir):
            return 0
        return len([n for n in os.listdir(self.frames_dir) if n.lower().endswith((".jpg", ".jpeg", ".png"))])

    def wait(self, stall_min: float, settle_sec: int, total_hint: int = 0):
        """返回 (ok, reason)。ok=False 时 reason 区分 停滞 / 进程退出。"""
        if total_hint and not self.total:
            self.total = total_hint
        last_n, last_change = -1, time.time()
        while True:
            self.scan()
            n = self.frames_on_disk()
            if n != last_n:
                last_n, last_change = n, time.time()
            total = self.total or total_hint
            alive = self.proc.poll() is None

            if total and n >= total and self.done >= total:
                log(f"抓帧完成 {n}/{total}，等 {settle_sec}s 确认稳定…")
                time.sleep(settle_sec)
                n2 = self.frames_on_disk()
                if n2 >= total:
                    return True, f"frames={n2} total={total}"
                last_change = time.time()
                continue

            if not alive:
                # CLI 自己退了（可能是超时/崩溃）；帧若齐了仍可继续
                if total and n >= total:
                    return True, f"cli_exited_but_frames_complete frames={n}"
                return False, f"cli_exited_early frames={n}/{total or '?'}"

            idle = time.time() - last_change
            if idle > stall_min * 60:
                return False, f"stalled frames={n}/{total or '?'} idle={idle/60:.1f}min"

            log(f"  抓帧 {n}/{total or '?'}  ({self.done} done)")
            time.sleep(15)

    def stop(self):
        if self.proc and self.proc.poll() is None:
            kill_tree(self.proc.pid)
            try:
                self.proc.wait(timeout=15)
            except Exception:
                pass
            log("已终止 CLI（encode 阶段不需要它）")
        try:
            self.logf.close()
        except Exception:
            pass


# ---------------------------------------------------------------- 帧校验
def validate_frames(frames_dir: str, ffprobe: str, total: int) -> tuple[bool, str, int]:
    files = sorted(f for f in os.listdir(frames_dir) if f.lower().endswith((".jpg", ".jpeg", ".png")))
    n = len(files)
    if total and n != total:
        return False, f"帧数不符 disk={n} expect={total}", n
    m = re.match(r"^(.*?)(\d+)(\.[A-Za-z]+)$", files[0])
    if not m:
        return False, f"帧命名无法解析: {files[0]}", n
    prefix, _, ext = m.group(1), m.group(2), m.group(3)
    pad = len(m.group(2))
    expect = [f"{prefix}{i:0{pad}d}{ext}" for i in range(n)]
    missing = [x for x in expect if x not in set(files)]
    if missing:
        return False, f"帧编号不连续，缺 {len(missing)} 个（如 {missing[0]}）", n
    # 末帧完整性：chrome 被杀可能留下截断 JPEG
    for probe_name in (files[-1], files[-min(3, n)]):
        info = probe(ffprobe, os.path.join(frames_dir, probe_name))
        streams = (info or {}).get("streams") or []
        if not streams:
            return False, f"末帧无法解码: {probe_name}", n
    return True, f"frames={n} 连续且末帧可解码", n


# ---------------------------------------------------------------- 编码
def encode(ffmpeg, frames_dir, audio, out_path, fps, crf, preset) -> bool:
    cmd = [
        ffmpeg, "-y", "-hide_banner",
        "-framerate", str(fps),
        "-start_number", "0",
        "-i", os.path.join(frames_dir, "frame_%06d.jpg"),
        "-i", audio,
        "-c:v", "libx264", "-crf", str(crf), "-preset", preset,
        "-pix_fmt", "yuv420p", "-r", str(fps),
        "-c:a", "copy", "-shortest", "-movflags", "+faststart",
        out_path,
    ]
    log("ffmpeg 编码中…")
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    if r.returncode != 0:
        log("ffmpeg 失败：\n" + (r.stderr or "")[-1500:])
        return False
    return True


def audio_duration(ffprobe: str, path: str) -> float:
    info = probe(ffprobe, path)
    return float((info.get("format") or {}).get("duration") or 0)


def verify_output(path: str, ffprobe: str, fps: int, total: int,
                  audio_dur: float = 0.0) -> tuple[bool, str]:
    if not os.path.exists(path):
        return False, "成片不存在"
    if not has_moov(path):
        return False, "成片缺 moov（未正常收尾）"
    info = probe(ffprobe, path)
    v = [s for s in info.get("streams", []) if s.get("codec_type") == "video"]
    a = [s for s in info.get("streams", []) if s.get("codec_type") == "audio"]
    if not v:
        return False, "成片无视频流"
    nb = int(v[0].get("nb_frames") or 0)
    dur = float((info.get("format") or {}).get("duration") or 0)
    # -shortest 会按音频长度裁掉片尾几帧（2026-10-26 实测：3878 抓帧 → 3874 出帧，
    # 与交付成片字节完全一致），所以容差按 0.2s 给，不放宽到看不见真短少。
    tol = max(6, int(round(fps * 0.2)))
    if total and nb and (nb > total + 2 or nb < total - tol):
        return False, f"帧数不符 {nb} vs {total}（容差 {tol}）"
    if dur <= 0:
        return False, "时长为 0"
    if audio_dur and abs(dur - audio_dur) > 0.3:
        return False, f"时长与音频不齐 {dur:.3f}s vs {audio_dur:.3f}s"
    if total and not audio_dur and abs(dur - total / fps) > 1.0:
        return False, f"时长异常 {dur:.2f}s vs {total/fps:.2f}s"
    if not a:
        return False, "成片无音频流"
    mb = os.path.getsize(path) / 2**20
    return True, f"{dur:.2f}s / {nb} 帧 / {mb:.1f} MB / 含音频"


# ---------------------------------------------------------------- main
def main() -> int:
    ap = argparse.ArgumentParser(description="稳定渲染：CLI 只抓帧，编码自己来")
    ap.add_argument("--proj", help="工程目录")
    ap.add_argument("--output", default=None, help="成片路径（默认 <proj>/out-MMDD.mp4）")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--crf", type=int, default=16,
                    help="默认 16，对齐 CLI --quality high 的 CRF 16（18 更小更快，文字边缘略差）")
    ap.add_argument("--preset", default="veryfast")
    ap.add_argument("--workers", type=int, default=1, help="抓帧 worker 数（本机建议 1）")
    ap.add_argument("--tmp-root", default=r"E:\workbuddy\hfVideos\_hftmp",
                    help="临时目录根（Windows 上避开 C 盘）")
    ap.add_argument("--stall-min", type=float, default=6.0, help="抓帧停滞多少分钟后判死")
    ap.add_argument("--settle-sec", type=int, default=10)
    ap.add_argument("--protocol-timeout", type=int, default=420000)
    ap.add_argument("--total-frames", type=int, default=0, help="已知总帧数，加快判定")
    ap.add_argument("--from-frames", help="跳过抓帧，直接编码这个帧目录（断点续做）")
    ap.add_argument("--audio", help="配合 --from-frames 的音频文件")
    ap.add_argument("--keep-frames", action="store_true", help="保留临时帧（默认成功后删除）")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    proj = os.path.abspath(args.proj) if args.proj else None
    if not args.from_frames and not proj:
        log("必须给 --proj 或 --from-frames")
        return 2

    bins = resolve_bins(proj or os.getcwd())
    for k in ("node", "ffmpeg", "ffprobe"):
        if not bins[k]:
            log(f"找不到 {k}")
            return 2
    if not args.from_frames and not bins["hyperframes_cli"]:
        log("找不到 hyperframes CLI")
        return 2
    log("bins: " + " | ".join(f"{k}={os.path.basename(v)}" for k, v in bins.items() if v))

    # ---- 输出路径
    out = args.output
    if not out and proj:
        out = os.path.join(proj, f"out-{datetime.now(TZ).strftime('%m%d')}.mp4")
    elif out and not os.path.isabs(out) and proj:
        out = os.path.join(proj, out)
    if out and os.path.exists(out) and not args.from_frames:
        log(f"⚠ 成片已存在，先删除半成品: {out}")
        os.remove(out)

    frames_dir = audio = work_dir = None

    if args.from_frames:
        frames_dir = os.path.abspath(args.from_frames)
        audio = args.audio and os.path.abspath(args.audio)
        if not os.path.isdir(frames_dir):
            log(f"帧目录不存在: {frames_dir}")
            return 2
        if not audio:
            guess = os.path.join(os.path.dirname(frames_dir), "audio.m4a")
            if os.path.exists(guess):
                audio = guess
        if not audio or not os.path.exists(audio):
            log("找不到音频（--audio）")
            return 2
        log(f"跳过抓帧，复用帧目录 {frames_dir}")
    else:
        if not os.path.exists(os.path.join(proj, "index.html")):
            log("工程里没有 index.html（先跑 build_cards.py / build.sh）")
            return 2
        os.makedirs(args.tmp_root, exist_ok=True)
        log(f"临时目录根 {args.tmp_root}（剩余 {free_gb(args.tmp_root):.1f} GB）")
        cap = Capture(bins["hyperframes_cli"], bins["node"], proj,
                      os.path.join(proj, "render-safe-cli.log"),
                      args.tmp_root, args.fps, args.workers, args.protocol_timeout)
        if args.dry_run:
            log("dry-run：将启动 CLI 抓帧后自行编码，未执行")
            return 0
        cap.start()
        ok, reason = cap.wait(args.stall_min, args.settle_sec, args.total_frames)
        cap.stop()
        log(f"抓帧判定: {'OK' if ok else 'FAIL'} — {reason}")
        if not ok:
            return 3
        frames_dir, work_dir = cap.frames_dir, cap.work_dir
        audio = os.path.join(work_dir, "audio.m4a")
        if not os.path.exists(audio):
            log("抓帧目录里没有 audio.m4a")
            return 4
        total = cap.total or args.total_frames or cap.frames_on_disk()
        n_need = total
        need_gb = n_need * 1.35 / 1024
        if free_gb(os.path.dirname(out) or proj) < need_gb + 1:
            log(f"⚠ 成片所在盘剩余不足（需 ~{need_gb:.1f} GB）")

    # ---- 帧校验
    total = args.total_frames or (cap.total if not args.from_frames else 0) or 0
    ok, msg, n = validate_frames(frames_dir, bins["ffprobe"], total)
    log(f"帧校验: {'OK' if ok else 'FAIL'} — {msg}")
    if not ok:
        return 4
    total = total or n

    if args.dry_run:
        log("dry-run：帧校验通过，未开始编码")
        return 0

    # ---- 编码 + 校验
    a_dur = audio_duration(bins["ffprobe"], audio)
    log(f"音频时长 {a_dur:.3f}s")
    if not encode(bins["ffmpeg"], frames_dir, audio, out, args.fps, args.crf, args.preset):
        return 5
    ok, msg = verify_output(out, bins["ffprobe"], args.fps, total, a_dur)
    log(f"成片校验: {'OK' if ok else 'FAIL'} — {msg}")
    if not ok:
        return 5

    report = {
        "output": out, "frames": total, "fps": args.fps,
        "size": os.path.getsize(out), "frames_dir": frames_dir,
        "at": datetime.now(TZ).isoformat(timespec="seconds"),
    }
    if proj:
        try:
            json.dump(report, open(os.path.join(proj, "render-safe.json"), "w", encoding="utf-8"),
                      ensure_ascii=False, indent=2)
        except Exception:
            pass

    # ---- 清理
    if work_dir and not args.keep_frames:
        shutil.rmtree(work_dir, ignore_errors=True)
        log(f"已清理临时目录 {work_dir}")
    elif work_dir:
        log(f"保留临时帧 {work_dir}")

    log(f"✅ 完成 → {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
