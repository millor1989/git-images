'use strict';
/*
 * render_with_shim.cjs — 带 stdio 修补的 hyperframes 启动器
 *
 * 为什么需要它
 * -----------
 * 本机「同步 spawn + stdin 管道 = EBUSY」（详见同目录 ff_stdin_shim.cjs 的说明），
 * 会让 `hyperframes render` 在 ffmpeg 探针（execFileSync）就死掉。
 *
 * 为什么不用 `NODE_OPTIONS=--require=...` 直接起 CLI
 * ------------------------------------------------
 * 实测该方式在**直接起 node 时可行**，但作为渲染入口不够稳：只要有一环没把
 * env 传下去（或被测到的是异步/子进程路径），shim 就没生效，且**失败现象与
 * 不打 shim 完全一样**（还是那句 `✗ FFmpeg cannot start`），很容易白跑一轮。
 * 本启动器把三件事**钉在同一个进程内**，不依赖外部 env：
 *   ① 同进程 require 装 shim（并 syncBuiltinESMExports，让 ESM 具名导入也生效）
 *   ② 覆写 process.argv，让 CLI 以为自己是入口脚本
 *   ③ 再把 NODE_OPTIONS 写进 process.env，使 CLI 派生的子进程同样带上 shim
 *
 * 用法
 * ----
 *   cd <PROJ>
 *   export PATH="/c/<ffmpeg bin>:$PATH"        # render 仍需要 ffmpeg 在 PATH 上
 *   node <SKILL>/scripts/render_with_shim.cjs <preflight 输出的 hyperframes_cli> \
 *        render --quality high --no-browser-gpu --output out-<日期>.mp4 > render.log 2>&1
 *
 * 自检：渲染日志里应出现 `[init] shim installed ...`（见 <PROJ>/_ffshim.log）。
 * 没有这行 = 启动器没生效，别等 10 分钟再排查。
 */
const path = require('path');
const fs = require('fs');

const SHIM = path.join(__dirname, 'ff_stdin_shim.cjs');
require(SHIM);
process.env.NODE_OPTIONS = '--require=' + SHIM;

const cli = process.argv[2];
if (!cli) {
  console.error('用法: node render_with_shim.cjs <hyperframes_cli.mjs> [hyperframes 参数...]');
  process.exit(2);
}
const cliAbs = path.resolve(cli);
if (!fs.existsSync(cliAbs)) {
  console.error('[launcher] 找不到 hyperframes CLI: ' + cliAbs);
  process.exit(2);
}

process.argv.splice(2, 1);      // 去掉 CLI 路径参数，让 CLI 看到原本的 render 参数
process.argv[1] = cliAbs;       // 伪装成入口脚本

import('file:///' + cliAbs.replace(/\\/g, '/')).catch((e) => {
  console.error('[launcher] import cli failed: ' + (e && e.message));
  process.exit(1);
});
