#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""check_ssot.py —— 「单一事实源」一致性硬闸门（渲染前跑，秒级）。

为什么需要它（2026-09-30 A股期实测踩到，一次白出一轮片）：
  同一条数据链被手抄成了 3 份互不同步的副本 ——
    ① md 里的片头行 ② 确认邮件正文 ③ build_cards.py 的 INTRO
  三处片头各写一遍，改其中一处另两处不会跟着变。当期的实际后果：
    md 写「元件·PCB」→ 邮件正文写「康希诺」→ build_cards 又写成「沪指」，
  用户邮件里确认的片头（康希诺）从头到尾没被执行过，直到成片出来才发现。
  **这不是数据算错，是同一份数据被手写了三遍。**

  本脚本把「md = 唯一事实源」从一句口头约定变成**机器闸门**：
  凡是从 md 取数生成的产物，都必须与 md 逐值对齐；对不上就 exit 1 停线。

检查项（--proj 指定工程根）：
  A. 片头主线（build_cards.py 的 INTRO 段）
       · 名称 + 涨跌幅（含正负号）必须与 md「拟用结构与片头」的主线行一致
       · INTRO 里的「概述行」必须与 md 一致
       · 日期行必须与 md 的交易日一致
  B. 片头 count-up 参数（JS 里的 countUp("#intro-big", X) 等）
       · 数值必须等于 INTRO 里对应数字元素显示的涨跌幅
       （2026-09-30 踩到：INTRO 改了但 countUp 参数没跟着改 → 会写回旧值）
  C. 旁白 intro 段（audio/gen_narration.py 的 SEGMENTS intro 文案）
       · 不得出现与 md 片头主线的涨跌方向相反的表述（粗查方向词）
  D. 画面数字总检（复用 check_source_numbers.py 的口径，此处只做存在性）

用法（工程根目录）：
    python <SKILL>/scripts/check_ssot.py --proj <PROJ>
    python <SKILL>/scripts/check_ssot.py --proj . --json     # 机读输出

退出码：0 = 全部对齐；1 = 有不对齐项（逐条打印「md 值 vs 产物值」）

自测记录（2026-09-30，四例全过 —— 闸门自身也要有自证）：
  · 例1 md=康希诺+20.00% / 产物=沪指+0.31% → exit 1，报名称+涨跌幅不一致 ✅
  · 例2 概述行不一致（医药地产领涨 vs 元件涨停潮…）→ exit 1 ✅
  · 例3 INTRO 正确、countUp 仍为旧值 0.86 → exit 1，报 countUp 覆盖风险 ✅
  · 例4 全部对齐 → exit 0 ✅
  ⚠ 自测中抓到本脚本自身的一个 bug：countUp 的选择器是 `"#intro-big"`（带 `#`），
    初版正则漏写 `#` → 整条 B 项**静默跳过**、闸门「永远通过」。
    已修（`"#?(intro-big2?)"`），并新增「找不到 countUp 就报错」——**静默跳过是闸门最大的敌人**。
"""
from __future__ import annotations

import argparse
import glob
import json
import pathlib
import re
import sys

UNESC = re.compile(r"\\u([0-9a-fA-F]{4})")
# md 里的片头主线行：`<名称 ▲ +x.xx%>` ／ `<名称 ▼ −x.xx%>`
MD_MAIN = re.compile(r"^\s*[-*]?\s*主线两行[：:]\s*(.+)$", re.M)
# `名称 ▲ +1.23%` / `名称 ▼ −4.56%`（分隔符可全角/半角，三角可有无）
MD_LEG = re.compile(
    r"([^\s`▲▼+\-−]+)\s*([▲▼])?\s*([+\-−]\s*\d+(?:\.\d+)?\s*%)"
)


def unesc(t: str) -> str:
    """\\uXXXX → 真字符。"""
    return UNESC.sub(lambda m: chr(int(m.group(1), 16)), t)


def norm_pct(s: str) -> str:
    """涨跌幅归一化：全角负号→半角、去空格、统一一位小数格式。"""
    s = s.replace("−", "-").replace("－", "-").replace("＋", "+").replace(" ", "")
    m = re.match(r"^([+\-]?)(\d+(?:\.\d+)?)%?$", s)
    if not m:
        return s
    sign, num = m.group(1) or "+", m.group(2)
    try:
        return f"{sign}{float(num):.2f}%"
    except ValueError:
        return s


def pick_source(proj: pathlib.Path, explicit: str | None) -> pathlib.Path:
    if explicit:
        p = pathlib.Path(explicit)
        return p if p.is_absolute() else (proj / p)
    cands = sorted(glob.glob(str(proj / "data" / "*.md")),
                   key=lambda p: pathlib.Path(p).stat().st_mtime)
    if not cands:
        raise SystemExit("[error] data/*.md 不存在 —— 先跑第 2 步落盘")
    return pathlib.Path(cands[-1])


def parse_md_intro(md_text: str):
    """从 md 抽出片头三行 + 日期。返回 dict（缺项为 None）。"""
    out = {"date": None, "legs": [], "note": None}
    m = re.search(r"^\s*[-*]?\s*日期行[：:]\s*`?([^`\n]+?)`?\s*$", md_text, re.M)
    if m:
        out["date"] = m.group(1).strip()
    m = MD_MAIN.search(md_text)
    if m:
        line = m.group(1)
        for mm in MD_LEG.finditer(line):
            out["legs"].append({
                "name": mm.group(1).strip(),
                "arrow": (mm.group(2) or "").strip(),
                "pct": norm_pct(mm.group(3)),
            })
    m = re.search(r"^\s*[-*]?\s*概述行[：:]\s*`?([^`\n]+?)`?\s*$", md_text, re.M)
    if m:
        out["note"] = m.group(1).strip()
    return out


def strip_tags(t: str) -> str:
    return re.sub(r"<[^>]+>", "", t)


def parse_build_intro(src: str):
    """从 build_cards.py 抽 INTRO：两行主线 + 概述 + 日期。"""
    out = {"date": None, "legs": [], "note": None,
           "countup": {}, "xml_hint": ""}
    src_u = unesc(src)

    def grab(eid: str):
        m = re.search(r'id="' + eid + r'"[^>]*>(.*?)</h1>', src_u, re.S)
        return m.group(1) if m else None

    for eid in ("intro-main", "intro-main2"):
        blk = grab(eid)
        if blk is None:
            continue
        pm = re.search(r'id="intro-big2?"[^>]*>([^<]*)<', blk)
        pct = norm_pct(pm.group(1).strip()) if pm else None
        # 名称 = 去掉 svg（三角）+ 去掉承载涨跌幅的 <span> 后的纯文字
        name_blk = re.sub(r'<svg.*?</svg>', '', blk, flags=re.S)
        name_blk = re.sub(r'<span[^>]*id="intro-big2?"[^>]*>.*?</span>', '',
                          name_blk, flags=re.S)
        name = strip_tags(name_blk).strip()
        out["legs"].append({"name": name, "pct": pct})

    m = re.search(r'id="intro-note"[^>]*>([^<]*)<', src_u)
    if m:
        out["note"] = m.group(1).strip()
    m = re.search(r'id="intro-date"[^>]*>([^<]*)<', src_u)
    if m:
        out["date"] = m.group(1).strip()

    # countUp("#intro-big", 0.31, 0.12) / countUp("#intro-big2", -2.51, 0.38)
    # ⚠ 选择器带 `#`（`"#intro-big"`）—— 早期漏写 `#` 会让整条 B 项静默跳过，
    #   闸门「永远通过」（本脚本自证时抓到，见文件末尾自测记录）。
    for m in re.finditer(
            r'countUp\(\s*"#?(intro-big2?)"\s*,\s*([+\-]?\d+(?:\.\d+)?)', src_u):
        out["countup"][m.group(1)] = float(m.group(2))
    return out


def parse_narration_intro(path: pathlib.Path):
    """从 gen_narration.py 抽 intro 段旁白。"""
    if not path.exists():
        return None
    t = path.read_text(encoding="utf-8", errors="ignore")
    m = re.search(r'\(\s*"intro"\s*,\s*["\'](.+?)["\']\s*\)', t, re.S)
    return m.group(1).strip() if m else None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--proj", default=".", help="工程根目录")
    ap.add_argument("--src", default=None, help="事实源 md（默认 data/*.md 最新）")
    ap.add_argument("--json", action="store_true", help="机读输出")
    a = ap.parse_args()

    proj = pathlib.Path(a.proj).resolve()
    if not (proj / "build_cards.py").exists():
        raise SystemExit(f"[error] {proj}/build_cards.py 不存在")

    md_path = pick_source(proj, a.src)
    md = md_path.read_text(encoding="utf-8", errors="ignore")
    src = (proj / "build_cards.py").read_text(encoding="utf-8", errors="ignore")

    md_intro = parse_md_intro(md)
    bd_intro = parse_build_intro(src)
    nar_intro = parse_narration_intro(proj / "audio" / "gen_narration.py")

    bad: list[str] = []

    # ---- A. 片头主线逐行比对 ----------------------------------------------
    if not md_intro["legs"]:
        bad.append("md 里没解析到「主线两行」—— 请确认第 2 步的片头行格式为 "
                   "`- 主线两行：` 名称 ▲ +x.xx%` ／ `名称 ▼ −x.xx%``")
    if not bd_intro["legs"]:
        bad.append("build_cards.py 里没解析到 intro-main / intro-main2")

    for i, (m_leg, b_leg) in enumerate(zip(md_intro["legs"], bd_intro["legs"]),
                                       1):
        if m_leg["name"] != b_leg["name"]:
            bad.append(f"片头主线{i} 名称不一致：md=「{m_leg['name']}」"
                       f" vs build_cards=「{b_leg['name']}」")
        if m_leg["pct"] != b_leg["pct"]:
            bad.append(f"片头主线{i} 涨跌幅不一致：md=「{m_leg['pct']}」"
                       f" vs build_cards=「{b_leg['pct']}」")
    if len(md_intro["legs"]) != len(bd_intro["legs"]) and md_intro["legs"]:
        bad.append(f"片头主线行数不一致：md={len(md_intro['legs'])} "
                   f"vs build_cards={len(bd_intro['legs'])}")

    # ---- 概述行 -----------------------------------------------------------
    if md_intro["note"] and bd_intro["note"]:
        if md_intro["note"] != bd_intro["note"]:
            bad.append(f"片头概述行不一致：md=「{md_intro['note']}」"
                       f" vs build_cards=「{bd_intro['note']}」")

    # ---- B. countUp 参数 vs INTRO 显示值 ----------------------------------
    # INTRO 里第 i 行的 % → 对应 countUp 的 intro-big / intro-big2
    # ⚠ 用「每个数字元素都必须有对应 countUp」作判据：缺了也要报，不能静默跳过
    #   （静默跳过 = 闸门永远通过，正是本脚本自证时踩到的坑）。
    for key, idx in (("intro-big", 0), ("intro-big2", 1)):
        if idx >= len(bd_intro["legs"]):
            continue
        shown = bd_intro["legs"][idx]["pct"]
        if not shown:
            continue
        if key not in bd_intro["countup"]:
            bad.append(f"build_cards.py 里找不到 {key} 的 countUp() 调用 —— "
                       f"数字会停在 HTML 初始值、不做滚动。"
                       f"（若该行本来就不需要数字，请改用 .intro-hook-main.word "
                       f"并删掉对应 HTML span）")
            continue
        m = re.match(r"^([+\-]?)(\d+(?:\.\d+)?)%$", shown)
        if not m:
            continue
        shown_v = float((m.group(1) or "+") + m.group(2))
        cu_v = bd_intro["countup"][key]
        if abs(shown_v - cu_v) > 1e-9:
            bad.append(f"{key} 的 countUp 参数与 INTRO 显示值不一致："
                       f"INTRO=「{shown}」 vs countUp={cu_v:g}"
                       f"（渲染时会被 count-up 覆盖成 {cu_v:+g}%）")

    # ---- C. 旁白 intro 方向粗查 -------------------------------------------
    # 只抓「同一个名字 + 反方向动词」这种明确矛盾，别把正确表述当错误。
    # 做法：对每个片头主线名，看它在旁白里紧邻的 3 个字内出现的是涨词还是跌词。
    if nar_intro and md_intro["legs"]:
        UP_W = ("涨", "领涨", "走高", "拉升", "上攻", "反弹")
        DN_W = ("跌", "领跌", "走低", "下挫", "回落", "承压", "拖累")
        for l in md_intro["legs"]:
            nm = l["name"]
            if not nm or nm not in nar_intro:
                continue
            want_dn = l["pct"].startswith("-")
            # 取名字之后 6 个字符的窗口（「科创50领跌」→ 窗口含「领跌」）
            for mm in re.finditer(re.escape(nm), nar_intro):
                win = nar_intro[mm.end(): mm.end() + 6]
                hit_up = ("领涨" in win) or ("涨" in win and "跌" not in win)
                hit_dn = any(w in win for w in DN_W)
                if want_dn and hit_up and not hit_dn:
                    bad.append(
                        f"旁白 intro 段：md 里「{nm}」为下跌，"
                        f"但旁白写成了上涨语气 —— 「{nar_intro}」")
                if (not want_dn) and hit_dn and not hit_up:
                    bad.append(
                        f"旁白 intro 段：md 里「{nm}」为上涨，"
                        f"但旁白写成了下跌语气 —— 「{nar_intro}」")

    # ---- 输出 -------------------------------------------------------------
    ok = not bad
    if a.json:
        print(json.dumps({
            "ok": ok, "src": str(md_path),
            "md_intro": md_intro, "build_intro": bd_intro,
            "narration_intro": nar_intro, "issues": bad,
        }, ensure_ascii=False, indent=2))
    else:
        print(f"事实源：{md_path.relative_to(proj) if md_path.is_relative_to(proj) else md_path}")
        print(f"检查对象：build_cards.py（片头） + audio/gen_narration.py（旁白 intro）\n")
        print("md 片头主线：")
        for i, l in enumerate(md_intro["legs"], 1):
            print(f"  {i}. {l['name']}  {l['arrow']}  {l['pct']}")
        print("build_cards 片头主线：")
        for i, l in enumerate(bd_intro["legs"], 1):
            print(f"  {i}. {l['name']}  {l['pct']}")
        print()
        if ok:
            print("✅ 片头 / 概述 / countUp / 旁白 intro 全部与事实源对齐")
        else:
            print(f"❌ 发现 {len(bad)} 处不对齐 —— **必须改完再渲染**：\n")
            for i, b in enumerate(bad, 1):
                print(f"  [{i}] {b}")
            print("\n修法：改 md（唯一事实源）→ 重跑 build_cards.py → 再跑本脚本。"
                  "\n**不要直接手改 build_cards.py 的数字。**")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
