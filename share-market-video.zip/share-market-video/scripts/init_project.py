# -*- coding: utf-8 -*-
"""Scaffold a new hyperframes market-video project from a bundled template.

Usage:
    python init_project.py --mode a-share --out ./market-20260831
    python init_project.py --mode us      --out ./market-us-20260831
    python init_project.py --mode us --out ./x --name market-us-0831 --force

Creates:
    <out>/index.html          template composition (mode-specific)
    <out>/hyperframes.json    <out>/package.json   <out>/meta.json
    <out>/assets/gsap.min.js
    <out>/audio/gen_narration.py   <out>/audio/gen_bgm.py
"""
import argparse
import json
import os
import shutil
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATES = {
    "a-share": os.path.join(SKILL_DIR, "assets", "templates", "a-share"),
    "us": os.path.join(SKILL_DIR, "assets", "templates", "us"),
}
SCRIPTS = ["gen_narration.py", "gen_bgm.py"]
COPY_FILES = ["index.html", "hyperframes.json", "package.json", "meta.json"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=True, choices=sorted(TEMPLATES),
                    help="a-share = A股/港股/韩日 5 板块；us = 美股固定 4 板块")
    ap.add_argument("--out", required=True, help="目标工程目录")
    ap.add_argument("--name", default=None, help="工程名（默认用目录名）")
    ap.add_argument("--date", default=None,
                    help="交易日 YYYYMMDD；给出则从骨架生成 data/market-<date>.md（已存在不覆盖）")
    ap.add_argument("--force", action="store_true", help="目标非空时仍然写入")
    args = ap.parse_args()

    src = TEMPLATES[args.mode]
    out = os.path.abspath(args.out)
    name = args.name or os.path.basename(out.rstrip("\\/"))

    if not os.path.isdir(src):
        print(f"[error] 模板缺失：{src}", file=sys.stderr)
        return 1
    if os.path.isdir(out) and os.listdir(out) and not args.force:
        print(f"[error] 目标目录非空：{out}\n如需覆盖请加 --force", file=sys.stderr)
        return 1

    os.makedirs(out, exist_ok=True)
    for f in COPY_FILES:
        shutil.copy2(os.path.join(src, f), os.path.join(out, f))

    os.makedirs(os.path.join(out, "assets"), exist_ok=True)
    shutil.copy2(os.path.join(src, "assets", "gsap.min.js"),
                 os.path.join(out, "assets", "gsap.min.js"))

    audio_dir = os.path.join(out, "audio")
    os.makedirs(audio_dir, exist_ok=True)
    for s in SCRIPTS:
        shutil.copy2(os.path.join(SKILL_DIR, "scripts", s), os.path.join(audio_dir, s))

    # 行情数据落盘目录（第 2 步的 markdown 闸门用）
    data_dir = os.path.join(out, "data")
    os.makedirs(data_dir, exist_ok=True)
    data_md = None
    if args.date:
        data_md = os.path.join(data_dir, f"market-{args.date}.md")
        if os.path.exists(data_md):
            print(f"[skip] 行情数据文件已存在，不覆盖：{data_md}")
        else:
            tpl = os.path.join(SKILL_DIR, "assets", "market-data-template.md")
            if os.path.isfile(tpl):
                shutil.copy2(tpl, data_md)
            else:
                print(f"[warn] 骨架文件缺失：{tpl}", file=sys.stderr)
                data_md = None

    # rewrite project identity so hyperframes studio shows the right name
    pkg_path = os.path.join(out, "package.json")
    if os.path.exists(pkg_path):
        with open(pkg_path, encoding="utf-8") as f:
            pkg = json.load(f)
        pkg["name"] = name
        with open(pkg_path, "w", encoding="utf-8") as f:
            json.dump(pkg, f, ensure_ascii=False, indent=2)
    with open(os.path.join(out, "meta.json"), "w", encoding="utf-8") as f:
        json.dump({"id": name, "name": name}, f, ensure_ascii=False, indent=2)

    sections = 5 if args.mode == "a-share" else 4
    print(f"[ok] 工程已创建：{out}")
    print(f"     模式：{args.mode}（{sections} 个内容板块）")
    if data_md:
        print(f"     行情数据文件：{data_md}（填好后交用户确认）")
    print("\n下一步：")
    if data_md:
        print(f"  1. 抓取行情数据填入 {data_md}，做链式算术 + 多源交叉校验")
        print(f"  2. 展示该 md 等用户确认（可删减/补充），确认后才继续")
        print(f"  3. 按 md 编辑 {os.path.join(audio_dir, 'gen_narration.py')} 的 SEGMENTS；"
              f"运行 python {os.path.join(audio_dir, 'gen_narration.py')}")
        print(f"  4. 运行 python {os.path.join(audio_dir, 'gen_bgm.py')} <总秒数>")
        print(f"  5. 按 audio/segments.json 更新 {os.path.join(out, 'index.html')}")
    else:
        print(f"  1. 编辑 {os.path.join(audio_dir, 'gen_narration.py')} 的 SEGMENTS")
        print(f"  2. 运行 python {os.path.join(audio_dir, 'gen_narration.py')}")
        print(f"  3. 运行 python {os.path.join(audio_dir, 'gen_bgm.py')} <总秒数>")
        print(f"  4. 按 audio/segments.json 更新 {os.path.join(out, 'index.html')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
