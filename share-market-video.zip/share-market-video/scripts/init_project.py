# -*- coding: utf-8 -*-
"""Scaffold a new hyperframes market-video project from a bundled template.

Usage:
    python init_project.py --mode a-share --out ./market-20260831
    python init_project.py --mode us      --out ./market-us-20260831
    python init_project.py --mode us --out ./x --name market-us-0831 --force

Creates:
    <out>/index.html          composition（由 build_cards.py 生成，随模板带的示例数据）
    <out>/build_cards.py      卡片版引擎（改 SECTIONS / SEC*_PAGES 后重跑，写出 index.html）
    <out>/_base-head.html     版式基座（引擎读它；**必须与 build_cards.py 同目录**）
    <out>/build.sh            ★ 出片命令：build_cards.py + 追加默认星空背景层（改版式只跑这一条）
    <out>/hyperframes.json    <out>/package.json   <out>/meta.json
    <out>/assets/gsap.min.js
    <out>/audio/gen_narration.py   <out>/audio/gen_bgm.py   <out>/audio/resume_narration.py
"""
import argparse
import json
import os
import shutil
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATES = {
    "a-share": os.path.join(SKILL_DIR, "assets", "templates", "a-share"),
    "us": os.path.join(SKILL_DIR, "assets", "templates", "us"),
}
SCRIPTS = ["gen_narration.py", "gen_bgm.py", "resume_narration.py"]
# ⚠ `build_cards.py` / `_base-head.html` 必须一起拷：前者是真正的**版式载体**
#   （卡片分页 + 新结构 + 片头模板 都在里面），后者是它读的版式基座。
#   2026-09-30 前这两样都没打包，导致换了台机器只能退回包内的 2026-08-28 旧模板。
COPY_FILES = ["index.html", "build_cards.py", "_base-head.html",
              "hyperframes.json", "package.json", "meta.json"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=True, choices=sorted(TEMPLATES),
                    help="a-share = A股/港股/韩日 5 板块；us = 美股固定 4 板块")
    ap.add_argument("--out", required=True, help="目标工程目录")
    ap.add_argument("--name", default=None, help="工程名（默认用目录名）")
    ap.add_argument("--date", default=None,
                    help="交易日 YYYYMMDD；给出则从骨架生成 data/market-<date>.md（已存在不覆盖）")
    ap.add_argument("--force", action="store_true", help="目标非空时仍然写入")
    args = ap.parse_args()

    src = TEMPLATES[args.mode]
    out = os.path.abspath(args.out)
    name = args.name or os.path.basename(out.rstrip("\\/"))

    if not os.path.isdir(src):
        print(f"[error] 模板缺失：{src}", file=sys.stderr)
        return 1
    if os.path.isdir(out) and os.listdir(out) and not args.force:
        print(f"[error] 目标目录非空：{out}\n如需覆盖请加 --force", file=sys.stderr)
        return 1

    os.makedirs(out, exist_ok=True)
    for f in COPY_FILES:
        src_f = os.path.join(src, f)
        if not os.path.isfile(src_f):
            print(f"[error] 模板包不完整，缺文件：{src_f}\n"
                  f"        build_cards.py / _base-head.html 是版式载体，缺了只能退回旧版式 —— "
                  f"用 scripts/sync_template_from_project.py 重新回灌模板。", file=sys.stderr)
            return 1
        shutil.copy2(src_f, os.path.join(out, f))

    os.makedirs(os.path.join(out, "assets"), exist_ok=True)
    shutil.copy2(os.path.join(src, "assets", "gsap.min.js"),
                 os.path.join(out, "assets", "gsap.min.js"))

    audio_dir = os.path.join(out, "audio")
    os.makedirs(audio_dir, exist_ok=True)
    for s in SCRIPTS:
        shutil.copy2(os.path.join(SKILL_DIR, "scripts", s), os.path.join(audio_dir, s))

    # 行情数据落盘目录（第 2 步的 markdown 闸门用）
    data_dir = os.path.join(out, "data")
    os.makedirs(data_dir, exist_ok=True)
    data_md = None
    if args.date:
        data_md = os.path.join(data_dir, f"market-{args.date}.md")
        if os.path.exists(data_md):
            print(f"[skip] 行情数据文件已存在，不覆盖：{data_md}")
        else:
            tpl = os.path.join(SKILL_DIR, "assets", "market-data-template.md")
            if os.path.isfile(tpl):
                shutil.copy2(tpl, data_md)
            else:
                print(f"[warn] 骨架文件缺失：{tpl}", file=sys.stderr)
                data_md = None

    # rewrite project identity so hyperframes studio shows the right name
    pkg_path = os.path.join(out, "package.json")
    if os.path.exists(pkg_path):
        with open(pkg_path, encoding="utf-8") as f:
            pkg = json.load(f)
        pkg["name"] = name
        with open(pkg_path, "w", encoding="utf-8") as f:
            json.dump(pkg, f, ensure_ascii=False, indent=2)
    with open(os.path.join(out, "meta.json"), "w", encoding="utf-8") as f:
        json.dump({"id": name, "name": name}, f, ensure_ascii=False, indent=2)

    sections = 5 if args.mode == "a-share" else 4
    print(f"[ok] 工程已创建：{out}")
    print(f"     模式：{args.mode}（{sections} 个内容板块）")
    if data_md:
        print(f"     行情数据文件：{data_md}（填好后交用户确认）")

    # ------------------------------------------------------------------ 背景层
    # ★ 2026-09-30 用户定：**星空背景是默认**（不再是可选步骤）。
    #   落地方式（路径 A）= 生成一个 `build.sh` 到工程里，把「build_cards → apply_bg_layer」
    #   合成一条命令；**不改 `_base-head.html` / `build_cards.py`**，理由有两条：
    #     ① 基座必须保持"纯色底"的稳定版式载体 —— 把 #hfbg 固化进去会让所有场次的
    #        基座 diff 变化，破坏「改版式后才 diff」这条校验手段；
    #     ② 背景层是**追加**性质，index.html 是 build_cards.py 的生成物，每次重跑整个重写
    #        → 必须"每次 build 之后都追加一次"，脚本化比固化更能保证这个顺序不被漏掉。
    #   ⚠ 顺序是硬约束，写进 build.sh 就是为了让它不可能被搞反。
    #   ⚠ python 解释器**必须写绝对路径**：`apply_bg_layer.py` 要 PIL，
    #     而 PATH 上的 `python` 是没有 PIL 的基础解释器（2026-09-30 实测：
    #     用 `PY="${PY:-python}"` 时 build_cards 能过、apply_bg_layer 直接
    #     `ModuleNotFoundError: No module named 'PIL'`）。这里写死本机 venv，
    #     并留 `PY=` 环境变量允许覆盖（换机器时改一处即可）。
    #   ⚠ 路径一律用**正斜杠**：写进 build.sh 的是 bash 字符串，反斜杠虽多数情况能活，
    #     但遇到 `\U` `\t` 之类极易被误读；正斜杠在 bash 与 Windows python 下都成立。
    def _fw(p):
        return p.replace("\\", "/")

    venv_py = os.path.join(
        os.path.expanduser("~"), ".workbuddy", "binaries", "python",
        "envs", "default", "Scripts", "python.exe")
    if not os.path.isfile(venv_py):
        venv_py = sys.executable      # 兜底：换机器找不到 venv 时用当前解释器
    venv_py = _fw(venv_py)
    apply_py = _fw(os.path.join(SKILL_DIR, "scripts", "apply_bg_layer.py"))
    build_sh = os.path.join(out, "build.sh")
    with open(build_sh, "w", encoding="utf-8", newline="\n") as f:
        f.write(
            "#!/usr/bin/env bash\n"
            "# 生成 index.html（含默认的星空背景层）。\n"
            "# ⚠ 顺序硬约束：build_cards.py 每次重跑都**整个重写** index.html，\n"
            "#   背景层必须紧跟其后重新追加 —— 所以两件事合成本脚本，别拆开单跑。\n"
            "# 只想要纯色底（排障 / 省渲染时长与体积）：把最后一行注释掉即可。\n"
            "# ⚠ PY 必须是**装了 Pillow 的解释器**；PATH 上的 `python` 没有 PIL。\n"
            "set -e\n"
            "cd \"$(dirname \"$0\")\"\n"
            f"PY=\"${{PY:-{venv_py}}}\"\n"
            "\"$PY\" build_cards.py\n"
            f"\"$PY\" \"{apply_py}\" --proj .\n"
        )
    print(f"     背景层：星空为**默认**，已生成连跑脚本 {build_sh}")
    print(f"     解释器：{venv_py}（apply_bg_layer 依赖 Pillow）")

    print("\n下一步：")
    if data_md:
        print(f"  1. 抓取行情数据填入 {data_md}，做链式算术 + 多源交叉校验")
        print(f"  2. 展示该 md 等用户确认（可删减/补充），确认后才继续")
        print(f"  3. 按 md 编辑 {os.path.join(audio_dir, 'gen_narration.py')} 的 SEGMENTS；"
              f"运行 python {os.path.join(audio_dir, 'gen_narration.py')}")
        print(f"  4. 运行 python {os.path.join(audio_dir, 'gen_bgm.py')} <总秒数>")
        print(f"  5. 改 {os.path.join(out, 'build_cards.py')} 的 SECTIONS / SEC*_PAGES"
              f"（含指数卡的页必写 mini_at）")
    else:
        print(f"  1. 编辑 {os.path.join(audio_dir, 'gen_narration.py')} 的 SEGMENTS")
        print(f"  2. 运行 python {os.path.join(audio_dir, 'gen_narration.py')}")
        print(f"  3. 运行 python {os.path.join(audio_dir, 'gen_bgm.py')} <总秒数>")
        print(f"  4. 改 {os.path.join(out, 'build_cards.py')} 的 SECTIONS / SEC*_PAGES")
    print(f"  ★ 版式改完**只跑这一条**（生成 index.html + 追加星空背景层）：")
    print(f"      bash build.sh          # 或手动两条连跑，顺序不能反")
    print("  ⚠ index.html 是 build_cards.py 的**生成物**，别手改（下次重跑会被覆盖）。")
    print("  ⚠ 背景层检测到已存在会报错退出（不叠加）—— 见到它就是忘了走 build.sh。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
