'use strict';
/*
 * ff_stdin_shim.cjs — 绕开「同步 spawn + stdin 管道 = EBUSY」的 child_process 修补 shim
 *
 * 问题（2026-09-25 实测，本机确定性复现 12/12）
 * -------------------------------------------
 * 本机环境下，node 的 **同步** spawn 路径在 `stdio[0] === "pipe"`（给子进程建 stdin
 * 管道）时必然抛 `EBUSY`（libuv UV_EBUSY = -4082，Windows 侧等价 ERROR_PIPE_BUSY
 * 「管道已存在但实例全忙」）。表现为 hyperframes 渲染在第一步探针就死：
 *
 *     ✗  FFmpeg cannot start
 *        Failed to run "...\ffmpeg.exe" -version.
 *
 * 对照实测（同一进程、同一目标程序）：
 *     spawnSync / execFileSync + stdin=pipe   → 必 EBUSY
 *     spawn（异步）        + stdin=pipe        → 正常（子进程能收到父进程写入的数据）
 * 与目标程序、node 版本（22 / 24 都试过）、shell（bash / cmd / PowerShell）、
 * 是否禁用沙箱**都无关**。所以 hyperframes 里「execFileSync(ffmpeg, ['-version'])」
 * 这类探针全挂，而 puppeteer 起浏览器（异步 spawn）一路正常 —— 这也解释了为什么
 * `check` / `snapshot` 能过、`render` 必挂。
 *
 * 策略（只动「不需要 stdin」的调用，宁可不修补也不改语义）
 * ------------------------------------------------------
 * 命中以下任一 → 视为**需要 stdin**，原样放行、不修补：
 *     - options.input !== undefined
 *     - args 里出现裸 `-`（ffmpeg 的 `-i -`）或 `pipe:0`
 * 其余情况若 stdin 是管道（或 stdio 为默认三管道），改成 `"ignore"`。
 * 这样探针 / 音量测量 / 音频处理都能起来，而**真·喂帧编码**（`-f image2pipe -i -`）
 * 的管道语义保持不变。
 *
 * 用法
 * ----
 *   NODE_OPTIONS="--require=<本文件>" node <hyperframes cli> render ...
 * 或更稳（不依赖 env 传递、同时对子进程也生效）：用同目录的 render_with_shim.cjs 启动。
 *
 * 日志：`$HF_FFSHIM_LOG`，默认 `<cwd>/_ffshim.log`（每行一条被拦截/放行的调用）。
 * 关闭：`HF_FFSHIM=0`。
 */
const cp = require('child_process');
const fs = require('fs');
const path = require('path');

const LOG = process.env.HF_FFSHIM_LOG || path.join(process.cwd(), '_ffshim.log');
function log(line) {
  try { fs.appendFileSync(LOG, line + '\n'); } catch (_) { /* 日志失败不影响主流程 */ }
}

function argsNeedStdin(args) {
  if (!Array.isArray(args)) return false;
  for (const raw of args) {
    const a = String(raw);
    if (a.includes('pipe:0')) return true;
    if (a === '-') return true; // 裸 - 一律保守视为读 stdin
  }
  return false;
}

function describe(file, args) {
  const a = Array.isArray(args) ? args : [];
  const s = (a.length > 6 ? a.slice(0, 6).join(' ') + ' …' : a.join(' '));
  return path.basename(String(file)) + ' ' + s;
}

function fixOptions(opts, args) {
  const o = (opts && typeof opts === 'object' && !Array.isArray(opts)) ? opts : {};
  if (o.input !== undefined) return { opts: o, changed: false, why: 'has-input' };
  if (argsNeedStdin(args)) return { opts: o, changed: false, why: 'wants-stdin' };
  const s = o.stdio;
  if (s === 'pipe') {
    return { opts: { ...o, stdio: ['ignore', 'pipe', 'pipe'] }, changed: true, why: 'stdio-string-pipe' };
  }
  if (Array.isArray(s)) {
    if (s.length && s[0] === 'pipe') {
      const n = s.slice(); n[0] = 'ignore';
      return { opts: { ...o, stdio: n }, changed: true, why: 'stdio[0]=pipe' };
    }
    return { opts: o, changed: false, why: 'stdio-ok' };
  }
  if (s === undefined) {
    return { opts: { ...o, stdio: ['ignore', 'pipe', 'pipe'] }, changed: true, why: 'stdio-default-pipe' };
  }
  return { opts: o, changed: false, why: 'stdio-other' };
}

function wrap(file, args, opts, fnName, orig) {
  let realArgs = args;
  let realOpts = opts;
  if (!Array.isArray(realArgs)) { realOpts = realArgs; realArgs = []; }
  const r = fixOptions(realOpts, realArgs);
  log(`[${r.changed ? 'patch' : 'keep '}] ${fnName} ${r.why} | ${describe(file, realArgs)}`);
  if (r.opts === realOpts) return orig(file, realArgs, realOpts);
  return orig(file, realArgs, r.opts);
}

if (process.env.HF_FFSHIM !== '0') {
  try {
    const originals = {
      execFileSync: cp.execFileSync, execFile: cp.execFile,
      spawnSync: cp.spawnSync, spawn: cp.spawn,
      execSync: cp.execSync, exec: cp.exec,
    };
    cp.execFileSync = (f, a, o) => wrap(f, a, o, 'execFileSync', originals.execFileSync);
    cp.execFile = (f, a, o, cb) => wrap(f, a, o, 'execFile', originals.execFile);
    cp.spawnSync = (f, a, o) => wrap(f, a, o, 'spawnSync', originals.spawnSync);
    cp.spawn = (f, a, o) => wrap(f, a, o, 'spawn', originals.spawn);
    cp.execSync = (c, o) => wrap(c, [], o, 'execSync', originals.execSync);
    cp.exec = (c, o, cb) => wrap(c, [], o, 'exec', originals.exec);
    // 让 ESM 具名导入（esbuild 打包产物里的 `import { execFileSync }`）也看到补丁
    try { require('module').syncBuiltinESMExports(); } catch (e) { log('[warn] syncBuiltinESMExports: ' + e.message); }
    log('[init] shim installed pid=' + process.pid + ' argv=' + process.argv.slice(1, 3).join(' '));
  } catch (e) {
    log('[fatal] ' + e.message);
  }
}
