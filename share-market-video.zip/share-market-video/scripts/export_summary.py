# -*- coding: utf-8 -*-
"""Export a short **video description / summary** for a market-video project.

为什么需要它
------------
「旁白稿」是给耳朵的（完整、有时间轴），「视频概要」是给眼睛的（发布时粘在
描述栏，一两百字讲清今天发生了什么）。二者不能互替：旁白太长且带口语助词。

真源
----
`<PROJ>/summary.py` 里的 `SUMMARY` 字典（与旁白稿同时写，见 SKILL 第 4 步）。
本脚本用 `ast` 静态解析它（不 import，避免拉起依赖），渲染成：

    <PROJ>/video-summary-<date>.md    人读版（含段落表、校验结果）
    <PROJ>/video-summary-<date>.txt   可直接粘贴的纯文本版

并做一步**数字回查**：概要里出现的每个数字都必须在
`<PROJ>/data/market-<date>.md`（唯一事实源）里找得到 —— 防止手写概要时
把 4.14% 抄成 4.41%、把 2264 写成 2246。查不到只警告不中断。

用法
----
    python export_summary.py --project <工程目录> [--date YYYY-MM-DD] [--check-only]
"""
from __future__ import annotations

import argparse
import ast
import json
import re
import sys
from pathlib import Path

DEFAULT_DISCLAIMER = "投资有风险，视频内容不构成投资建议"

# 长度规格（发布平台的硬约束，超了脚本会警告）
MAX_TITLE = 30      # 标题字数
MAX_ONELINER = 60   # 一句话概要字数
MAX_POINT = 45      # 单条要点字数

# 概要里必须有的字段；缺失只提示、不报错（允许简写版）
KNOWN_FIELDS = ("title", "one_liner", "points", "tags", "disclaimer", "platform")

# 参与数字回查的字段白名单 —— `platform` 是制作规格（「30 字内 / 约 200 字」），
# 不是行情数据，混进来只会刷出一堆无意义的「命中」。
CHECK_FIELDS = ("title", "one_liner", "points")

# 回查前先遮掉的**非数据数字**：指数名里的数字、日期、规格数字。
# 不遮的话 `科创50`→`50`、`日经225`→`225`、`9月16日`→`16` 会全被当成数据点
# 塞进回查表，把真正的行情数字淹掉。
NAME_MASKS = (
    r"科创50", r"北证50", r"上证50", r"中证500", r"中证1000", r"国证2000",
    r"日经225", r"沪深300", r"沪深两市",
    r"\d{1,2}月\d{1,2}日",   # 日期
    r"\d+\s*字", r"\d+\s*秒", r"\d+\s*分",  # 规格 / 时长
)


# ------------------------------------------------------------------ 读取
def find_date(proj: Path) -> str | None:
    cands = sorted(proj.glob("data/market-*.md"))
    if not cands:
        return None
    m = re.search(r"market-(\d{8})\.md$", cands[-1].name)
    if not m:
        return None
    d = m.group(1)
    return f"{d[:4]}-{d[4:6]}-{d[6:]}"


def load_summary(proj: Path) -> dict | None:
    """静态解析 <PROJ>/summary.py 的 SUMMARY（不 import）。"""
    p = proj / "summary.py"
    if not p.exists():
        return None
    tree = ast.parse(p.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if getattr(t, "id", None) == "SUMMARY":
                    return ast.literal_eval(node.value)
    return None


def load_total(proj: Path) -> float | None:
    p = proj / "audio" / "segments.json"
    if not p.exists():
        return None
    try:
        return float(json.loads(p.read_text(encoding="utf-8")).get("total"))
    except Exception:  # noqa: BLE001
        return None


def load_segments(proj: Path) -> list[dict]:
    p = proj / "audio" / "segments.json"
    if not p.exists():
        return []
    try:
        return json.loads(p.read_text(encoding="utf-8")).get("segments", [])
    except Exception:  # noqa: BLE001
        return []


def fmt_duration(sec: float | None) -> str:
    if not sec:
        return "—"
    m, s = divmod(int(round(sec)), 60)
    return f"{m}分{s:02d}秒" if m else f"{s}秒"


# ------------------------------------------------------------------ 回查
def check_numbers(summary: dict, md_path: Path
                  ) -> tuple[list[str], list[tuple[str, list[str]]], list[str]]:
    """概要里的数字能否在事实源 md 里找到，并**回带出处上下文**。

    返回 (未命中, 命中+出处, 跳过)。

    为什么不能只做「命中/未命中」：纯子串匹配防不了**张冠李戴**。
    实测把「科创50 涨 4.14%」误写成 4.41 时不会报错 —— 因为 md 里
    恰好有「CPO +4.41%」，子串撞上了。所以这里把每个数字在 md 中的
    **原文片段**一并带出来，让人一眼看出「这个 4.41 出自 CPO，不是科创50」。

    匹配时把 md 与概要里的逗号都去掉，使「2264」能命中 md 的「2,264.05」。
    长度 <2 的数字跳过（「8 个宽基」里的 8 到处都是，查了没意义）。
    """
    if not md_path.exists():
        return [], [], []
    raw = md_path.read_text(encoding="utf-8")
    flat = re.sub(r"\s+", " ", raw)
    # md 里所有数字及其上下文
    index: dict[str, list[str]] = {}
    for m in re.finditer(r"\d[\d,]*\.?\d*", flat):
        key = m.group(0).replace(",", "").rstrip(".")
        if len(key) < 2:
            continue
        lo, hi = max(0, m.start() - 20), min(len(flat), m.end() + 16)
        ctx = ("…" if lo else "") + flat[lo:hi].strip() + ("…" if hi < len(flat) else "")
        bucket = index.setdefault(key, [])
        if ctx not in bucket and len(bucket) < 2:
            bucket.append(ctx)

    text = _check_text(summary)
    miss, found, skipped = [], [], []
    seen = set()
    for tok in re.findall(r"\d[\d,]*\.?\d*", text):
        t = tok.replace(",", "").rstrip(".")
        if len(t) < 2:
            skipped.append(tok)
            continue
        if t in seen:
            continue
        seen.add(t)
        # ① 精确命中；② 前缀命中（概要写「2264」而 md 写「2,264.05」）
        ctxs = index.get(t)
        if not ctxs:
            ctxs = [c for k in index if k.startswith(t) for c in index[k]][:2]
        if ctxs:
            found.append((t, ctxs))
        elif t in re.sub(r"\s", "", raw):
            found.append((t, ["（仅子串命中，无独立数字上下文）"]))
        else:
            miss.append(t)
    return miss, found, skipped


def _check_text(summary: dict) -> str:
    """取出参与回查的文本，并遮掉指数名/日期/规格里的数字。"""
    parts = []
    for k in CHECK_FIELDS:
        v = summary.get(k)
        if isinstance(v, str):
            parts.append(v)
        elif isinstance(v, (list, tuple)):
            parts.extend(str(x) for x in v)
    text = " ".join(parts)
    for pat in NAME_MASKS:
        text = re.sub(pat, " ", text)
    return text


# ------------------------------------------------------------------ 渲染
def length_issues(s: dict) -> list[str]:
    """发布平台的长度规格检查。"""
    out = []
    t = s.get("title", "")
    if len(t) > MAX_TITLE:
        out.append(f"标题 {len(t)} 字 > {MAX_TITLE} 字：{t}")
    ol = s.get("one_liner", "")
    if len(ol) > MAX_ONELINER:
        out.append(f"一句话概要 {len(ol)} 字 > {MAX_ONELINER} 字")
    for p in s.get("points", []):
        if len(p) > MAX_POINT:
            out.append(f"要点 {len(p)} 字 > {MAX_POINT} 字：{p[:18]}…")
    if not 3 <= len(s.get("points", [])) <= 5:
        out.append(f"要点条数 {len(s.get('points', []))} 条，建议 3~5 条")
    if not 5 <= len(s.get("tags", [])) <= 8:
        out.append(f"话题标签 {len(s.get('tags', []))} 个，建议 5~8 个")
    return out


def render_md(s: dict, date: str, total: float | None, segs: list[dict],
              miss: list[str], found: list[tuple[str, list[str]]],
              skipped: list[str], lens: list[str]) -> str:
    o = [f"# 视频文字概要 · {date}", ""]
    o.append("<!-- 发布用描述文案。真源：<PROJ>/summary.py 的 SUMMARY；"
             "由 scripts/export_summary.py 导出。 -->")
    o.append("")
    o.append(f"- 标题（{len(s.get('title', ''))} 字，上限 {MAX_TITLE}）：{s.get('title', '—')}")
    o.append(f"- 视频时长：{fmt_duration(total)}")
    o.append(f"- 一句话概要（{len(s.get('one_liner', ''))} 字，上限 {MAX_ONELINER}）")
    if s.get("platform"):
        o.append(f"- 适配平台：{s['platform']}")
    if lens:
        o.append("")
        o.append(f"- ⚠ **{len(lens)} 处长度超规格**：")
        for x in lens:
            o.append(f"  - {x}")
    o.append("")

    o.append("## 一句话概要")
    o.append("")
    o.append(s.get("one_liner", "—"))
    o.append("")

    if s.get("points"):
        o.append("## 要点")
        o.append("")
        for p in s["points"]:
            o.append(f"- {p}")
        o.append("")

    if s.get("tags"):
        o.append("## 话题标签")
        o.append("")
        o.append(" ".join(f"#{t}" for t in s["tags"]))
        o.append("")

    o.append("## 片尾提示")
    o.append("")
    o.append(s.get("disclaimer", DEFAULT_DISCLAIMER))
    o.append("")

    o.append("## 数字回查（对 `data/market-*.md`）")
    o.append("")
    if miss:
        o.append(f"- ⚠ **{len(miss)} 个数字在事实源里找不到，必须人工核对**："
                 + "、".join(f"`{m}`" for m in miss))
    else:
        o.append("- ✅ 概要中每个数字都能在事实源中找到")
    o.append("- ⚠ 仅「找得到」≠「用对了」：请扫一眼下表出处，确认不是**张冠李戴**"
             "（数字在 md 里属另一实体）。")
    if skipped:
        o.append(f"- （跳过 {len(skipped)} 个单字符数字：{'、'.join(skipped[:12])}"
                 + ("…" if len(skipped) > 12 else "") + "）")
    o.append("")
    if found:
        o.append("| 概要数字 | 事实源出处 |")
        o.append("|---|---|")
        for tok, ctxs in found:
            cells = "<br>".join(c.replace("|", "\\|") for c in ctxs)
            o.append(f"| `{tok}` | {cells} |")
        o.append("")

    if segs:
        o.append("## 段落结构（供对齐封面/章节）")
        o.append("")
        o.append("| # | 段落 | 起始 | 时长 |")
        o.append("|---|---|---|---|")
        for i, t in enumerate(segs):
            o.append(f"| {i} | `{t['name']}` | {t['start']:.2f}s | "
                     f"{t['duration']:.2f}s |")
        o.append("")
    return "\n".join(o)


def render_txt(s: dict) -> str:
    o = [s.get("title", ""), ""]
    if s.get("one_liner"):
        o += [s["one_liner"], ""]
    for p in s.get("points", []):
        o.append(f"· {p}")
    if s.get("points"):
        o.append("")
    if s.get("tags"):
        o.append(" ".join(f"#{t}" for t in s["tags"]))
        o.append("")
    o.append(s.get("disclaimer", DEFAULT_DISCLAIMER))
    return "\n".join(o).strip() + "\n"


# ------------------------------------------------------------------ main
def main() -> None:
    ap = argparse.ArgumentParser(
        description="导出股市视频的文字概要（发布用描述文案）")
    ap.add_argument("--project", default=".", help="工程目录（默认当前目录）")
    ap.add_argument("--date", help="覆盖日期（默认从 data/market-*.md 推断）")
    ap.add_argument("--check-only", action="store_true",
                    help="只做数字回查，不写文件")
    a = ap.parse_args()

    proj = Path(a.project).resolve()
    if not proj.is_dir():
        print(f"[error] 不是目录：{proj}", file=sys.stderr)
        sys.exit(1)

    summary = load_summary(proj)
    if summary is None:
        print(f"[error] 找不到 {proj / 'summary.py'} 里的 SUMMARY。\n"
              "        请先写 <PROJ>/summary.py（见 SKILL 第 4 步）。",
              file=sys.stderr)
        sys.exit(2)

    date = a.date or find_date(proj) or "unknown"
    md_path = proj / "data" / f"market-{date.replace('-', '')}.md"
    total = load_total(proj)
    segs = load_segments(proj)
    miss, found, skipped = check_numbers(summary, md_path)
    lens = length_issues(summary)

    print(f"[summary] project = {proj}")
    print(f"[summary] date    = {date}")
    print(f"[summary] total   = {fmt_duration(total)}")
    print(f"[summary] title   = {summary.get('title')}")
    if miss:
        print(f"[check]   ⚠ {len(miss)} 个数字未在事实源命中：{'、'.join(miss)}")
    else:
        print(f"[check]   ✅ {len(found)} 个数字全部可在事实源中找到"
              "（出处见输出文件，注意核对有无张冠李戴）")
    if not md_path.exists():
        print(f"[check]   注意：事实源不存在（{md_path}），跳过校验")
    for x in lens:
        print(f"[length]  ⚠ {x}")
    if not lens:
        print("[length]  ✅ 标题/概要/要点/标签长度均合规格")

    if a.check_only:
        return

    md_out = proj / f"video-summary-{date}.md"
    txt_out = proj / f"video-summary-{date}.txt"
    md_out.write_text(
        render_md(summary, date, total, segs, miss, found, skipped, lens),
        encoding="utf-8")
    txt_out.write_text(render_txt(summary), encoding="utf-8")
    print(f"[write]   {md_out}")
    print(f"[write]   {txt_out}")


if __name__ == "__main__":
    main()
