# -*- coding: utf-8 -*-
"""消除 hyperframes 在 Windows 上弹出的 chrome 控制台黑框。

问题
----
渲染或刷新 studio 时，会弹出约 4 个 `chrome-headless-shell.exe` 命令行窗口。

根因（不是玄学，是 Windows API 的明文规定）
------------------------------------------
`@puppeteer/browsers/lib/launch.js` 这样起浏览器：

    opts.detached ??= true;                 // → CreateProcess 的 DETACHED_PROCESS
    childProcess.spawn(exe, args, {
      detached: opts.detached,              // → DETACHED_PROCESS
      windowsHide: true,                    // → CREATE_NO_WINDOW（**被忽略**）
    });

MSDN 对 `CreateProcessW` 的 `CREATE_NO_WINDOW` 写道：

    This flag is ignored if the application is not a console application,
    or if used with either CREATE_NEW_CONSOLE or DETACHED_PROCESS.

而 `chrome-headless-shell.exe` 恰好是 **CONSOLE 子系统**（普通 `chrome.exe` 是
GUI 子系统，所以不弹）。于是：`DETACHED_PROCESS` 让子进程**不继承**父控制台，
`CREATE_NO_WINDOW` 又被忽略 → 系统给每个 chrome 进程**新分配一个可见控制台窗口**。
hyperframes 一次 snapshot/render 会起多个浏览器进程（GPU 探测 + 抓取池），
所以一次弹 ~4 个。

修法
----
把默认改成 `detached: false` → `CREATE_NO_WINDOW` 生效 → 无窗口。
（`detached` 只影响进程组归属与信号传播；stdio 是管道、puppeteer 本来也
不显式传 detached，改动面很小。）

用法
----
    python patch_hyperframes_nowindow.py            # 施加补丁（幂等，可重复跑）
    python patch_hyperframes_nowindow.py --check     # 只看状态，不改文件
    python patch_hyperframes_nowindow.py --revert    # 从 .bak 还原

⚠ npx 缓存（`_npx/<hash>/`）被重新安装后补丁会丢 —— 重装 hyperframes 后重跑一次即可。
"""
from __future__ import annotations

import argparse
import glob
import os
import shutil
import sys

MARKER = "hyperframes-nowindow"
ORIGINAL = "opts.detached ??= true;"
PATCHED = f"opts.detached ??= false; // {MARKER}: CREATE_NO_WINDOW 才能生效"


def candidates() -> list[str]:
    """在所有 npx 缓存里找 @puppeteer/browsers 的 launch.js。"""
    roots = [
        os.path.expanduser("~/.workbuddy/tmp/npm-cache/_npx"),
        os.path.expanduser("~/.npm/_npx"),
        os.path.expanduser("~/AppData/Local/npm-cache/_npx"),
    ]
    hits: list[str] = []
    for root in roots:
        if not os.path.isdir(root):
            continue
        pat = os.path.join(root, "*", "node_modules", "@puppeteer",
                           "browsers", "lib", "launch.js")
        hits += glob.glob(pat)
    return sorted(set(hits))


def state(path: str) -> str:
    src = open(path, encoding="utf-8").read()
    if MARKER in src:
        return "patched"
    if ORIGINAL in src:
        return "original"
    return "unknown"


def main() -> None:
    ap = argparse.ArgumentParser(description="消除 chrome 控制台黑框补丁")
    ap.add_argument("--check", action="store_true", help="只报状态")
    ap.add_argument("--revert", action="store_true", help="从 .bak 还原")
    a = ap.parse_args()

    files = candidates()
    if not files:
        print("[error] 没找到 @puppeteer/browsers/lib/launch.js —— "
              "hyperframes 还没被 npx 缓存过？先跑一次 hyperframes 再试。",
              file=sys.stderr)
        sys.exit(2)

    changed = skipped = 0
    for p in files:
        st = state(p)
        tag = f"{st:9} {p}"
        if a.check:
            print(tag)
            continue
        if a.revert:
            bak = p + ".bak"
            if os.path.exists(bak):
                shutil.copy2(bak, p)
                print(f"reverted  {p}")
                changed += 1
            else:
                print(f"no .bak    {p}")
            continue
        if st == "patched":
            print(f"already   {p}")
            skipped += 1
            continue
        if st != "original":
            print(f"unknown   {p}（target 串没找到，未改动）")
            continue
        bak = p + ".bak"
        if not os.path.exists(bak):
            shutil.copy2(p, bak)
        src = open(p, encoding="utf-8").read()
        open(p, "w", encoding="utf-8", newline="").write(
            src.replace(ORIGINAL, PATCHED, 1))
        print(f"PATCHED   {p}")
        changed += 1

    if not a.check:
        verb = "还原" if a.revert else "打补丁"
        print(f"\n==> {verb}完成：改动 {changed} 个，跳过 {skipped} 个")
        if changed and not a.revert:
            print("    之后渲染 / 刷新 studio 不再弹 chrome 黑框。")
            print("    重装 hyperframes（npx 缓存换 hash）后需重跑本脚本。")


if __name__ == "__main__":
    main()
