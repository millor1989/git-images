#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""check_source_numbers.py —— 画面数字「对源」检查（渲染前跑，秒级）。

为什么需要它：
  链式算术只能验「内部一致性」，验不了「口径正确性」，更验不了
  「这个数字根本不在确认版数据源里」。手工目视折行时顺带扫数字，
  极易漏掉凭印象写进去的数（本期 2026-09-24 就写了个源里没有的
  「哔哩哔哩 −1.94%」，抽 14 帧才逮到）。

口径：
  · 事实源 = <proj>/data/*.md 里最后一版（即已确认的那份）全文。
  · 检查对象 = build_cards.py 的 C() 画面 chip（名称/值/副行）、
    K() 卡标题、以及每屏 lead 文案里的**所有数字**。
  · 归一化：剥掉 \\uXXXX 转义 → 去掉千分位逗号 → 负号保留在 token 外。
  · 白名单 = 年份、日期、cm/连板数、TOP 名次这类非行情数字（见 NOISE），
    需要时用 --noise 追加。

用法（工程根目录）：
    python qa/check_source_numbers.py                    # 用 data/*.md 里最新一份
    python qa/check_source_numbers.py --src data/x.md    # 指定源
    python qa/check_source_numbers.py --noise 30,50      # 追加白名单

退出码：0 = 全部有出处；1 = 有无源数字（并逐条打印上下文）。
"""
from __future__ import annotations

import argparse
import glob
import pathlib
import re
import sys

# 非行情数字白名单：年份 / 交易日 / cm 与连板 / 名次序号
NOISE = set("""1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
21 22 23 24 25 26 27 28 29 30 2007 2026""".split())

UNESC = re.compile(r"\\u[0-9a-fA-F]{4}")
NUM = re.compile(r"\d[\d,]*(?:\.\d+)?")


def norm(t: str) -> str:
    """剥转义 + 去千分位，保留数字本体。"""
    return UNESC.sub("", t).replace(",", "")


def nums(t: str):
    for m in NUM.finditer(norm(t)):
        yield m.group(0).replace(",", "")


def pick_source(proj: pathlib.Path, explicit: str | None) -> pathlib.Path:
    if explicit:
        return (proj / explicit) if not pathlib.Path(explicit).is_absolute() else pathlib.Path(explicit)
    cands = sorted(glob.glob(str(proj / "data" / "*.md")),
                   key=lambda p: pathlib.Path(p).stat().st_mtime)
    if not cands:
        raise SystemExit("[error] data/*.md 不存在")
    return pathlib.Path(cands[-1])


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--proj", default=".")
    ap.add_argument("--src", default=None, help="事实源 md（默认取 data/*.md 最新一份）")
    ap.add_argument("--build", default="build_cards.py")
    ap.add_argument("--noise", default="", help="追加白名单，逗号分隔")
    args = ap.parse_args()

    proj = pathlib.Path(args.proj).resolve()
    src = pick_source(proj, args.src)
    build = proj / args.build
    if not build.exists():
        raise SystemExit(f"[error] {build} 不存在")

    md = norm(src.read_text(encoding="utf-8"))
    code = build.read_text(encoding="utf-8")
    noise = set(NOISE) | {x.strip() for x in args.noise.split(",") if x.strip()}

    print(f"事实源：{src.relative_to(proj)}  ({len(md)} 字)")
    print(f"检查对象：{args.build}\n")

    items: list[tuple[str, str, str]] = []          # (类别, 名称/位置, 文案)
    for name, val, sub in re.findall(
            r'C\(\s*"([^"]*)"\s*,\s*"([^"]*)"\s*,\s*"\w+"\s*,\s*"([^"]*)"', code):
        items.append(("chip值", name, val))
        items.append(("chip副行", name, sub))
    for title in re.findall(r'K\(\s*"\w+"\s*,\s*"([^"]*)"\s*,', code):
        items.append(("卡标题", title, title))
    for lead in re.findall(r'"lead"\s*:\s*\'([^\']*)\'', code):
        items.append(("lead", "-", re.sub(r"<[^>]+>", "", lead)))

    miss, checked = [], 0
    for kind, name, text in items:
        for n in nums(text):
            if n in noise:
                continue
            checked += 1
            if n not in md:
                miss.append((kind, name, text, n))

    print(f"共核对 {len(items)} 条文案 / {checked} 个数字")
    if not miss:
        print("\n✅ 所有画面数字均能在事实源中找到出处")
        return 0

    print(f"\n❌ 有 {len(miss)} 处数字在事实源中找不到出处（可能是凭印象写的）：")
    for kind, name, text, n in miss:
        print(f"   [{kind}] {name}：{text!r}  → 未找到 {n}")
    print("\n处理：① 从事实源里挑一个口径正确的数替换；② 或删掉该数字；"
          "③ 若确认数无误，先把事实源补齐（走用户确认）再回填。")
    return 1


if __name__ == "__main__":
    sys.exit(main())
