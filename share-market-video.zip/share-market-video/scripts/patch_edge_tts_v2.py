# -*- coding: utf-8 -*-
"""把 edge-tts 的合成端点从已下线的 v1 切到 v2（api.msedgeservices.com）。

背景（2026-10-12 实测定位）
---------------------------
微软把 Edge「大声朗读」的合成 WebSocket 从 v1（`speech.platform.bing.com`）迁到
v2（`api.msedgeservices.com`）。v1 自 2026-10-12 起在全球陆续返回 HTTP 403，
现象是 `WSServerHandshakeError: 403, message='Invalid response status'`
（上游 issue: https://github.com/rany2/edge-tts/issues/490，至今未关）。

排障时最容易踩的三个坑（本机已逐一实测证伪，别再重复走）：
  1. **不是出口 IP**：6 个国家出口 + DIRECT 全 403，与 IP 无关。
  2. **不是时钟**：本机与服务器 `Date` 头差 <1 秒。
  3. **不是 Sec-MS-GEC 算法 / 版本号**：版本号 143→152→154→155 全 403；
     而且 `voices/list` **从不校验签名**（故意写错 GEC / 填假版本 `1-999.0.0.0` /
     完全不传，全都返回 200）—— 所以「`voices/list` 能通」**不能**当凭证有效的证据。

真正的修法：**换 host**，并把 token 改从 `Ocp-Apim-Subscription-Key` 传参
（token 值不变）；legacy 的 `Sec-MS-GEC` / `Sec-MS-GEC-Version=1-143.0.3650.75`
沿用即可。输出格式与旧 host 完全一致：mp3 / 24000 Hz / mono / 48 kbps。

用法
----
    python patch_edge_tts_v2.py                # 打补丁（幂等，首次自动备份 .py.v1bak）
    python patch_edge_tts_v2.py --check        # 只查状态：v2 -> exit 0，v1 -> exit 1
    python patch_edge_tts_v2.py --verify       # 打完跑一次真实合成
    python patch_edge_tts_v2.py --verify --proxy http://127.0.0.1:7890

⚠️ 重装 / 升级 edge-tts 会覆盖 site-packages，补丁需要重打 —— 本脚本就是为此存在。
⚠️ 必须用**跑 gen_narration 的那个解释器**执行（受管 venv 与系统 python 的
   site-packages 是两份），否则打在了另一个副本上。
⚠️ 新端点速率限制更严：连测 6 次左右会返 **429**，症状与 403 同样是
   `Invalid response status`，极易误读成「没修好」。403 = 被拒（端点问题）；
   429 = 限流（等 60~100s 重试）。`--verify` 已内置退避重试。
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
import time
from pathlib import Path

NEW_BASE = "api.msedgeservices.com/tts/cognitiveservices"
NEW_HOST = "api.msedgeservices.com"
NEW_VER = "155.0.4283.45"
OLD_HOST = "speech.platform.bing.com"

REPL = [
    (
        re.compile(r'^BASE_URL = ".*?"\s*$', re.M),
        f'BASE_URL = "{NEW_BASE}"',
    ),
    (
        re.compile(r'^WSS_URL = f"wss://\{BASE_URL\}/.*?$', re.M),
        'WSS_URL = f"wss://{BASE_URL}/websocket/v1'
        '?Ocp-Apim-Subscription-Key={TRUSTED_CLIENT_TOKEN}"',
    ),
    (
        re.compile(r'^VOICE_LIST = f"https://\{BASE_URL\}/.*?$', re.M),
        'VOICE_LIST = f"https://{BASE_URL}/voices/list'
        '?Ocp-Apim-Subscription-Key={TRUSTED_CLIENT_TOKEN}"',
    ),
    (
        re.compile(r'^CHROMIUM_FULL_VERSION = ".*?"\s*$', re.M),
        f'CHROMIUM_FULL_VERSION = "{NEW_VER}"',
    ),
    (
        re.compile(r'^    "Authority": ".*?",\s*$', re.M),
        f'    "Authority": "{NEW_HOST}",',
    ),
]


def constants_path() -> Path:
    import edge_tts
    return Path(edge_tts.__file__).parent / "constants.py"


def endpoint_status(text: str) -> tuple[str, bool]:
    """返回 (人话描述, 是否已是 v2)。"""
    if NEW_HOST in text:
        return "v2 ✅（可用）", True
    if OLD_HOST in text:
        return "v1 ❌（2026-10-12 起全球 403）", False
    return "未知（constants.py 里找不到已知 host）", False


def _verify(proxy: str | None, attempts: int = 4) -> int:
    """跑一次真实合成。403 -> 明确报端点错误；429 -> 退避重试。"""
    import asyncio

    import edge_tts

    async def go() -> int:
        last = ""
        for i in range(attempts):
            n = 0
            try:
                c = edge_tts.Communicate("补丁验证，测试。", "zh-CN-XiaoxiaoNeural",
                                         proxy=proxy)
                async for ch in c.stream():
                    if ch["type"] == "audio":
                        n += len(ch["data"])
            except Exception as e:  # noqa: BLE001
                last = f"{type(e).__name__}: {e}"
                if "429" in last:
                    wait = 20 * (i + 1)
                    print(f"[edge-tts] 429 限流，等 {wait}s 重试（第 {i + 1}/{attempts} 次）")
                    await asyncio.sleep(wait)
                    continue
                if "403" in last:
                    print("[edge-tts] 403 —— 端点仍被拒，补丁没生效或微软又改了端点")
                else:
                    print(f"[edge-tts] 失败 {last[:140]}"
                          "（若为 Cannot connect / 超时，本机直连境外随机失败，"
                          f"加 --proxy {proxy or 'http://127.0.0.1:7890'} 重试）")
                await asyncio.sleep(3)
                continue
            if n:
                print(f"[edge-tts] 合成验证 audio_bytes={n} ✅（proxy={proxy or 'direct'}）")
                return 0
            last = "返回 0 字节（多半撞 429 留下了空文件）"
            await asyncio.sleep(5)
        print(f"[edge-tts] 合成验证失败：{last[:160]}")
        return 1

    return asyncio.run(go())


def main() -> int:
    ap = argparse.ArgumentParser(description="edge-tts v1 -> v2 端点补丁")
    ap.add_argument("--check", action="store_true", help="只检查状态，不改动")
    ap.add_argument("--verify", action="store_true", help="打完跑一次真实合成")
    ap.add_argument("--proxy", default=None,
                    help="--verify 用的代理（本机建议 http://127.0.0.1:7890）")
    a = ap.parse_args()

    p = constants_path()
    src = p.read_text(encoding="utf-8")
    desc, is_v2 = endpoint_status(src)
    print(f"[edge-tts] constants = {p}")
    print(f"[edge-tts] 当前端点 = {desc}")

    if a.check and not a.verify:
        return 0 if is_v2 else 1

    if is_v2:
        print("[edge-tts] 已是 v2，无需改动")
    else:
        bak = p.with_suffix(".py.v1bak")
        if not bak.exists():
            shutil.copy2(p, bak)
            print(f"[edge-tts] 已备份 -> {bak.name}")
        out = src
        for rx, rep in REPL:
            out, n = rx.subn(rep, out)
            print(f"[edge-tts] {rx.pattern[:38]:42s} 替换 {n} 处")
        p.write_text(out, encoding="utf-8")
        print(f"[edge-tts] 补丁完成 -> {endpoint_status(out)[0]}")
        leftover = "\n".join(
            ln for ln in out.splitlines()
            if OLD_HOST in ln and not ln.lstrip().startswith("#"))
        if leftover:
            print("[edge-tts] ⚠ 正文仍残留旧 host，请人工检查：")
            print("          " + leftover.replace("\n", "\n          "))

    if a.verify:
        time.sleep(1)
        return _verify(a.proxy)
    return 0


if __name__ == "__main__":
    sys.exit(main())
