# -*- coding: utf-8 -*-
"""bg_zones_heat.py — 从**上一期成片**算出「内容占空热力图」，用来给闪烁星 / hero 主星挑安全区。

为什么需要它：星空背景上线后，活的闪烁星必须避开信息卡片。凭感觉画矩形会翻车
（第一版把右竖带起点放在 x=0.56，抽帧一看有几颗就闪在卡片里面；右上区第一版
  下边界放到 y=0.205，实测 A股 12.8% / 美股 18.6% 有内容）。
正确做法是拿**上一期成片**量：哪些像素在整片里有文字/图形 → 那些地方就是禁区。

用法：
  python bg_zones_heat.py <成片.mp4> [--fps 1] [--out _heat]

产物：
  <out>.png   1080x1920 的 8bit 占空图（像素值 = 该点在抽样帧里「有内容」的比例 ×255）
  终端打印 24x16 的占空格网，以及 apply_bg_layer.py 里那份 LIVE_ZONES 的实测占空

⚠ **这里的区定义直接 import 自 `apply_bg_layer.py`**，不是另抄一份 —— 否则改了那边的
   LIVE_ZONES 而这边没跟着改，量出来的是"另一个方案"的占空，等于白量一轮。
   换版式（改 SECTIONS / 卡片布局 / 换市场）之后必须重跑本脚本复测；
   A股 与 美股 共用同一份 LIVE_ZONES（2026-09-30 双市场复测通过）。

判据说明（实测调出来的）：
  · 「有内容」= 局部对比度（|dx|+|dy|）经 16px 盒滤波后 > 6 —— 能把文字/卡片描边抓出来，
    又不会被大面积柔和辉光（.glow）误判
  · 再用 31px 的 MaxFilter 膨胀一次 —— 把「偶尔有内容」也划进禁区，留出安全边距
  · 逐区用「有内容像素占比」而不是「平均占空」：后者会把少量文字稀释到看不出来
"""
import argparse
import os
import subprocess
import sys

import numpy as np
from PIL import Image, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
from apply_bg_layer import LIVE_ZONES, HERO_STARS, W, H   # noqa: E402  （同一份定义，不抄）

# [名称, x0, x1, y0, y1] —— 从 LIVE_ZONES 派生，行末权重不参与测量
ZONES = [("区%d" % (i + 1), z[0], z[1], z[2], z[3]) for i, z in enumerate(LIVE_ZONES)]


def frame_heat(img):
    """单帧 → 「有内容」软掩码（局部对比度 + 大盒滤波）。"""
    a = np.asarray(img.convert("L"), dtype=np.float32)
    gx = np.zeros_like(a)
    gy = np.zeros_like(a)
    gx[:, 1:-1] = np.abs(a[:, 2:] - a[:, :-2])
    gy[1:-1, :] = np.abs(a[2:, :] - a[:-2, :])
    g = np.clip(gx + gy, 0, 255).astype(np.uint8)
    d = np.asarray(Image.fromarray(g).filter(ImageFilter.BoxBlur(16)), dtype=np.float32)
    return (d > 6.0).astype(np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--fps", type=float, default=1.0)
    ap.add_argument("--out", default=os.path.join(HERE, "_heat"))
    ap.add_argument("--ffmpeg", default=os.environ.get("FFMPEG", "ffmpeg"))
    ap.add_argument("--tmp", default=os.path.join(HERE, "_frames"))
    args = ap.parse_args()

    os.makedirs(args.tmp, exist_ok=True)
    pattern = os.path.join(args.tmp, "f%04d.jpg")
    print("[1/3] 抽帧 %.1f fps → %s" % (args.fps, args.tmp))
    subprocess.run([args.ffmpeg, "-v", "error", "-i", args.video,
                    "-vf", "fps=%g" % args.fps, "-q:v", "3", pattern, "-y"], check=True)
    files = sorted(f for f in os.listdir(args.tmp) if f.endswith(".jpg"))
    if not files:
        sys.exit("抽帧失败：%s 里没有 jpg" % args.tmp)
    print("      共 %d 帧" % len(files))

    print("[2/3] 累加占空")
    acc = None
    for i, f in enumerate(files, 1):
        im = Image.open(os.path.join(args.tmp, f))
        if im.size != (W, H):
            print("      ⚠ 尺寸 %s ≠ %dx%d，热力图坐标系会对不上" % (im.size, W, H))
        m = frame_heat(im)
        acc = m if acc is None else acc + m
        if i % 20 == 0:
            print("      %d/%d" % (i, len(files)))
    heat = acc / len(files)
    Image.fromarray((np.clip(heat, 0, 1) * 255).astype(np.uint8)).save(args.out + ".png")
    print("      → %s.png  (最大值 %.3f / 均值 %.3f)" % (args.out, heat.max(), heat.mean()))

    occ = np.asarray(Image.fromarray((heat * 255).astype(np.uint8))
                     .filter(ImageFilter.MaxFilter(31)), dtype=np.float32) / 255.0
    print("[3/3] 逐区实测（31px 膨胀后）—— 区定义来自 apply_bg_layer.py 的 LIVE_ZONES")
    for (n, x0, x1, y0, y1), z in zip(ZONES, LIVE_ZONES):
        a = occ[int(y0 * H):int(y1 * H), int(x0 * W):int(x1 * W)]
        print("      %-6s x %.3f-%.3f y %.3f-%.3f  平均占空 %.4f  有内容像素 %5.1f%%  (权重 %.1f)"
              % (n, x0, x1, y0, y1, a.mean(), (a > 0.05).mean() * 100, z[4]))

    # hero 主星：核心框（±40px，柔光半径量级）与含芒框（±90px，只算到半芒的一半）
    print("      --- hero 主星位置 ---")
    for i, hs in enumerate(HERO_STARS):
        for r in (40, 90):
            x0 = (hs["x"] * W - r) / W
            y0 = (hs["y"] * H - r) / H
            x1 = (hs["x"] * W + r) / W
            y1 = (hs["y"] * H + r) / H
            a = occ[max(0, int(y0 * H)):int(y1 * H), max(0, int(x0 * W)):int(x1 * W)]
            print("      hero#%d (%.0f,%.0f) ±%dpx   有内容像素 %5.2f%%"
                  % (i + 1, hs["x"] * W, hs["y"] * H, r, (a > 0.05).mean() * 100))

    print("\n判据：有内容像素 ≤5% 才适合放闪烁星（hero 核心框 <2% 更好）；>10% 就会闪到字上。")


if __name__ == "__main__":
    main()
