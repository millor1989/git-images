#!/usr/bin/env node
/**
 * seek_probe.mjs — 在浏览器内 seek GSAP 时间轴，验证某个 section 各元素的 opacity / 位置。
 *
 * 为什么需要它：index.html 是 paused 时间轴，**静态加载时所有元素 opacity 都是 0**。
 * 直接量 DOM 会把「动画没跑」误判成「元素不存在」，而渲染一次要十几分钟 —— 必须先用它验证。
 *
 * 用法（在工程根目录跑，index.html 在同级）：
 *   export NODE_OPTIONS=""
 *   export HYPERFRAMES_BROWSER_PATH="<chrome-headless-shell.exe 路径>"
 *   node seek_probe.mjs sec4 139.5 141 143 150 175
 *     第 1 个参数 = section id（sec1..sec5 / intro / outro）
 *     后续参数   = 要采样的时间点（秒）
 *
 * 依赖：ws 模块。默认从 hyperframes 的 npx 缓存里 require；
 *      若路径不同，用环境变量 WS_BASE 指定 node_modules 目录。
 *
 * 两类断言 + 退出码：
 *   2 = 某元素在所有采样点都 opacity 0（被多条 tween 争抢，见 SKILL.md 排坑）
 *   3 = 内容底边越过底部 .emoji 上沿（y≈1478），会被图标压住
 *
 * 版式预算：.emoji 固定在 bottom:320px、高 120px（上沿 y≈1478），
 * 而 .content 是 top:0/bottom:0 + padding-bottom:200px 的垂直居中盒
 * （居中区 0~1720，内容高 H 时底边 =(1720+H)/2）。
 * 因此 **内容总高 H 需 ≲ 1240px** 才不与图标交叠。估算：
 *   .grid2 一行 ≈109px；非 dense .topic ≈202px（2 行 chip）/ 146px（1 行）；
 *   dense .topic ≈164px / 117px；.rank-row ≈74px；.info-row ≈89px；.info-sub ≈51px。
 */

import { createRequire } from "node:module";
import { spawn } from "node:child_process";
import fs from "node:fs";
import http from "node:http";
import os from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";

// ws 模块所在目录（hyperframes 的 npx 缓存）——**不要写死**：npx 缓存 hash 会变。
// 解析顺序：环境变量 WS_BASE → ~/.workbuddy 与 ~/.npm 下的通配查找。
function findWsBase() {
  const roots = [
    path.join(os.homedir(), ".workbuddy", "tmp", "npm-cache", "_npx"),
    path.join(os.homedir(), ".npm", "_npx"),
  ];
  if (process.env.LOCALAPPDATA) {
    roots.push(path.join(process.env.LOCALAPPDATA, "npm-cache", "_npx"));
  }
  for (const root of roots) {
    let dirs = [];
    try { dirs = fs.readdirSync(root).sort(); } catch { continue; }
    for (const d of dirs) {
      const nm = path.join(root, d, "node_modules");
      if (fs.existsSync(path.join(nm, "ws"))) return nm;
    }
  }
  return null;
}

const WS_BASE = process.env.WS_BASE || findWsBase();
if (!WS_BASE) {
  console.error("未找到 ws 模块目录：请设 WS_BASE 指向含 ws 的 node_modules"
    + "（如 ~/.workbuddy/tmp/npm-cache/_npx/<hash>/node_modules）");
  process.exit(1);
}
const require = createRequire(pathToFileURL(path.join(WS_BASE, "anchor.js")).href);
const WebSocket = require("ws");

const CHROME = process.env.HYPERFRAMES_BROWSER_PATH;
if (!CHROME) { console.error("请设置 HYPERFRAMES_BROWSER_PATH"); process.exit(1); }

const SEC = process.argv[2] || "sec4";
const TIMES = (process.argv.slice(3).length ? process.argv.slice(3) : ["139.5", "141", "143", "150", "175"])
  .map(Number);

const CWD = process.cwd();
const URL_ = pathToFileURL(path.join(CWD, "index.html")).href;
const PORT = Number(process.env.PROBE_PORT || 9345);

const proc = spawn(CHROME, [
  `--remote-debugging-port=${PORT}`, "--headless=new", "--no-sandbox",
  "--disable-gpu", "--window-size=1080,1920", "about:blank",
], { stdio: "ignore" });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function getJson(p) {
  return new Promise((resolve, reject) => {
    http.get({ host: "127.0.0.1", port: PORT, path: p }, (res) => {
      let d = ""; res.on("data", (c) => (d += c));
      res.on("end", () => { try { resolve(JSON.parse(d)); } catch (e) { reject(e); } });
    }).on("error", reject);
  });
}

let targets;
for (let i = 0; i < 60; i++) {
  try { targets = await getJson("/json/list"); if (targets?.length) break; } catch {}
  await sleep(500);
}
if (!targets?.length) { console.error("chrome 未就绪"); process.exit(1); }

const socket = new WebSocket(targets.find((t) => t.type === "page").webSocketDebuggerUrl);
let id = 0; const pending = new Map();
socket.on("message", (raw) => {
  const m = JSON.parse(raw);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
});
const send = (method, params = {}) => new Promise((res) => {
  const i = ++id; pending.set(i, res);
  socket.send(JSON.stringify({ id: i, method, params }));
});

await new Promise((r) => socket.on("open", r));
await send("Page.enable");
// 关键：不注入这个，index.html 里 `window.__timelines["main"] = tl` 会抛错中断整个脚本
await send("Page.addScriptToEvaluateOnNewDocument", { source: "window.__timelines = {};" });
await send("Page.navigate", { url: URL_ });
await sleep(5000);

function expr(t) {
  return `(() => {
    const tl = (window.__timelines && window.__timelines["main"]) || window.__tl;
    if (!tl) return JSON.stringify({ err: "NO_TIMELINE", nodes: [] });
    tl.pause(); tl.time(${t});
    const sec = document.getElementById("${SEC}");
    if (!sec) return JSON.stringify({ err: "NO_SECTION", nodes: [] });
    const cont = sec.querySelector(".content");
    // 底部 .emoji 是内容安全区的下边界：内容底边超过它就会被图标压住
    const em = sec.querySelector(".emoji");
    const emojiTop = em ? Math.round(em.getBoundingClientRect().top) : null;
    const nodes = [];
    const walk = (el, depth) => {
      for (const ch of el.children) {
        // .grid2 是纯布局包裹层，展开它才能量到里面的 .idx-card（限深防意外递归）
        if (ch.classList.contains("grid2") && depth < 3) { walk(ch, depth + 1); continue; }
        const st = getComputedStyle(ch);
        const r = ch.getBoundingClientRect();
        nodes.push({
          cls: ch.className.split(" ")[0] || ch.tagName.toLowerCase(),
          op: +(+st.opacity).toFixed(2),
          top: Math.round(r.top),
          h: Math.round(r.height),
        });
      }
    };
    walk(cont, 1);
    return JSON.stringify({
      vh: innerHeight,
      emojiTop,
      contentBox: [Math.round(cont.getBoundingClientRect().top),
                   Math.round(cont.getBoundingClientRect().bottom)],
      nodes,
    });
  })()`;
}

const rows = [];
let emojiTop = null, overflowTop = -1, overflowCls = "";
for (const t of TIMES) {
  const r = await send("Runtime.evaluate", { expression: expr(t), returnByValue: true });
  const v = r.result?.result?.value;
  if (!v) { console.log(`t=${t}  EVAL_ERR`); continue; }
  const parsed = JSON.parse(v);
  if (parsed.err) { console.log(`t=${t}  ${parsed.err}`); continue; }
  const list = parsed.nodes;
  emojiTop = parsed.emojiTop;
  console.log(`t=${t}`);
  for (const k of list) {
    const flag = k.op === 0 && k.top > 0 ? "  <== 不可见!" : "";
    console.log(`   ${k.cls.padEnd(10)} opacity=${k.op}  top=${k.top}  h=${k.h}${flag}`);
    if (emojiTop !== null && k.top + k.h > emojiTop && k.top + k.h > overflowTop) {
      overflowTop = k.top + k.h;
      overflowCls = `${k.cls} (底边 ${k.top + k.h} vs 图标上沿 ${emojiTop})`;
    }
  }
  rows.push(list);
}

// 汇总 1：内容底边是否越过底部 emoji（会被图标压住 / 显得拥挤）
if (emojiTop !== null) {
  console.log(`\n== 内容安全区 ==\n  .emoji 上沿 y=${emojiTop}（内容底边应小于它）`);
  if (overflowTop > 0) {
    console.log(`  !! 内容越界：${overflowCls}`);
    process.exitCode = 3;
  } else {
    console.log(`  OK 内容底边最高 ${Math.max(...rows.flat().map((x) => x.top + x.h))} < ${emojiTop}`);
  }
}

// 汇总：若某类元素在所有采样点都 opacity 0，判定为渲染缺失
if (rows.length) {
  const first = rows[0].map((x) => x.cls);
  const dead = first.filter((cls, i) =>
    cls !== "NO_TIMELINE" && rows.every((r2) => r2[i] && r2[i].op === 0));
  if (dead.length) {
    console.log(`\n!! 以下元素在所有采样点都不可见，疑似被多条 tween 争抢 opacity：${dead.join(", ")}`);
    console.log("   检查它们是否为 .content 的直接子元素（需包一层 .grid2）");
    process.exitCode = 2;
  } else if (!process.exitCode) {
    console.log("\nOK 所有采样点元素均可见，且无内容越界");
  }
}

socket.close(); proc.kill(); process.exit(process.exitCode || 0);
