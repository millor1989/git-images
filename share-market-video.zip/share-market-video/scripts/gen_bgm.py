# -*- coding: utf-8 -*-
"""Generate a calm broadcast-style BGM for the stock video (numpy synthesis).

Adapted from gen_bgm_calm.py (BPM=75, Am-F-C-G loop). Output written to this
project's assets/ so the composition can reference it locally.
"""
import numpy as np
import wave
import os
import sys

SR = 44100
BPM = 75
BEAT = 60.0 / BPM          # 0.8s
BAR = BEAT * 4             # 3.2s
TOTAL = float(sys.argv[1]) if len(sys.argv) > 1 else 107.0
N = int(TOTAL * SR)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "assets", "bgm-v1.wav")
OUT = os.path.abspath(OUT)

CHORDS = [
    [220.00, 261.63, 329.63],  # Am : A3 C4 E4
    [174.61, 220.00, 261.63],  # F  : F3 A3 C4
    [261.63, 329.63, 392.00],  # C  : C4 E4 G4
    [196.00, 246.94, 293.66],  # G  : G3 B3 D4
]
ROOTS = [110.00, 87.31, 130.81, 98.00]   # A2 F2 C3 G2
ARP = [
    [440.00, 523.25, 659.25, 523.25],    # A4 C5 E5 C5
    [349.23, 440.00, 523.25, 440.00],    # F4 A4 C5 A4
    [523.25, 659.25, 783.99, 659.25],    # C5 E5 G5 E5
    [392.00, 493.88, 587.33, 493.88],    # G4 B4 D5 B4
]

mix = np.zeros(N, dtype=np.float64)


def add(sig, start, gain=1.0):
    s = int(start * SR)
    n = len(sig)
    if s < 0:
        sig = sig[-s:]
        s = 0
        n = len(sig)
    if s + n > N:
        n = N - s
    if n <= 0:
        return
    mix[s:s + n] += sig[:n] * gain


# 1) kick: beats 1 & 3, soft attack, longer decay
for bar in range(int(TOTAL // BAR)):
    for beat in (0, 2):
        t0 = bar * BAR + beat * BEAT
        n = int(0.22 * SR)
        t = np.arange(n) / SR
        f = 100 * np.exp(-t / 0.05) + 42
        ph = 2 * np.pi * np.cumsum(f) / SR
        kick = np.sin(ph) * np.exp(-t / 0.14)
        click = (np.random.rand(n) * 2 - 1) * np.exp(-t / 0.005) * 0.12
        add(kick + click, t0, 0.85)

# 2) hi-hat: eighth notes, very light
hat_n = int(0.045 * SR)
for step in range(int(TOTAL // (BEAT / 2))):
    t0 = step * (BEAT / 2)
    t = np.arange(hat_n) / SR
    noise = np.random.rand(hat_n) * 2 - 1
    hp = np.zeros(hat_n)
    prev = 0.0
    for i in range(hat_n):
        prev = noise[i] - prev * 0.82
        hp[i] = prev
    hat_sig = hp * np.exp(-t / 0.025)
    add(hat_sig, t0, 0.13)

# 3) bass: whole-bar long note, soft triangle-ish
for bar in range(int(TOTAL // BAR)):
    chord_i = bar % 4
    root = ROOTS[chord_i]
    t0 = bar * BAR
    n = int(BAR * 0.96 * SR)
    t = np.arange(n) / SR
    osc = (np.sin(2 * np.pi * root * t) * 0.85
           + np.sin(2 * np.pi * root * 2 * t) * 0.15)
    bass = osc * np.exp(-t / 1.2)
    add(bass, t0, 0.42)

# 4) arp: eighth notes, triangle + harmonics
arp_step = BEAT / 2
steps = int(BAR // arp_step)
for bar in range(int(TOTAL // BAR)):
    chord_i = bar % 4
    seq = ARP[chord_i]
    for i in range(steps):
        t0 = bar * BAR + i * arp_step
        note = seq[i % len(seq)]
        n = int(arp_step * 0.95 * SR)
        t = np.arange(n) / SR
        tri = (2 / np.pi) * np.arcsin(np.sin(2 * np.pi * note * t))
        pluck = tri * np.exp(-t / 0.18) * 0.42
        pluck += np.sin(2 * np.pi * note * 3 * t) * np.exp(-t / 0.14) * 0.16
        pluck += np.sin(2 * np.pi * note * 5 * t) * np.exp(-t / 0.10) * 0.07
        add(pluck, t0, 0.5)

# 5) pad: chord long notes
for bar in range(int(TOTAL // BAR)):
    chord_i = bar % 4
    t0 = bar * BAR
    n = int(BAR * SR)
    t = np.arange(n) / SR
    pad = np.zeros(n)
    for fr in CHORDS[chord_i]:
        pad += np.sin(2 * np.pi * fr * t) * 0.15 + np.sin(2 * np.pi * fr * 2 * t) * 0.05
    add(pad * 0.4, t0, 0.30)

# normalize + fade in/out
peak = np.max(np.abs(mix)) + 1e-9
mix = mix / peak * 0.85
fade_in = int(0.6 * SR)
fade_out = int(1.2 * SR)
mix[:fade_in] *= np.linspace(0, 1, fade_in)
mix[-fade_out:] *= np.linspace(1, 0, fade_out)


def write_wav(path, data, sr=SR):
    data = np.clip(data, -1, 1)
    pcm = (data * 32767).astype(np.int16)
    with wave.open(path, "w") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


os.makedirs(os.path.dirname(OUT), exist_ok=True)
write_wav(OUT, mix)
print(f"bgm-v1.wav -> {OUT} ({TOTAL}s, peak={peak:.3f})")
