# share-market-video

用 [hyperframes](https://hyperframes.heygen.com) 生成「股市行情汇总」竖版短视频（1080×1920，中文旁白 + 背景音乐）的 WorkBuddy / Claude Skill。

两种市场模式：

| 模式 | 片头标题 | 内容板块 | 时长参考 |
|---|---|---|---|
| `a-share` | 今日股市行情 | **大盘 / 概述 / A股综述 / 港股综述 / 日韩综述**（5 段；概述找不到跨市场共性时整段省略 = 4 段） | 约 110~190s |
| `us` | 隔夜美股行情 | 美股大盘 / 当日主线 / 龙头与中概 / 承压与分化（**固定 4 段**） | 约 140~165s |

画面风格：深色背景 + 白字 + 青色 `#00D4FF` 高亮 + **涨红跌绿**（中国习惯）+ **卡片式分页**（一屏拆 2~3 屏，段标题常驻，无底部图标/进度点）。
流程是**音频驱动**的：先用 edge-tts 生成中文播报，语音时长反过来决定每个画面片段的长度。

---

## 安装（3 步）

### 1. 放对目录

把整个 `share-market-video` 文件夹解压到你的用户级技能目录：

| 平台 | 路径 |
|---|---|
| Windows | `C:\Users\<你>\.workbuddy\skills\share-market-video\` |
| macOS / Linux | `~/.workbuddy/skills/share-market-video/` |

（项目级安装则放到项目根目录下的 `.workbuddy/skills/`。）
放好后目录结构应为：

```
share-market-video/
  SKILL.md
  README.md
  assets/templates/a-share/   # A股模板工程：build_cards.py（★版式载体）+ _base-head.html + index.html
  assets/templates/us/        # 美股模板工程（同上）
  assets/bg/taurus.png        # 星空背景底板（金色星座牛，3 MB —— 必须是 PNG，原因见 SKILL.md 第 5D 步）
  references/template.md      # 版式说明 + 排坑记录
  scripts/init_project.py     # 从模板建工程（同时生成工程的 build.sh）
  scripts/sync_template_from_project.py  # 从最新工程回灌模板（版式改完跑一次）
  scripts/preflight.py        # 环境自检
  scripts/gen_narration.py    # 语音生成（模板，会被复制进工程）
  scripts/gen_bgm.py          # BGM 生成（模板，会被复制进工程）
  scripts/resume_narration.py # 断点续跑 TTS
  scripts/apply_bg_layer.py   # 给 index.html 追加星空装饰背景层（工程里由 build.sh 自动连跑）
  scripts/bg_zones_heat.py    # 从上一期成片量「内容占空热力图」，复测背景层的空区
  scripts/check_ssot.py       # ★ 单一事实源闸门：md 片头 ↔ build_cards 片头 ↔ countUp（渲染前必跑）
```

### 2. 装依赖

需要 Python 3.9+ 与 Node.js 18+（推荐 22），以及 ffmpeg/ffprobe。

```bash
pip install edge-tts numpy pillow
```

- **Node.js**：https://nodejs.org
- **ffmpeg**：Windows 可从 https://www.gyan.dev/ffmpeg/builds/ 下载后把 `bin` 加入 PATH；macOS `brew install ffmpeg`；Linux `apt install ffmpeg`
- hyperframes CLI 与 chrome-headless-shell **不用手动装**，首次渲染时 `npx` 会自动拉取

### 3. 跑一次自检

```bash
python <skill目录>/scripts/preflight.py
```

看到「全部必需依赖就绪」就完成了。缺什么它会直接告诉你怎么补。

---

## 快速开始

在 WorkBuddy / Claude 里直接用自然语言触发即可，例如：

> 做一条 2026 年 8 月 31 日的 A 股行情视频
> 做 2026 年 8 月 31 日的美股行情视频

Skill 会先问你两件事：**市场模式**（A股 / 美股）和**交易日**。数据一律由 AI 联网检索——**不接受手工提供的行情数字**，你贴来的数字只会被当成线索去复核。

检索结果会先写成 `<工程>/data/market-<日期>.md` 交给你过目——**想删减或补充就在这一步说**（也可以直接改文件），确认之后才继续做语音和渲染。

想手动跑，流程是：

```bash
# 1. 建工程
python <skill目录>/scripts/init_project.py --mode a-share --out ./market-20260831

# 2. 编辑文案：./market-20260831/audio/gen_narration.py 里的 SEGMENTS
#    （数字要写成中文口语："三千九百八十六点三零"，别写 "3,986.30"）

# 3. 生成语音 + BGM
python ./market-20260831/audio/gen_narration.py          # 产出 assets/narration-v1.mp3 + audio/segments.json
python ./market-20260831/audio/gen_bgm.py 120            # 参数是视频总秒数

# 4. 改 ./market-20260831/build_cards.py 的 SECTIONS / SEC*_PAGES，然后**只跑这一条**出片：
#    bash build.sh ← init_project.py 已生成，= build_cards.py + 追加星空背景层
#    （index.html 是生成物，别手改；涨用 class="up" 红 / 跌用 class="down" 绿）
#    ⚠ 星空是**默认背景**。若某期要纯色底，改用 python build_cards.py（不要跑 build.sh）。
cd ./market-20260831 && bash build.sh

# 5. 校验 + 渲染
cd ./market-20260831
export NODE_OPTIONS=""
npx --yes hyperframes@0.8.17 check
npx --yes hyperframes@0.8.17 render --quality high --output out-0831.mp4
```

> ⚠ **星空背景的代价**：成片体积 ×3.5、渲染时长 ×1.8（约 52 MB / 17 min）。这是默认开启的取舍，若要省时间/体积可改跑纯色底。

---

## 数据可靠性

数据一律联网检索，SKILL.md 里内置了强制校验规则：

- 每个指数做 `昨收 ± 涨跌点 = 今收` 链式算术验算
- 关键数字至少两个独立来源一致
- 检查文章年份，避免"同月不同年"的旧文污染
- 校验不通过就不出片

除此之外还有一道**人工闸门**：抓到的数据先落盘成 `data/market-<日期>.md`（含来源清单和校验算式），你确认（或删改）后才进文案。数字错了不用重渲整条视频。

---

## 常见问题

**渲染时报删除/权限错误** → 先 `export NODE_OPTIONS=""` 再跑 hyperframes。

**浏览器启动失败（0xC000013B）** → 跑 `preflight.py`，用它挑出的那个 chrome-headless-shell（脚本会实测 `--version`，不限定版本），用 `HYPERFRAMES_BROWSER_PATH` 指过去。

**渲染报 EPERM / 输出已存在** → hyperframes 用 rename 而非覆盖，换个输出文件名或先删旧文件。

**旁白把数字念错** → 文案里数字必须写成中文口语形式。

**成片太长 / 听着啰嗦** → 旁白把明细念全了。硬规则：每个 topic / 板块最多播报 3 条明细，或汇总成最多 3 句话；10 条个股只念 3 条，成交额前十只念前 3 名。画面照常展示完整明细，只有旁白受限。

**A股 sec1 开场的指数念太久** → 画面放 6 张指数卡（上证 / 深证成指 / 创业板指 / 科创50 / 沪深300 / 北证50），旁白**只念 3 个**：上证指数、创业板指、沪深300。深证成指、科创50、北证50 与上证高度同向，只上画面、不进旁白；要体现大小盘分化就用一句话概括。

**没声音** → `<audio>` 标签必须带 `id`；两个音频要用不同的 `data-track-index`。

**星空背景是默认的** → 工程建好后，出片用 **`bash build.sh`**（= `build_cards.py` + `apply_bg_layer.py` 连跑，见「快速开始」第 4 步）。
它是一层装饰（金色星座牛 + 星云 + 闪烁星 + 金黄主星），代价是成片体积 ×3.5、渲染时长 ×1.8。
⚠ **别只跑 `build_cards.py`**，它会整个重写 `index.html`，把背景冲掉 —— 这就是 `build.sh` 存在的理由。
⚠ 某期想要纯色底，就改跑 `python build_cards.py`（不跑 `build.sh`）。
⚠ 背景里闪烁的星只落在「上一期成片里没有内容」的区域，那是用量化热力图挑的；**改了卡片版式就要重跑
`scripts/bg_zones_heat.py` 复测**，否则星会闪到字上。

更多细节见 `references/template.md`。

---

## 授权

内部模板，随技能一起分发，可自由修改。行情数据请自行确保来源可靠。
