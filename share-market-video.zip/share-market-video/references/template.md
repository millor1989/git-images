# hyperframes 股市行情模板 · 版式与排坑参考

本文件是 share-market-video 的详细参考，供需要深入排查或调整版式时加载。SKILL.md 已覆盖主流程，此处补细节。

## 模板源码

- A股模式：`<SKILL>/assets/templates/a-share/index.html`
- 美股模式：`<SKILL>/assets/templates/us/index.html`
- 由 `scripts/init_project.py --mode a-share|us --out <PROJ>` 复制到工程目录，复制后只改内容与时间，不改版式。
- 分辨率：1080×1920（竖屏），30fps
- 结构：`#root[data-composition-id="main"][data-duration]` 内 7 个 `<section class="clip" data-start data-duration data-track-index>`（intro / sec1~sec5 / outro）+ 底部进度点 + 两段 `<audio>`。

## 数据落盘与人工确认闸门

- 联网抓取的数据先写到 `<PROJ>/data/market-<YYYYMMDD>.md`，骨架见 `<SKILL>/assets/market-data-template.md`（元信息 + 校验记录 + 片段结构 + 来源清单四块）。
- 落盘后用文件展示工具给用户看，等其「确认 / 删减 / 补充」，**停在这里不要往下做语音**。用户可能直接改文件，继续前重新读取磁盘版本；口述的改动也要同步写回 md。
- 确认后 md 即唯一事实源：文案、画面数值、板块数、进度点数全部从 md 取，不再凭检索记忆补数。
- 用户删减/补充导致板块数变化 → 按 SKILL.md 的「动态片段模式」处理（进度点数 = 片段数 N，旁白段数 = N + 2）。

## 版式约定（用户已确认的审美）

- 深色背景 `#0A0E14`，正文白字，关键词青色 `#00D4FF` 高亮。
- 涨红跌绿（中国股市惯例）：`.up { color: #ff4d4f }` 涨红，`.down { color: #00c48c }` 跌绿。
- 每个板块：标题（左对齐，下带青色分隔线 `.sec-line`）→ 内容区（竖向居中）→ 底部图标（`.emoji` 内联 SVG，青色描边细线条）→ 底部进度点（`.timeline`，一串白色圆点，每板块一个，flex 居中，`gap: 38px`；播放到某板块时该点变蓝 `#00D4FF` 并缩放脉冲）。
  - **注（2026-09-16）**：走**卡片式分页版式**时，用户要求**删掉底部图标**，且进度点**暂时不要**（见下方「卡片式分页版式」一节）。单屏原版仍保留这两者。
- 片头 intro：**已由 SKILL.md 第 5C 步「内容概要版」取代**（2026-09-17）—— 三行 = 小字「日期 + 市场」（**纯白 `#ffffff`**）→ 装饰线 → 中号主线 + 超大数字 → 小字概述；入场分**核心 → 支撑 → 日期**三层。此处旧描述（日期青色小字 + 「今日股市行情」大字）保留仅供理解上游工程结构，**不要再照它实现**。
- 片尾 outro：「投资有风险」青色小字 + 分隔线 + 「视频内容不构成投资建议」白色大字，七段式入场 + 持续呼吸收尾（详见下节），固定 CTA。
- 动画：GSAP timeline（`window.__timelines["main"]`），标题 `back.out(1.7)` 左滑入，内容 `power3.out` stagger 淡入，图标 `elastic.out` 弹入，进度点 `back.out(2)` 点亮（白点变蓝，无填充线）。
- 话题要点（`.topic`）新版排版：板块名小标（独立行，左 4px 青色竖条 + 30px 字号 + 8% 青色底）+ 内容 chip（2 列 grid，名称左对齐 + 数值右对齐 + tabular-nums 等宽数字）。原版「`flex` 单行塞所有股票 + 空格分隔」会让长名字（"埃克森美孚/雪佛龙/康菲"）撞图标、数字宽度不齐、跨行错位——新版通过 chip 2 列对齐 + tabular-nums 等宽 + ellipsis 截断解决。

## topics 排版的自适应密度（数据量决定）

| 密度 | 触发条件 | 字号 | chip 列数 | 单 topic 高度 |
|---|---|---|---|---|
| **L1 标准** | sec 内 ≤6 topic 且每 topic ≤5 chip | 30px label / 28px chip / 28px snum | 2 列 | ~150px |
| **L2 紧凑** | sec 内 6~10 topic 或某 topic 6~8 chip（agent 给 `.content` 加 `dense` 类触发） | 28px / 26px / 26px | 2 列 | ~110px |
| **L3 分页** | sec 内 >10 topic（agent 拆分为多个 `<section class="clip">`，每个 2~3 topic，配合音频段切分） | 由拆分后内容决定 | 2 列 | ~150px |

切换 CSS：`/assets/templates/{a-share,us}/index.html` 内 `.content.dense .topic {...}`。1080×1920 内容区可用约 1620px：L1 可放 5~8 topic，L2 可放 10~12 topic，L3 无上限。

GSAP 选择器（同步修改）：新版 `.topic` 由 `secAnim` 的 `.content > *` 统一动画入场。不要额外写 `tl.from("#secN .topic b", ...)` 或 `tl.from("#secN .topic", ...)`，因为这会和 `.content > *` 上的 `from(autoAlpha:0)` 冲突，导致除第一个 topic 外全部保持隐藏。需要放慢 topic 入场节奏时，给 `secAnim` 加第 4 个参数：`secAnim("s2", 29.40, "#sec2 .content > *", 0.15)`。`secAnim` 签名：`function secAnim(id, tStart, contentSel, stagger)`，默认 stagger=0.08。

HTML 结构（新版每个 `.topic`）：

```html
<div class="topic">
  <div class="name">板块名</div>
  <div class="stocks">
    <span class="chip"><span class="sname">个股名</span><span class="snum up">+7%</span></span>
    <span class="chip"><span class="sname">个股名</span><span class="snum down">−5%</span></span>
    <span class="chip"><span class="sname">说明</span><span class="snum hl">高亮词</span></span>
  </div>
</div>
```

颜色：`.snum` 直接复用 `.up` / `.down` / `.hl` 三类（涨红 / 跌绿 / 青色高亮）。不再用 `<b>`，避免和 inline 流混在一起。

## 片尾 CTA 动效（outro，固定版式）

outro 是最后一个 clip，时长由 outro 旁白决定（典型 4.38s）。动效分 7 拍，全部锚在 `const OT = <outro data-start>` 上——**改 outro 时长只需改 OT 一个值**，不用逐个改时间。

元素（3 个原有 + 2 个新增）：

```html
<div class="content">
  <div id="cta-halo"  class="cta-halo"></div>          <!-- 新增：背后青色径向光晕 -->
  <h2 id="cta-title"  class="cta-title">投资有风险</h2>
  <div id="cta-line"  class="cta-line">
    <i id="cta-sheen" class="cta-sheen"></i>            <!-- 新增：线上扫光条 -->
  </div>
  <p  id="cta-sub"    class="cta-sub">视频内容不构成投资建议</p>
</div>
```

时间线（相对 OT 的偏移，总长 4.20s，末尾留 ~0.2s 静止收尾）：

| 拍 | 偏移 | 目标 | 动作 |
|---|---|---|---|
| ① | +0.02 | `#cta-halo` | `scale 0.35→1`、`autoAlpha 0→1`，0.85s `power2.out` |
| ② | +0.08 | `#cta-title` | `from y:46, scale:0.68, autoAlpha:0`，0.55s `back.out(2.6)` |
| ③ | +0.42 | `#cta-line` | `scaleX 0→1`，0.55s `power3.inOut` |
| ④ | +0.62 | `#cta-sheen` | `xPercent -120→260`，0.8s `power2.inOut`（被 `overflow:hidden` 裁出视野，不需要淡入淡出） |
| ⑤ | +0.70 | `#cta-sub` | `from y:26, scale:0.55, autoAlpha:0`，0.6s `back.out(2.4)` |
| ⑥ | +1.30 | `#cta-sub` | `textShadow 0 → 0 0 34px rgba(0,212,255,0.9)`，0.22s `sine.out` yoyo×1（落定强闪） |
| ⑦ | +1.75 | sub / title / halo | 呼吸 `duration 0.43, yoyo, repeat 5`（3 个来回，2.58s）：sub `scale 1.055 + 26px 辉光`、title `scale 1.07 + 22px 辉光`、halo `scale 1.14 / autoAlpha 0.62` |

关键约束：

- **绝不要给 `.cta-sub` 加 `letterSpacing` 动画**。字距属于文本重排属性，逐帧捕获引擎下 glyph 位置会 snap 到整数像素，慢动作/缓动尾巴会明显抖动——hyperframes lint 直接报 `gsap_non_transform_motion` error。想要"字距收拢"的效果只能拆成逐字符元素各自动 `x`，成本不划算，用 `scale` 就够。**通用规则：本模板所有 GSAP 动画只动 transform / opacity / textShadow / boxShadow / backgroundColor，不要动任何会引起重排的属性（letterSpacing、width、top、fontSize）。**
- **`.cta-title` / `.cta-sub` 要写初始 `text-shadow: 0 0 0px rgba(0,212,255,0)`**。GSAP 对 `text-shadow` 做复杂值插值，两端格式必须一致（offset-x / offset-y / blur / color 四段齐全），否则从 `none` 起补间会失败。
- **各拍之间不要重叠**，尤其 ⑥ 的 `textShadow` 和 ⑦ 的 `textShadow` 是同一属性——lint 会报 `overlapping_gsap_tweens`。⑥ 结束在 `+1.74`，⑦ 从 `+1.75` 起。呼吸总长 `1.75 + 0.43×6 = 4.33 < 4.38`；outro 被拉长/缩短时按 `呼吸起点 + duration×(repeat+1) ≤ outro时长 − 0.15` 重算。
- **不要给 `.cta-sub`/`.cta-title` 额外写 `.content > *` 级别的入场动画**（outro 不走 `secAnim`），否则会和上面的 `from` 抢 `autoAlpha`。

旧版（已废弃）只有 4 条：`title y:26` 淡入、`sub scale 0.75` 弹入、line 展开、最后 `scale:1.02 / autoAlpha:0.92` 0.16s yoyo×1——幅度 2% 且只呼吸一次，实际几乎看不出来。

## 环境清单（跨平台，全部自动探测）

路径不写死在文档里——运行 `python <SKILL>/scripts/preflight.py --json env.json` 会解析出本机实际路径。探测顺序：

| 组件 | 探测方式 |
|---|---|
| Python | 当前解释器 `sys.executable` |
| edge-tts / numpy / Pillow | `import` 探测；缺失则 `pip install edge-tts numpy pillow`（Pillow 供 `qa_pre` / `qa_post` 抽帧比对） |
| Node.js | `$NODE_BIN` → PATH → `~/.workbuddy/binaries/node/versions/*/node` → `/usr/local/bin` |
| ffmpeg / ffprobe | `$FFMPEG` / `$FFPROBE` → PATH → `~/.workbuddy/binaries/ffmpeg/**/bin` |
| hyperframes CLI | npm 缓存各候选目录下的 `_npx/*/node_modules/hyperframes/bin/hyperframes.mjs` + `npm config get cache`；未缓存则用 `npx --yes hyperframes@0.8.17` |
| chrome-headless-shell | `~/.cache/hyperframes/chrome/chrome-headless-shell/*`（Windows 另查 `%LOCALAPPDATA%`）→ 候选逐个 `--version` 冒烟测试，**取第一个真能启动的**（无版本偏好）；全失败则交给 hyperframes 自行下载 |
| TTS 音色 | `zh-CN-XiaoxiaoNeural`，rate `+8%`（可用 `TTS_VOICE` / `TTS_RATE` 覆盖） |

⚠ 各脚本里的**内置回退**（`qa_pre._FALLBACK` / `qa_post._FALLBACK` / `export_cover._fallback_ffmpeg()` /
`probe_intro_len._resolve_ffprobe()`）同样**不含用户名与版本 hash** —— 一律按运行时 home
（`~/.workbuddy`，可用 `WORKBUDDY_HOME` 覆盖）+ glob 通配求值，所以换机器/换版本无需改代码。
三个浏览器探针（`seek_pages` / `seek_probe` / `wrap_probe`）在未设 `WS_BASE` 时会自己去
`~/.workbuddy/tmp/npm-cache/_npx/*/node_modules`（以及 `~/.npm/_npx`、`%LOCALAPPDATA%`）里找含 `ws` 的那份。

## 排坑记录（全部已验证）

1. **删除钩子拦截**：某些宿主环境（如 WorkBuddy）会往 `NODE_OPTIONS` 注入 `--require=...safe-delete...` 之类的钩子，导致 hyperframes 清理 `~/.cache/hyperframes` 下的浏览器安装锁文件时抛错，check/render 失败。解法：所有 hyperframes 命令前 `export NODE_OPTIONS=""`。
2. **浏览器版本**：Windows 上曾观察到 bundled chrome-headless-shell 152 启动报 `Code 3221225595`（0xC000013B），当时换 131 版解决。
   ⚠ **那不是版本定律**（2026-09-29 修正）：本机现在只有 152 版，9/28、9/29 两场渲染均正常。
   所以 `preflight.py` 已改成**对候选逐个 `--version` 冒烟测试、取第一个能启动的**，不锁版本；真撞上 0xC000013B 再手动换版本即可。
3. **CLI 弹黑窗**：hyperframes `dist/cli.js` 有 3 处 spawn 未设 `windowsHide`（ffmpeg 探测、命令执行器），无控制台父进程下触发即弹窗。已修补该缓存包（`dist/cli.js.bak` 是备份），重新 npx 下载会丢失修补，需重打补丁。
4. **渲染不覆盖输出**：hyperframes 用 rename 而非 overwrite，同名 out.mp4 存在时报 `EPERM`。解法：换文件名或先删旧文件。
5. **GSAP 数组选择器 bug**：`tl.from([".topic",".info-row"], {stagger})` 多选择器数组不稳定（只生效第一个，报 "GSAP target not found"），改用单字符串 `.content > *`。
6. **标题 id 不匹配**：标题元素 id 是 `sec1-title`（非 `s1-title`），分隔线 id 是 `s1-line`。JS 里 `secAnim` 用 `"#sec" + id.slice(1) + "-title"` 匹配标题。
7. **字体声明**：`@font-face { font-family: "Microsoft YaHei"; src: local(...) }` 等系统字体必须声明，否则 lint 报 `font_family_without_font_face`。
8. **check 偶发 0 samples**：音频首次转码时序问题，重跑 check 即恢复。
9. **音频挂载**：`<audio>` 必须带 `id`（否则静音，lint 报 `media_missing_id`）；多音频不同 `data-track-index` 避免同轨重叠 warning；BGM 用 `data-volume="0.16"` 压低。
10. **不要截断 check 输出，必须读全文**：`check` 的第一段是 **Lint**，error/warning 就在那里；后面 Runtime / Layout / Motion / Contrast 四段才是 0 errors。曾经用 `| tail -15` 只看后半段，漏掉了 Lint 的 1 个 error（outro 的 `letterSpacing` 逐帧抖动），把带缺陷的版本当成合格交付。正确做法：输出重定向到文件（`> check.log 2>&1`），再用文件读取工具读全文。**`| head -N` 和 `| tail -N` 都不要用**——不只是漏内容：`tail` 必须等 stdin 关闭才吐字，子进程若不干净退出它会一直挂住，把前台命令拖到 120s 默认超时后转后台，之后只能长轮询，这段时间在界面上完全不可见。
11. **禁止动画任何会引起重排的 CSS 属性**：hyperframes lint 会报 `gsap_non_transform_motion` error（判为 error 不是 warning）。典型是 `letterSpacing`（逐帧捕获下 glyph snap 到整数像素 → 缓动尾巴抖动），同类还有 `width` / `top` / `fontSize`。**只允许动 transform（x/y/scale/scaleX/rotation）、opacity/autoAlpha、textShadow、boxShadow、backgroundColor。** 想要"字距展开"效果必须把文本拆成逐字符元素各自动 `x`。
12. **同一元素同一属性的两个 tween 不能时间重叠**：lint 报 `overlapping_gsap_tweens` warning。例如片尾"落定闪光"的 `textShadow` 与紧随其后"呼吸"的 `textShadow` 必须首尾相接（前者结束 ≤ 后者开始），不能交叉。
13. **`check --timeout` 默认只有 3000ms，必须显式给 120000**：`--timeout` 是"等待渲染就绪"的超时（"also sets the navigation minimum, 10s floor"）。一次完整 check 实测约 **53 秒**，给 30000 仍会报 `Timed out after 30000 ms while waiting for the WS endpoint`。失败一次要连带十几分钟的重试空档，是全流程最大的非必要耗时。另注意 **`render` 没有 `--timeout`**（传了报 `Unknown flag: --timeout`），它对应 `--browser-timeout`，单位是**秒**，与 check 的毫秒不是一回事。
14. **长命令一律后台运行**：`check`（约 53s）、`render`（5~8 分钟）都设后台运行，输出落盘。`render` 后台跑的同时并行编写 QA 脚本——渲染窗口是零成本时间，不要空等。

## 生成脚本说明

- `<PROJ>/audio/gen_narration.py`（由 init_project 从 `<SKILL>/scripts/` 复制）：编辑 `SEGMENTS`（a-share 7 段 / **us 6 段 = `intro` + sec1~sec4 + `outro`**，每项 `(name, text)`），运行后产出分段时间表 `audio/segments.json`（`start`/`duration`/`total`）+ 合成 `assets/narration-v1.mp3`。GAP=0.3s 段间静音。ffmpeg/ffprobe 自动探测（`$FFMPEG`/`$FFPROBE` 或 PATH）。
- `<PROJ>/audio/gen_bgm.py`：numpy 合成 75BPM 舒缓 BGM（Am-F-C-G 循环），参数为总秒数，输出 `assets/bgm-v1.wav`。

## 数据校验清单（发布前逐项打勾）

- [ ] 每个 A股指数：昨收 ± 涨跌点 = 今收（链式算术）。
- [ ] 港股/韩日指数：官方交易所快照 + 带日期新闻双重确认。
- [ ] TOP10 成交额：至少两个独立来源金额一致。
- [ ] 输出文件名含日期（如 `out-0831.mp4`）。

## 美股模式版式差异

美股模式与 A股模式共用同一模板，仅在以下点改动（其余完全一致）：

1. 片头 **按 SKILL.md 第 5C 步「内容概要版」实现**（三行 = 日期+市场 / 主线+数字 / 一句话概述；日期**纯白**、其动效**排在核心内容之后**）。旧版 `<h1 id="intro-title">`「隔夜美股行情」写法**已废弃**，别再照做；日期用美股交易日期（如「2026年8月28日 · 周五」）。
2. 内容板块：**固定 4 段**（`intro` / sec1~sec4 / `outro`），**不要把美股压成 2 段**。复用 A股模板的 sec1~sec4 槽位、**删掉 sec5**：

   | 段 | 美股内容（见 SKILL.md「us 模式 4 个板块」） |
   |---|---|
   | sec1 | 美股大盘：道指 / 标普500 / 纳指 / 费半 4 张指数卡 + 当日驱动因素（旁白 4 个都念） |
   | sec2 | 当日主线：最强题材 + 代表个股 + 催化逻辑 |
   | sec3 | 龙头与中概：七巨头（指数 + 7 只个股）/ 纳斯达克中国金龙指数 + 中概代表 |
   | sec4 | 承压的一面：领跌板块/个股 + 避险资产走强 |

   > **2026-09-18 定**：早期版本把美股压成 2 段（大盘 + 热门），单段旁白会涨到 40s+、画面 5~6 屏，节奏明显拖沓。9/16、9/17 两期实测 **4 段**信息量与观感都更好，**一律 4 段**（除非用户明确要求精简）。
3. 时间线：进度点 = **4 个**（`tl-n1`~`tl-n4`，对应 sec1~sec4 四个板块）。点用 flex 居中排列，无需手动定位。JS 中**删除 `tl-n5` 及 sec5 的 `secAnim` / 节点点亮调用**，`tl.set("#timeline", ...)` 显隐时间改为 sec1 显示、outro 隐藏。
4. 美股大盘 4 个指数卡：道琼斯/标普500/纳斯达克/费城半导体，涨跌颜色规则不变（美股同用红涨绿跌，虽与美式习惯相反，但本视频面向中文用户沿用中国习惯）。
5. outro 完全不变（「投资有风险 / 视频内容不构成投资建议」+ 呼吸动画）。

## 动态片段模式版式

当数据带显式「第N部分/片段N」编号且片段数 ≠ 预置数（**a-share = 5、us = 4**）时，动态生成片段。复用模板现有 CSS 类，不新写样式：

| 片段 type | 复用类 | 条目结构 |
|---|---|---|
| `index-cards` 指数卡片 | `.idx-card` | 名称 + 点位 + 涨跌幅（2~6 个；a-share sec1 常用 6 张 = `.grid2` 3 行，旁白只念其中 3 个） |
| `rank-list` 榜单 | `.rank-row` | 排名 + 名称 + 数值 + 涨跌幅（多行） |
| `topics` 话题要点 | `.topic`（新版 chip 结构） | 板块名小标 + 若干 chip（个股名 + 数值 + 涨跌色），参考上方"topics 排版的自适应密度" |

落地要点：

- 每个动态片段 = 一个 `<section class="clip" data-start data-duration data-track-index>`，内部：标题（`.sec-title`）+ 分隔线（`.sec-line`）+ 内容区（按 type 套对应类）+ 底部图标（`.emoji` 内联 SVG，按内容概要手绘，青色 #00D4FF 描边、细线条、约 120px）。
- 进度点：`.timeline` 内 `<div class="tl-node">` 数量 = 片段数 N（flex 居中、`gap: 38px` 自动排布），JS 里对应 `tl.to("#tl-nN", {backgroundColor:"#00d4ff", scale:1.35, ...})` 逐个点亮。
- 旁白：`SEGMENTS` = intro + N 片段 + outro；`secAnim("sN", start, ...)` 与 glow 动画按每段 start 同步。
- 片头三行内容由数据/用户指定，市场兜底：纯美股→「隔夜美股」、含A股→「今日股市」（**片头写法以 SKILL.md 第 5C 步为准**）。

## 卡片式分页版式（2026-09-16 用户确认可用）

把「一段旁白 = 一屏」改成「一段旁白 = 2~3 屏轮播」，专治「一屏内容太多 → 字体被压小 → 密集凌乱」与「画面静止太久」。完整做法与铁律见 SKILL.md 第 5B 步，这里只列版式参数。

| 项 | 单屏原版 | 卡片式分页 |
|---|---|---|
| 内容容器 | `.content`（flex 垂直居中） | `.content.pages`（block，装 `.page`） |
| 一屏元素 | 全部内容（6 卡 / 7 topic） | 1~2 张 `.pcard`（单卡页加 `.hero`） |
| 字号量级 | 正文 26px 起 | 标题 54~62px、数值 50~92px、胶囊名 35~38px、综述行 42px |
| 字重 | 混用 600~800 | **一律 400**（层级靠字号/颜色/底色） |
| 指数卡数字 | inline span 自动换行 | `.idx-nums { flex column }` 锁死两行 |
| 底部图标 `.emoji` | 有 | **删掉** |
| 底部进度点 `.timeline` | 有 | **暂时不要**（删 HTML 时连动画引用一起删） |
| 页点 `.dots` | 无 | 右上角 N 个点，点亮当前屏（可选） |
| 换页时刻 | — | `scripts/page_breaks.py` 实测停顿，误差 <0.05s |
| 校验探针 | `scripts/seek_probe.mjs` | `scripts/seek_pages.mjs` |

切页动画：旧页 `x:-90, opacity:0`，新页 `x:90 → 0`，时长 ~0.30~0.38s，`power2` 缓动；页点同步换色 + `back.out(2)` 脉冲。

**内容高度预算不适用单屏那套**：每个 `.page` 是 `inset:0` 全屏容器，内容自己在页内居中，所以不再受「≲1240px」约束；但**单页内容仍不宜超过约 1400px**，用 `seek_pages.mjs` 的 `SAFE_BOTTOM`（默认 1620）复核。

**入场节奏（关键）**：只拆屏不摊时间 = 把「一段长静止」变「两段中静止」。要把每张卡/每个 chip 对齐到旁白对应分句起点（取 `page_breaks.py` 停顿中点 +0.1s）。实测最长连续静止 35s → 2s。代价是中间态先空着后面的格子（元素只透明、不改布局，不回流）。

