# -*- coding: utf-8 -*-
"""卡片式轮播版 index.html 生成器 —— **A股 / 港韩日 5 板块** 模板（skill 自带）。

════════════════════════════════════════════════════════════════════════
⚠ 这是**模板**，不是某一期的工程。`init_project.py` 会把它和 `_base-head.html`
  一起复制进新工程；你在新工程里改本文件即可。
  示例数据 = 2026年9月29日 的真实行情，**仅作格式参考，逐段替换**。
  本文件由 `scripts/sync_template_from_project.py` 从工程同步而来，
  版式要改就改工程再回灌，别在这里零散手工改（否则下次回灌会被覆盖）。
════════════════════════════════════════════════════════════════════════

运行前置：`audio/segments.json` 必须已存在（由 `audio/gen_narration.py` 生成）。
    python build_cards.py          # 写出 index.html

⚠ 版式基座 `_base-head.html` 必须与本文件**同目录**（= 基座工程 index.html 的
  `<head>` 到 `<body>`）。旧版本文件这里写的是 `../market-XXXX/index.html` ——
  跨工程相对路径，换台机器就找不到，直接导致「只能退回旧模板」。**别改回去。**

★ 结构改动只改下面 `SECTIONS` + 各段 `SEC*_PAGES`，**引擎逻辑不动**。
  改造验证法：`cp index.html _b.html` → 改 → 重跑 → `diff _b.html index.html` **必须为空**。

★ 新内容结构（2026-09-24 用户重订）：
    ① 大盘（2 屏）    屏1 A股 4 指数 / 屏2 港韩日 3 指数 —— 画面与旁白都**只含指数**
    ② 概述（2 屏）    只装横跨 ≥2 个市场的同向驱动；找不到就**整段省略**（段名跳 sec2）
    ③ A股综述（3 屏） 总成交 + 成交额前三 + 领涨 3 板块 + 领跌 3 板块
    ④ 港股综述（1 屏）南向资金净买入 + 领涨/领跌各 1 板块各 1 代表股
    ⑤ 日韩综述（1 屏）日/韩各自领涨/领跌各 1 板块各 1 代表股
    **铁律：概述讲横向共性、各市场段讲纵向个体，同一件事只许出现在一处。**
    段名用固定语义名（大盘=sec1 … 日韩=sec5），省略板块**跳号不顺移**，track 连续。
    韩国统一写「韩国综指」；**不做中国台湾市场**。
    **含指数卡的页必须写 `mini_at`**（漏写 → KeyError，是有意的配置校验，别改成 .get()）。

画面细节（2026-09-16 起的卡片式轮播）：
    整屏分页 `.page` + 段标题常驻 `.sec-title`（「大标题 + 一屏一屏切」靠它）
    换页点落在 `scripts/page_breaks.py` 实测的句末停顿上
    底部 emoji 图标与底部进度点均已删除；卡内文字一律 font-weight 400

片头（2026-09-30 收敛为**唯一模板**，无变体编号；详见 skill 第 5C 步）：
    四行 t=0 全出（**首帧即封面**）：日期小字 / 主线1 / 主线2 / 概述小字
    唯一开关 = 主线「一涨一跌」（涨跌上色 + 方向三角）/「同向」（同青蓝无三角）/「无数字」（纯文字行）
    主线**名称青蓝 #00d4ff**；涨跌幅数字与方向三角按涨跌上色（涨红 #ff4d4f / 跌绿 #00c48c）
    A 涨跌上色 + 50px 方向三角 ｜ B 数字 count-up（只改 textContent，**绝不动 opacity**）
    C 一次性 pulse（**不能改成循环** —— 循环会把 static-dedup 复用率从 ~50% 打到 ~13%）
    入场分三层：核心 0.00 → 装饰线 0.22 / 行2 0.26 / 概述 0.52 → 日期 0.78
    ⚠ 所有 `fromTo` / `from` 必须显式 `immediateRender: false`。

分页依据：`PAGE_BREAKS` 取 `scripts/page_breaks.py`（ffmpeg silencedetect -40dB/0.12s）
对 `assets/narration-v*.mp3` 实测的句末停顿，**不要按字数估**。
"""
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))

# 版式基座随模板携带（`_base-head.html`），**不再引用同级工程** ——
# 旧写法 `../market-XXXX/index.html` 是跨工程相对路径，换台机器/换工作区即失效，
# 症状是「拿不到基线 → 退回包内旧模板」（2026-09-30 排查确认）。别改回去。
BASE = os.path.join(HERE, "_base-head.html")
if not os.path.isfile(BASE):
    raise SystemExit("[error] 版式基座缺失：" + BASE + "（应与 build_cards.py 同目录，勿删）")
with open(BASE, encoding="utf-8") as fh:
    head = fh.read()
assert head.rstrip().endswith("<body>"), head[-200:]
assert "#sec2 .content.dense .topic" in head, "基座 head 缺少 sec2 间距规则"

with open(os.path.join(HERE, "audio", "segments.json"), encoding="utf-8") as f:
    seg = json.load(f)
T = {s["name"]: (s["start"], s["duration"]) for s in seg["segments"]}
total = seg["total"]
t_intro, d_intro = T["intro"]
t_s1, d_s1 = T["sec1"]
t_s2, d_s2 = T["sec2"]
t_s3, d_s3 = T["sec3"]
t_s4, d_s4 = T["sec4"]
t_s5, d_s5 = T["sec5"]
t_out, d_out = T["outro"]
f2 = lambda v: f"{v:.2f}"

# 页面 <title>（只影响浏览器标签 / Studio 列表，不进画面）。
# 不显式替换就永远显示版式基座里那个旧日期。
TITLE = '今日股市行情 2026.09.29'

# 各段换页点（绝对秒，取实测停顿中点；ffmpeg silencedetect -40dB/0.12s 实测）
PAGE_BREAKS = {
    "sec1": [15.64],              # 大盘：A股 4 指数 → 港韩日 3 指数
                                  # （「…科创50涨百分之零点八六。」句末，停 0.63s）
                                  # 两屏 11.19 / 10.64s
    "sec2": [37.43],              # 概述：驱动（美债+油价）→ 传导（港股日韩弱、A股独立红）
                                  # （「…布伦特原油接近九十八美元。」停 0.62s）
                                  # 两屏 11.15 / 8.28s
    "sec3": [56.34, 66.01],       # A股综述：量能+前三 → 领涨 → 领跌
                                  # （「…新易盛。」停 0.63s；「…多股涨停。」停 0.60s）
                                  # 三屏 10.63 / 9.67 / 7.33s
    "sec4": [],                   # 港股综述：单屏（12.66s）
    "sec5": [94.54],              # 日韩综述：日本 → 韩国
                                  # （「…三井住友跌超百分之四。」停 0.63s）
                                  # 两屏 8.54 / 11.04s
}
PAGE_IN = {k: [T[k][0]] + v for k, v in PAGE_BREAKS.items()}

# =================================================================== CSS
CSS = """      /* ================= 卡片式轮播（2026-09-16 A股场次） ================= */
      /* 1) 内容盒改为整屏分页容器（覆盖原垂直居中盒）
         ⚠ 必须限定 .pages：片头/片尾也用 .content，全局覆盖会把它们的
         垂直居中 + 水平居中 + 左右内边距一起干掉。 */
      .content.pages { display: block; padding: 0; }
      .page {
        position: absolute;
        left: 0; right: 0; top: 0; bottom: 0;
        padding: 296px 64px 300px;
        display: flex; flex-direction: column; justify-content: center; gap: 34px;
      }
      /* 全局去加粗：卡内文字 + 页首综述行一律 400。
         ⚠ 必须逐个改在本块里，光加一条 `.pcard *{}` 压不住
         `.pchip .pcv`、`.pcard.mini .idx-val` 这些更高特异性的原声明。 */
      /* 2) 页首要点行 */
      .pg-lead {
        font-size: 42px; font-weight: 400; color: #e6edf6;
        text-align: center; letter-spacing: 1px; line-height: 1.34;
      }
      .pg-lead .hl { color: #00d4ff; font-weight: 400; }
      /* 3) 卡片 */
      .pcard {
        border-radius: 30px;
        background: linear-gradient(158deg, rgba(255,255,255,0.085) 0%, rgba(255,255,255,0.030) 100%);
        border: 1px solid rgba(255,255,255,0.11);
        box-shadow: 0 20px 54px rgba(0,0,0,0.34);
        padding: 36px 38px 38px;
      }
      .pcard.hero { padding: 50px 52px 52px; }
      .pcard.solo { width: 100%; }
      .pc-head { display: flex; align-items: center; gap: 26px; }
      .pc-icon {
        width: 104px; height: 104px; flex: 0 0 104px; border-radius: 26px;
        background: rgba(0,212,255,0.12); border: 1px solid rgba(0,212,255,0.30);
        display: flex; align-items: center; justify-content: center;
      }
      .pc-icon svg { width: 62px; height: 62px; }
      .pcard.hero .pc-icon { width: 132px; height: 132px; flex-basis: 132px; border-radius: 32px; }
      .pcard.hero .pc-icon svg { width: 80px; height: 80px; }
      .pc-title { font-size: 54px; font-weight: 400; color: #ffffff; letter-spacing: 1px; line-height: 1.18; }
      .pcard.hero .pc-title { font-size: 60px; }
      .pc-badge { margin-left: auto; font-size: 54px; font-weight: 400; letter-spacing: 0.5px; font-variant-numeric: tabular-nums; }
      /* 4) 卡内大数字 */
      .pc-hero { display: flex; align-items: baseline; gap: 22px; margin-top: 26px; }
      .pc-hero .hv { font-size: 92px; font-weight: 400; letter-spacing: 1px; font-variant-numeric: tabular-nums; }
      .pc-hero .hu { font-size: 34px; color: #8a94a6; }
      /* 5) 卡内胶囊 */
      .pc-chips { display: grid; gap: 18px; margin-top: 30px; }
      .pc-chips.c1 { grid-template-columns: 1fr; }
      .pc-chips.c2 { grid-template-columns: repeat(2, 1fr); }
      .pc-chips.c3 { grid-template-columns: repeat(3, 1fr); }
      .pchip {
        border-radius: 20px; background: rgba(255,255,255,0.055);
        padding: 22px 24px; display: flex; flex-direction: column; gap: 8px;
      }
      .pcard.hero .pchip { padding: 26px 28px; }
      .pchip .pcn { font-size: 35px; color: #cdd7e4; line-height: 1.2; font-weight: 400; }
      .pchip .pcv { font-size: 50px; font-weight: 400; letter-spacing: 0.5px;
                    font-variant-numeric: tabular-nums; line-height: 1.12; }
      .pchip .pcv.txt { font-size: 32px; line-height: 1.3; font-weight: 400; }
      .pcard.hero .pchip .pcn { font-size: 38px; }
      .pcard.hero .pchip .pcv { font-size: 56px; }
      .pcard.hero .pchip .pcv.txt { font-size: 36px; }
      .pchip .pcs { font-size: 27px; color: #8a94a6; font-weight: 400; }
      .pchip .pcs.up { color: #ff4d4f; }
      .pchip .pcs.down { color: #00c48c; }
      .pchip .pcs.hl { color: #00d4ff; }
      /* 兜底：卡内任何 .hl / .kw 高亮也不许加粗（基座 .hl 是 700） */
      .pcard .hl, .pcard .kw { font-weight: 400; }
      /* 6) 页指示点（右上角，与板块标题同一水平线） */
      .dots { position: absolute; right: 78px; top: 186px; display: flex; gap: 16px; }
      .dot { width: 18px; height: 18px; border-radius: 50%; background: rgba(255,255,255,0.25); }
      /* 7) 指数迷你卡 */
      .pgrid2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px; width: 100%; }
      .pcard.mini { padding: 28px 34px 30px; }
      .pcard.mini .idx-name { font-size: 34px; color: #8a94a6; margin-bottom: 12px; font-weight: 400; }
      .pcard.mini .idx-val { font-size: 58px; font-weight: 400; letter-spacing: 0.5px; }
      /* 点位与涨跌幅强制分两行：两 span 合计宽度随数字长度浮动，短数字会与
         涨幅挤进同一行，跟其他卡长得不一样。flex column 锁死行结构。 */
      .pcard.mini .idx-nums { display: flex; flex-direction: column; align-items: flex-start; }
      .pcard.mini .idx-pct { font-size: 38px; font-weight: 400; margin-left: 0; margin-top: 6px; }
      /* 7c) 休市卡：没有点位/涨跌幅，只给一行说明（2026-09-24 换到韩国）。
         「今日休市」四字按 58px 排 ≈232px，卡内可用 ~396px，单行不折。 */
      .pcard.mini .idx-val.closed { font-size: 52px; color: #8a94a6; letter-spacing: 4px; }
      .pcard.mini .idx-note { font-size: 26px; color: #8a94a6; margin-top: 8px; line-height: 1.25; }
      /* 7b) 两张卡同屏时整体收紧一档 —— 否则「lead + 2 张 hero 卡」会顶到板块标题
         （.page 是 justify-content:center，内容超高会同时向上溢出）。
         注意要写成 .page.two .pcard.hero ... 才压得住 .pcard.hero 的原声明。 */
      .page.two { gap: 26px; }
      .page.two .pcard, .page.two .pcard.hero { padding: 30px 34px 34px; }
      .page.two .pcard .pc-icon, .page.two .pcard.hero .pc-icon { width: 88px; height: 88px; flex-basis: 88px; border-radius: 22px; }
      .page.two .pcard .pc-icon svg, .page.two .pcard.hero .pc-icon svg { width: 54px; height: 54px; }
      .page.two .pcard .pc-title, .page.two .pcard.hero .pc-title { font-size: 46px; }
      .page.two .pcard .pc-badge, .page.two .pcard.hero .pc-badge { font-size: 46px; }
      .page.two .pcard .pc-chips { margin-top: 22px; gap: 14px; }
      .page.two .pcard .pchip, .page.two .pcard.hero .pchip { padding: 18px 22px; gap: 6px; }
      .page.two .pcard .pchip .pcn, .page.two .pcard.hero .pchip .pcn { font-size: 31px; }
      .page.two .pcard .pchip .pcv, .page.two .pcard.hero .pchip .pcv { font-size: 44px; }
      .page.two .pcard .pchip .pcv.txt, .page.two .pcard.hero .pchip .pcv.txt { font-size: 29px; }
      .page.two .pcard .pchip .pcs, .page.two .pcard.hero .pchip .pcs { font-size: 25px; }
      /* 8) 卡内榜单（sec3 屏2） */
      .pcard .rank-list { width: 100%; margin-top: 22px; }
      .pcard .rank-row { height: 96px; font-size: 44px; }
      .pcard .rank-no { width: 90px; font-size: 40px; font-weight: 400; }
      .pcard .rank-name { width: 330px; font-size: 46px; font-weight: 400; }
      .pcard .rank-amt { font-size: 42px; font-weight: 400; }
      .pcard .rank-pct { width: 200px; font-size: 44px; font-weight: 400; }
      /* 7d) 大盘屏2（港韩日 3 指数）：只有 3 张卡 → 单列铺满 + 字号放大一档
         （2026-09-25 用户定：维持 3 张、不补第 4 张；含韩国休市灰字卡）
         高度自检：卡 ≈314px × 3 + gap 40×2 = 1022 < 可用 1324px ✓ */
      .page.ow3 .pgrid2 { grid-template-columns: 1fr; gap: 40px; }
      .page.ow3 .pcard.mini { padding: 44px 52px 46px; }
      .page.ow3 .pcard.mini .idx-name { font-size: 44px; margin-bottom: 18px; }
      .page.ow3 .pcard.mini .idx-val { font-size: 80px; }
      .page.ow3 .pcard.mini .idx-pct { font-size: 50px; margin-top: 10px; }
      .page.ow3 .pcard.mini .idx-val.closed { font-size: 72px; }
      .page.ow3 .pcard.mini .idx-note { font-size: 34px; }
      /* 9) 底部 emoji 已删：留 0 高度锚点当 seek 安全区下边界（y=1620） */
      .emoji { bottom: 300px; height: 0; }
      /* ================= 片头 · 内容概要版（2026-09-17 skill 第 5C 步） =================
         基座 market-20260914 的 head 只有旧版片头（.intro-main / .intro-sub / .intro-line），
         没有三行版式 → 这里补注入 .intro-hook 块（来自 market-us-20260916 同款）。
         **2026-09-24 起走「两行主线（数值）」情形**：主线文字 60px + 数字 112px。
         语义：① 日期+市场（小字） ② 主线A（中号）+ 数字（超大青）
               ③ 主线B（中号）+ 数字（超大青） ④ 一句话概述（小字） */
      .content.intro-hook { padding: 0 72px 160px; }
      .intro-hook .intro-sub {
        margin-bottom: 26px; font-size: 40px; font-weight: 400;
        color: #8a94a6; letter-spacing: 5px;
      }
      /* 日期改纯白（2026-09-17 用户定）：基座灰 #8a94a6 存在感太弱；
         id 特异性 (1,0,0) 压过 .intro-hook .intro-sub (0,2,0)。 */
      #intro-date { transform-origin: 50% 100%; color: #ffffff; }
      .intro-hook .intro-line { width: 320px; height: 3px; margin: 0 0 40px; }
      /* 两行主线（数值版）：字号比单行版收一档（72→60 / 140→112），两行同权重、同样式。
         宽度自检：「创业板指」4 字 × 60 = 240 + gap 22 + 数字 112px「−2.68%」≈ 372
         → 合计 634 < 可用 936px，单行不折（「有色金属」同宽）。 */
      .intro-hook .intro-hook-main {
        display: flex; align-items: baseline; justify-content: center; gap: 22px;
        font-size: 60px; font-weight: 400; color: #ffffff;
        letter-spacing: 4px; line-height: 1.08; text-align: center;
      }
      .intro-hook .intro-hook-main.second { margin-top: 20px; }
      .intro-hook .intro-big {
        font-size: 112px; font-weight: 400; color: #00d4ff;
        letter-spacing: 0; line-height: 1; font-variant-numeric: tabular-nums;
        text-shadow: 0 0 44px rgba(0, 212, 255, 0.42);
      }
      .intro-hook .intro-note {
        margin-top: 40px; font-size: 44px; font-weight: 400;
        color: #cdd7e4; letter-spacing: 2px; text-align: center;
      }
      /* 涨跌色与卡片同源：涨 #ff4d4f / 跌 #00c48c（中国习惯，涨红跌绿） */
      .intro-hook .intro-note .up { color: #ff4d4f; }
      .intro-hook .intro-note .down { color: #00c48c; }
      /* ===== 片头「涨跌对立」情形（2026-09-25）：涨跌对立两条主线 + A/B/C 动效 =====
         主线名称文字用青蓝 #00d4ff（与卡片青关键词同源）；涨跌幅数字与三角按涨跌上色。
         父级 color 不污染子元素：.intro-big.up/.down 自带 color、三角自带 fill，特异性更高。 */
      .intro-hook .intro-hook-main { color: #00d4ff; }
      .intro-hook .intro-big.up   { color: #ff4d4f; text-shadow: 0 0 44px rgba(255, 77, 79, 0.42); }
      .intro-hook .intro-big.down { color: #00c48c; text-shadow: 0 0 44px rgba(0, 196, 140, 0.42); }
      .intro-hook .intro-arrow { width: 50px; height: 50px; flex: 0 0 50px; align-self: center; }
      .intro-hook .intro-arrow.up path   { fill: #ff4d4f; }
      .intro-hook .intro-arrow.down path { fill: #00c48c; }
"""
_p = head.replace("    </style>", CSS + "    </style>", 1)
assert _p != head, "CSS 注入锚点 '    </style>' 未找到"
head = _p

_p = re.sub(r"<title>.*?</title>", "<title>" + TITLE + "</title>", head, count=1)
assert _p != head, "版式基座的 <title> 替换未生效"
head = _p

# =================================================================== 图标
ICON_VIEW = ('viewBox="0 0 24 24" fill="none" stroke="#00D4FF" stroke-width="1.7" '
             'stroke-linecap="round" stroke-linejoin="round"')
ICONS = {
    "chip": '<rect x="7" y="7" width="10" height="10" rx="1.5"/><path d="M9.5 4.5V7M14.5 4.5V7M9.5 17v2.5M14.5 17v2.5M4.5 9.5H7M4.5 14.5H7M17 9.5h2.5M17 14.5h2.5"/>',
    "board": '<rect x="4" y="5" width="16" height="14" rx="1.5"/><path d="M8 9h4M14 9h2M8 12h3M13 12h3M8 15h4M14 15h2"/>',
    "memory": '<rect x="5" y="6" width="14" height="12" rx="1.5"/><path d="M8.5 9.5h7M8.5 12h7M8.5 14.5h4"/>',
    "trending": '<path d="M3 16.5 9 10.5l4 4L21 6.5M21 6.5h-5.5M21 6.5V12"/>',
    "bars": '<path d="M3.5 20h17M5.5 20v-8M10 20V7M14.5 20v-5M19 20V4"/>',
    "volume": '<path d="M4 9.5v5M8 6.5v11M12 3.5v17M16 7.5v9M20 10.5v3"/>',
    "layers": '<path d="M12 3 21 7.5 12 12 3 7.5Z"/><path d="M3 12 12 16.5 21 12M3 16.5 12 21 21 16.5"/>',
    "wind": '<circle cx="12" cy="12" r="2"/><path d="M14 12h6.2M14 12l-4.3 6M12.7 10.5 5.4 7.6"/>',
    "battery": '<rect x="2.5" y="7.5" width="15" height="9" rx="2"/><path d="M20.5 10.5v3M6 12h7M9.5 8.5v7"/>',
    "utensils": '<path d="M6.5 3v7.5a2.5 2.5 0 0 0 5 0V3M9 10.5V21"/><path d="M16.5 3c-1.4 1.6-2 3-2 5.2 0 1.6.7 2.6 2 3.1V21"/>',
    "wheat": '<path d="M12 21V9"/><path d="M12 9c0-2 1.4-3.4 3.2-3.4C15.2 7.4 14 9 12 9ZM12 9c0-2-1.4-3.4-3.2-3.4C8.8 7.4 10 9 12 9Z"/><path d="M12 14.5c0-2 1.4-3.4 3.2-3.4 0 1.8-1.2 3.4-3.2 3.4ZM12 14.5c0-2-1.4-3.4-3.2-3.4 0 1.8 1.2 3.4 3.2 3.4Z"/><path d="M6 21h12"/>',
    "globe": '<circle cx="12" cy="12" r="8.6"/><path d="M3.4 12h17.2M12 3.4c2.5 2.6 2.5 14.6 0 17.2M12 3.4c-2.5 2.6-2.5 14.6 0 17.2"/>',
    "bank": '<path d="M3 9.5 12 4l9 5.5"/><path d="M5 9.5V19M9.5 9.5V19M14.5 9.5V19M19 9.5V19M3 19h18"/>',
    "gold": '<rect x="9" y="7.5" width="6" height="4.5" rx="0.8"/><rect x="5" y="14" width="6" height="5" rx="0.8"/><rect x="13" y="14" width="6" height="5" rx="0.8"/>',
    "oil": '<path d="M12 3.2c0 0-6.2 7.4-6.2 11.4a6.2 6.2 0 0 0 12.4 0c0-4-6.2-11.4-6.2-11.4Z"/>',
    "coin": '<ellipse cx="12" cy="6.6" rx="7.5" ry="3.1"/><path d="M4.5 6.6v5c0 1.7 3.4 3.1 7.5 3.1s7.5-1.4 7.5-3.1v-5M4.5 11.6v5c0 1.7 3.4 3.1 7.5 3.1s7.5-1.4 7.5-3.1v-5"/>',
    "pill": '<rect x="3.6" y="9.4" width="16.8" height="8.2" rx="4.1" transform="rotate(-45 12 13.5)"/><path d="M8.6 8.4 15.4 15.2"/>',
    "building": '<path d="M4 21V6.5L12 3v18"/><path d="M12 21V9l8 3v9M7 9.5h2M7 13h2M7 16.5h2M15.5 13.5h1.5M15.5 17h1.5M2.5 21h19"/>',
    "cup": '<path d="M5.5 4h13l-1.4 14.2a1.6 1.6 0 0 1-1.6 1.4H8.5a1.6 1.6 0 0 1-1.6-1.4Z"/><path d="M6.2 10h11.6M9 7h6"/>',
}
ICON_TREND_DOWN = ('<svg viewBox="0 0 24 24" fill="none" stroke="#00D4FF" stroke-width="1.7" '
                   'stroke-linecap="round" stroke-linejoin="round">'
                   '<path d="M3 7l6.2 6.2 3.6-3.6 8.2 7.9"/><path d="M21 12.2v5.3h-5.4"/></svg>')


def ico(key):
    # `trenddown` 是独立常量、不在 ICONS 字典里（2026-09-25 美股场次踩到 KeyError）
    if key == "trenddown":
        return ICON_TREND_DOWN
    return f'<svg {ICON_VIEW}>{ICONS[key]}</svg>'


# =================================================================== 数据
def C(n, v, c="", s=None, t=False, sc=""):
    """一条胶囊：名称 / 数值 / 涨跌色 / 补充小字 / 文本型 / 小字颜色类"""
    return {"n": n, "v": v, "c": c, "s": s, "t": t, "sc": sc}


def K(icon, title, chips, cols=3, hero=False, at=0.35, chip_at=None,
      badge=None, badge_cls=""):
    return {"icon": icon, "title": title, "chips": chips, "cols": cols,
            "hero": hero, "at": at, "chip_at": chip_at or [],
            "badge": badge, "badge_cls": badge_cls}


# ---------------------------------------------------------------- sec1 大盘
# ★ 新结构：**画面与旁白都只含指数、不含任何其他信息**（量能与下跌动因已分别
#   移入 sec2 概述 / sec3 A股综述）。屏1 = A股 4 指数（固定 4 个）；屏2 = 港韩日 3 指数。
SEC1_CARDS = [
    ("上证指数", "3,830.45", "+0.18%"),
    ("沪深300", "4,345.21", "+0.10%"),
    ("创业板指", "3,142.56", "+0.09%"),
    ("科创50", "1,569.34", "+0.86%"),
]
# 逐张对齐旁白念到该指数的时刻（旁白 4 个全念，一项一句）。
# 旁白实测：句末停顿在 +1.20(首先看A股) / +3.64(上证) / +6.22(沪深300) / +8.65(创业板)
# ⚠ QA 以 0.4s 步长从「切点-0.45s」往前数连续静止帧，比生成器预估少 0.4~0.5s
#   → 末张必须留足余量：切点 +11.19s，末张 7.90 + 1.34 = 9.24 落位，
#     静止窗 9.54~10.74 ≈ 1.6s，刚好过 1.5s 门槛（别往后推）。
S1_IDX_AT = [1.70, 3.90, 6.10, 7.90]

SEC1_CARDS2 = [
    ("恒生指数", "24,523.57", "\u22120.48%"),
    ("日经225", "65,481.27", "\u22120.60%"),
    ("韩国综指", "6,870.81", "\u22120.27%"),
]
S1B_IDX_AT = [1.90, 4.40, 6.90]

SEC1_PAGES = [
    {"mini": SEC1_CARDS, "mini_at": S1_IDX_AT, "cards": []},
    # 屏2 只有 3 张卡 → 走 `.page.ow3`：单列铺满 + 字号放大一档，
    # 避免与屏1 的 4 卡版式（2×2）密度差一倍。
    {"page_cls": "ow3", "mini": SEC1_CARDS2, "mini_at": S1B_IDX_AT, "cards": []},
]

# ---------------------------------------------------------------- sec2 概述
# 只装**横跨 ≥2 个市场的同向驱动**；各市场独有的驱动归该市场段。
# 铁律：概述讲横向共性、各市场段讲纵向个体 —— 这里讲驱动与跨市场传导，
# **具体板块的涨跌幅读数留给 sec3/sec4/sec5**，避免同一件事出现两处。
SEC2_PAGES = [
    # 屏1 驱动：长端美债与油价双双高企（隔夜数据，跨市场共同背景）
    {"lead": '驱动 · <span class="hl">长端美债与油价双双高企</span>',
     "lead_at": 0.05,
     "cards": [
         K("globe", "利率与油价", [
             C("10年期美债", "5.239%", "down", "2007 年以来最高"),
             C("布伦特原油", "98.33 美元", "up", "美伊谈判无实质进展"),
             C("30年期美债", "突破 5.5%", "down", "续创多年新高"),
             C("全球无风险利率", "中枢抬升", "down", "压制高估值资产"),
         ], cols=2, hero=True, at=0.15, chip_at=[1.20, 6.60, 3.40, 8.20])]},
    # 屏2 传导：同一驱动在多个市场的同向表现（横向共性，不重复各市场段的纵向个股）
    {"lead": '传导 · <span class="hl">亚太风险偏好回落</span>',
     "lead_at": 0.05,
     "cards": [
         K("wind", "跨市场传导", [
             C("港股 · 恒生科技", "\u22121.08%", "down", "权重科技股集体下挫"),
             C("日本 · 韩国", "连续第二日收跌", "down", "日经 \u22120.60% · 韩国综指 \u22120.27%"),
             C("A股 · 独立收红", "国内政策预期", "up", "国常会稳地产 · 促就业增收"),
         ], cols=1, hero=True, at=0.15, chip_at=[0.60, 3.00, 5.60])]},
]

# ---------------------------------------------------------------- sec3 A股综述
SEC3_PAGES = [
    # 屏1：市场总成交 + 成交额前三（旁白逐条念）
    {"lead": '两市成交 <span class="hl">1.41 万亿</span> · 缩量 2,936 亿',
     "lead_at": 0.05,
     "cards": [
         K("volume", "量能与成交额前三", [
             C("两市成交", "1.41 万亿", "hl", "缩量 2,936 亿 · 14 个月新低"),
             C("中际旭创", "130.99 亿", "hl", "\u22120.24% 居首"),
             C("亨通光电", "113.44 亿", "hl", "\u22125.82% 第二"),
             C("新易盛", "100.62 亿", "hl", "\u22121.70% 第三"),
         ], cols=2, hero=True, at=0.15, chip_at=[0.60, 2.60, 4.60, 6.60])]},
    # 屏2：领涨 3 板块（每板块画面最多 3 只代表个股；**旁白只点名一只领涨股**）
    {"lead": '领涨方向 · <span class="hl">房地产板块走强</span>',
     "lead_at": 0.05,
     "cards": [
         K("building", "领涨 · 三个板块", [
             C("房地产", "+4.06%", "up", "特发服务 +13.49% · 万科A涨停"),
             C("固态电池", "武汉蓝电涨停", "up", "尚水智能 +20% · 国轩高科涨停"),
             C("PCB · 元件", "迅捷兴 +20%", "up", "依顿电子 · 奥士康涨停"),
         ], cols=1, hero=True, at=0.15, chip_at=[0.60, 3.20, 5.60])]},
    # 屏3：领跌 3 板块（**旁白只念板块、不念个股**）
    {"lead": '领跌方向 · <span class="hl">石油石化跌幅居首</span>',
     "lead_at": 0.05,
     "cards": [
         K("oil", "领跌 · 三个板块", [
             C("石油石化", "\u22121.66%", "down", "恒逸石化领跌 · 荣盛石化"),
             C("培育钻石", "黄河旋风 \u22129.70%", "down", "惠丰钻石 \u22128.16%"),
             C("种植业", "万向德农跌停", "down", "金健米业 \u22129.97%"),
         ], cols=1, hero=True, at=0.15, chip_at=[0.60, 2.60, 4.60])]},
]

# ---------------------------------------------------------------- sec4 港股综述
# **只要南向资金一个数**（2026-09-24 用户定：不报大市总成交额）
# + 领涨 1 板块 1 代表股 + 领跌 1 板块 1 代表股。
# 领跌**避开「黄金股」**（已进 sec2 共性②）与「AI硬件/存储」（已进 sec2 共性①）。
SEC4_PAGES = [
    {"lead": '南向资金 <span class="hl">净买入 0.15 亿港元</span> · 基本持平',
     "lead_at": 0.05,
     "cards": [
         K("building", "内房股领涨", [
             C("万科企业", "+11.29%", "up", "融信中国 +17.95% · 世茂集团 +15.79%"),
             C("催化", "国常会稳地产", "up", "研究出台稳定房地产市场举措", t=True),
         ], cols=1, at=0.60, chip_at=[1.10, 3.40]),
         K("trenddown", "汽车股领跌", [
             C("吉利汽车", "\u22127.36%", "down", "领跌恒指成分股"),
             C("同向", "蔚来 \u22125% · 小鹏 \u22124%", "down", "港股汽车板块集体走低", t=True),
         ], cols=1, at=5.20, chip_at=[5.70, 7.60]),
     ]},
]

# ---------------------------------------------------------------- sec5 日韩综述
# 日/韩**各自**领涨 1 板块 1 代表股 + 领跌 1 板块 1 代表股；
# 韩国统一写「韩国综指」；韩国休市 → 只讲休市安排，**不引上一交易日收盘值**。
# 日经涨跌幅已在 sec1 大盘报过，本段不再重复指数。
SEC5_PAGES = [
    {"lead": '日本 · <span class="hl">半导体设备领涨</span>',
     "lead_at": 0.05,
     "cards": [
         K("chip", "日本 · 板块涨跌", [
             C("领涨", "半导体设备", "up", "网屏制造 +2.65% · 迪斯科 +4%", t=True),
             C("领跌", "银行 · 金融", "down", "三井住友 \u22124% · 三菱UFJ \u22123.5%", t=True),
         ], cols=1, at=0.80, chip_at=[1.30, 3.60])]},
    {"lead": '韩国 · <span class="hl">半导体设备与材料领涨</span>',
     "lead_at": 0.05,
     "cards": [
         K("memory", "韩国 · 板块涨跌", [
             C("领涨", "半导体设备 · 材料", "up", "HPSP +8.93% · PSK +8.33%", t=True),
             C("领跌", "电池 · 建筑", "down", "LG新能源 \u22123.16% · 三星SDI \u22124.13%", t=True),
         ], cols=1, at=0.80, chip_at=[1.30, 3.60])]},
]

# =================================================================== 渲染
_hf = [0]


def hid():
    _hf[0] += 1
    return f'hf-c{_hf[0]}'


class Seq:
    """页内可动元素的类名发号器（DOM 顺序）。

    给每个要入场的元素一个**唯一选择器类名**（如 a0_3 = 第 0 屏第 4 个），
    时间轴 JS 用 `#sec1 .a0_3` 单独驱动它。比「按下标取 querySelectorAll 第 N 个」
    稳：DOM 顺序变了不会静默错位；hyperframes lint 也不会把一大堆
    `tl.from(动态变量)` 误判成同一个选择器上的重叠 tween。
    """

    def __init__(self, pi):
        self.pi = pi
        self.n = 0

    def next(self):
        c = f"a{self.pi}_{self.n}"
        self.n += 1
        return c


def chips_html(chips, cols, sq):
    cls = []
    out = [f'          <div class="pc-chips c{cols}" data-hf-id="{hid()}">']
    for c in chips:
        vcls = "pcv txt" if c["t"] else "pcv"
        scls = ("pcs " + c["sc"]).strip()
        k = sq.next()
        cls.append(k)
        out.append(f'            <div class="pchip {k}" data-hf-id="{hid()}">')
        out.append(f'              <div class="pcn" data-hf-id="{hid()}">{c["n"]}</div>')
        out.append(f'              <div class="{vcls} {c["c"]}" data-hf-id="{hid()}">{c["v"]}</div>')
        if c["s"]:
            out.append(f'              <div class="{scls}" data-hf-id="{hid()}">{c["s"]}</div>')
        out.append("            </div>")
    out.append("          </div>")
    return "\n".join(out), cls


def card_html(c, sq):
    k = sq.next()
    body, chip_cls = chips_html(c["chips"], c["cols"], sq)
    cls = "pcard hero" if c.get("hero") else "pcard"
    o = [f'        <div class="{cls} {k}" data-hf-id="{hid()}">']
    o.append(f'          <div class="pc-head" data-hf-id="{hid()}">')
    o.append(f'            <div class="pc-icon" data-hf-id="{hid()}">{ico(c["icon"])}</div>')
    o.append(f'            <div class="pc-title" data-hf-id="{hid()}">{c["title"]}</div>')
    if c.get("badge"):
        o.append(f'            <div class="pc-badge {c["badge_cls"]}" data-hf-id="{hid()}">{c["badge"]}</div>')
    o.append("          </div>")
    o.append(body)
    o.append("        </div>")
    return "\n".join(o), k, chip_cls


def mini_html(cards, sq):
    """指数迷你卡。三参数 (名称, 点位/主值, 涨跌幅)；
    **涨跌幅为空 = 休市卡**：主值走 .closed 灰字，不标涨跌色（2026-09-24 韩国中秋休市）。"""
    cls = []
    out = [f'          <div class="pgrid2" data-hf-id="{hid()}">']
    for n, v, p in cards:
        k = sq.next()
        cls.append(k)
        if not p:
            out.append(f'''            <div class="pcard mini idx-card {k}" data-hf-id="{hid()}">
              <div class="idx-name" data-hf-id="{hid()}">{n}</div>
              <div class="idx-nums" data-hf-id="{hid()}"><span class="idx-val closed" data-hf-id="{hid()}">{v}</span><span class="idx-note" data-hf-id="{hid()}">中秋休市 · 9/28 复市</span></div>
            </div>''')
            continue
        tone = "down" if p.startswith(("\u2212", "-")) else "up"
        out.append(f'''            <div class="pcard mini idx-card {k}" data-hf-id="{hid()}">
              <div class="idx-name" data-hf-id="{hid()}">{n}</div>
              <div class="idx-nums" data-hf-id="{hid()}"><span class="idx-val {tone}" data-hf-id="{hid()}">{v}</span><span class="idx-pct {tone}" data-hf-id="{hid()}">{p}</span></div>
            </div>''')
    out.append("          </div>")
    return "\n".join(out), cls


def rank_html(rows, card, sq):
    k = sq.next()
    cls = "pcard hero" if card.get("hero") else "pcard"
    o = [f'        <div class="{cls} {k}" data-hf-id="{hid()}">',
         f'          <div class="pc-head" data-hf-id="{hid()}">',
         f'            <div class="pc-icon" data-hf-id="{hid()}">{ico(card["icon"])}</div>',
         f'            <div class="pc-title" data-hf-id="{hid()}">{card["title"]}</div>',
         "          </div>",
         f'          <div class="rank-list" data-hf-id="{hid()}">']
    rcls = []
    for n, nm, amt, p, c in rows:
        rk = sq.next()
        rcls.append(rk)
        o.append(f'            <div class="rank-row {rk}" data-hf-id="{hid()}"><span class="rank-no" data-hf-id="{hid()}">{n}</span>'
                 f'<span class="rank-name" data-hf-id="{hid()}">{nm}</span>'
                 f'<span class="rank-amt" data-hf-id="{hid()}">{amt}</span>'
                 f'<span class="rank-pct {c}" data-hf-id="{hid()}">{p}</span></div>')
    o.append("          </div>")
    o.append("        </div>")
    return "\n".join(o), k, rcls


def page_html(name, pi, pg):
    """返回 (html, [(类名, 绝对入场秒, y偏移, 动画时长)])。

    入场时刻＝该元素对齐的旁白分句起点（不新增元素，只改时间）。
    """
    base = PAGE_IN[name][pi]
    sq = Seq(pi)
    ents = []
    ncard = len(pg.get("cards", [])) + (1 if pg.get("rows") else 0)
    _xcls = (" " + pg["page_cls"]) if pg.get("page_cls") else ""
    o = [f'        <div class="page{" two" if ncard >= 2 else ""}{_xcls}" data-page="{pi}" data-hf-id="{hid()}">']
    if pg.get("lead"):
        k = sq.next()
        o.append(f'          <div class="pg-lead {k}" data-hf-id="{hid()}">{pg["lead"]}</div>')
        ents.append((k, round(base + pg.get("lead_at", 0.05), 2), 26, 0.42))
    if pg.get("mini"):
        # 指数卡入场偏移由页配置自带（不再按段名硬编码）—— 缺省退化为等间隔 1.0s。
        offs = pg.get("mini_at") or [1.00] * len(pg["mini"])
        t0 = base   # ★ 屏起点（不是段起点）：同一段可有 2 屏指数卡（大盘屏1+屏2）
        body, cls = mini_html(pg["mini"], sq)
        o.append(body)
        for i, k in enumerate(cls):
            # 1.34 = 入场 0.28s 延迟 + 数字滚动 0.75s + 涨跌幅 pop 到 +1.06
            ents.append((k, round(t0 + offs[i], 2), 34, 1.34))
    if pg.get("rows"):
        body, k, rcls = rank_html(pg["rows"], pg["rows_card"], sq)
        o.append(body)
        ents.append((k, round(base + 0.10, 2), 32, 0.42))
        for i, rk in enumerate(rcls):
            ents.append((rk, round(base + pg["rows_at"][i], 2), 22, 0.42))
    for c in pg.get("cards", []):
        body, k, ccls = card_html(c, sq)
        o.append(body)
        ents.append((k, round(base + c["at"], 2), 32, 0.42))
        for i, ck in enumerate(ccls):
            ents.append((ck, round(base + c["chip_at"][i], 2), 22, 0.42))
    o.append("        </div>")
    return "\n".join(o), ents


def section_html(name, sid, start, dur, track, title_html, pages):
    o = [f'      <section data-hf-id="{hid()}" id="{name}" class="clip" data-start="{f2(start)}" '
         f'data-duration="{f2(dur)}" data-track-index="{track}">']
    o.append(f'        <div data-hf-id="{hid()}" id="{sid}-glow" class="glow"></div>')
    o.append(f'        <div data-hf-id="{hid()}" id="{name}-title" class="sec-title">')
    o.append(f'          <span data-hf-id="{hid()}">{title_html}</span>')
    o.append(f'          <div data-hf-id="{hid()}" id="{sid}-line" class="sec-line"></div>')
    o.append("        </div>")
    o.append(f'        <div data-hf-id="{hid()}" id="{sid}-dots" class="dots">')
    for _ in pages:
        o.append(f'          <i data-hf-id="{hid()}" class="dot"></i>')
    o.append("        </div>")
    o.append(f'        <div data-hf-id="{hid()}" class="content pages">')
    for i, pg in enumerate(pages):
        body, _ = page_html(name, i, pg)
        o.append(body)
    o.append("        </div>")
    o.append(f'        <div data-hf-id="{hid()}" id="{sid}-emoji" class="emoji"></div>')
    o.append("      </section>")
    return "\n".join(o)


def entrances(name, pages):
    out = []
    for pi, pg in enumerate(pages):
        _, e = page_html(name, pi, pg)
        out.extend(e)
    return out


def js_ent(name, ents):
    """把入场表编成显式 tween 行 —— 每个元素一个唯一选择器，lint 不会误判重叠。"""
    return "\n".join(
        f'      tl.from("#{name} .{k}", {{ y: {y}, autoAlpha: 0, duration: 0.42, '
        f'ease: "power3.out" }}, {t:.2f});'
        for k, t, y, _ in ents)


# =================================================================== 组装
# ★★ 结构性改动只改这个 SECTIONS 列表 ★★
#   每项 = 一个内容段。增删板块（例：A股新结构下「概述」段找不到跨市场共性就删掉
#   这一项）、换标题、调顺序，都只动这里，引擎与其余代码不用改。
#   - name  ：段 id，必须与 audio/segments.json 的段名逐字一致（也用作 <section id>）
#   - sid    ：段内元素 id 前缀（<sid>-glow / <sid>-line / <sid>-dots）
#   - track  ：data-track-index（渲染分轨，逐段递增）
#   - label  ：生成日志与 JS 注释里的段名
#   - title  ：段标题 HTML —— 常驻元素，切屏不消失（「大标题 + 多画面切换」靠它）
#   - pages  ：屏配置列表（写法见上面的 SEC*_PAGES）
SECTIONS = [
    {"name": "sec1", "sid": "s1", "track": 1, "label": "① 大盘（2 屏）",
     "title": '大盘', "pages": SEC1_PAGES},
    {"name": "sec2", "sid": "s2", "track": 2, "label": "② 概述（2 屏）",
     "title": '概述', "pages": SEC2_PAGES},
    {"name": "sec3", "sid": "s3", "track": 3, "label": "③ A股综述（3 屏）",
     "title": 'A股<span class="kw">综述</span>', "pages": SEC3_PAGES},
    {"name": "sec4", "sid": "s4", "track": 4, "label": "④ 港股综述（1 屏）",
     "title": '港股<span class="kw">综述</span>', "pages": SEC4_PAGES},
    {"name": "sec5", "sid": "s5", "track": 5, "label": "⑤ 日韩综述（2 屏）",
     "title": '日韩<span class="kw">综述</span>', "pages": SEC5_PAGES},
]

SEC_HTML = [section_html(s["name"], s["sid"], T[s["name"]][0], T[s["name"]][1],
                         s["track"], s["title"], s["pages"]) for s in SECTIONS]

INTRO = f'''      <!-- ============ 片头 · 唯一模板（skill 第 5C 步；本期取「涨跌对立」情形：两条主线 + A/B/C 动效） ============ -->
      <section data-hf-id="{hid()}" id="intro" class="clip" data-start="0" data-duration="{f2(d_intro)}" data-track-index="0">
        <div data-hf-id="{hid()}" class="content intro-hook">
          <p data-hf-id="{hid()}" id="intro-date" class="intro-sub">2026年9月29日 · 今日股市</p>
          <div data-hf-id="{hid()}" id="intro-line" class="intro-line"></div>
          <h1 data-hf-id="{hid()}" id="intro-main" class="intro-hook-main">科创50<svg data-hf-id="{hid()}" class="intro-arrow up" viewBox="0 0 20 20" aria-hidden="true"><path d="M10 2.4 18.6 16.6H1.4Z"/></svg><span data-hf-id="{hid()}" id="intro-big" class="intro-big up">+0.86%</span></h1>
          <h1 data-hf-id="{hid()}" id="intro-main2" class="intro-hook-main second">恒生科技<svg data-hf-id="{hid()}" class="intro-arrow down" viewBox="0 0 20 20" aria-hidden="true"><path d="M10 17.6 1.4 3.4h17.2Z"/></svg><span data-hf-id="{hid()}" id="intro-big2" class="intro-big down">\u22121.08%</span></h1>
          <p data-hf-id="{hid()}" id="intro-note" class="intro-note">缩量微涨 · 成交1.41万亿 · 地产领涨</p>
        </div>
      </section>
'''

BODY_HEAD = (f'    <div data-hf-id="{hid()}" id="root" data-composition-id="main" data-start="0" '
             f'data-duration="{f2(total)}" data-width="1080" data-height="1920">\n{INTRO}')

TAIL_TMPL = '''      <!-- ============ 片尾 ============ -->
      <section data-hf-id="__H__" id="outro" class="clip" data-start="__TO__" data-duration="__DO__" data-track-index="6">
        <div data-hf-id="__H__" class="content">
          <div data-hf-id="__H__" id="cta-halo" class="cta-halo"></div>
          <h2 data-hf-id="__H__" id="cta-title" class="cta-title">投资有风险</h2>
          <div data-hf-id="__H__" id="cta-line" class="cta-line">
            <i data-hf-id="__H__" id="cta-sheen" class="cta-sheen"></i>
          </div>
          <p data-hf-id="__H__" id="cta-sub" class="cta-sub">视频内容不构成投资建议</p>
        </div>
      </section>

      <!-- 底部进度点（timeline）已按用户要求移除：下方只保留右上角分页指示点 -->
      <audio data-hf-id="__H__" id="narration" src="assets/narration-v1.mp3" data-start="0"></audio>
      <audio data-hf-id="__H__" id="utvh" src="assets/bgm-v1.wav" data-start="0" data-volume="0.16" data-track-index="1"></audio>
    </div>
'''
TAIL = TAIL_TMPL.replace("__TO__", f2(t_out)).replace("__DO__", f2(d_out))
while "__H__" in TAIL:
    TAIL = TAIL.replace("__H__", hid(), 1)

# ---------------------------------------------------------------- timeline JS
JS = r'''
    <script>
      const tl = gsap.timeline({ paused: true });

      /* ============ 数字滚动（由 pct 反推昨收，滚到今天） ============ */
      function fmt(v) {
        return v.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      }
      function setupCountCards(secId, times) {
        const cards = document.querySelectorAll("#" + secId + " .idx-card");
        cards.forEach(function (card, i) {
          const valEl = card.querySelector(".idx-val");
          const pctEl = card.querySelector(".idx-pct");
          if (!valEl || !pctEl) return;   /* 休市卡没有 .idx-pct → 跳过滚动 */
          const to = parseFloat(valEl.textContent.replace(/,/g, ""));
          const pct = parseFloat(pctEl.textContent.replace(/%/g, "").replace(/\u2212/g, "-"));
          if (isNaN(to) || isNaN(pct) || pct === 0) return;
          const from = to / (1 + pct / 100);
          valEl.textContent = fmt(from);
          const obj = { v: from };
          /* times：逐张指定**绝对**入场时刻（跨屏累加，对齐旁白逐条报指数）；
             滚动 0.75s + power1.out —— 尾巴太长会让末张卡滚到切屏前才停，完整态不足。 */
          const t0 = times[i] + 0.28;
          tl.to(obj, { v: to, duration: 0.75, ease: "power1.out",
            onUpdate: function () { valEl.textContent = fmt(obj.v); } }, t0);
          tl.from(pctEl, { scale: 0.4, autoAlpha: 0, duration: 0.34, ease: "back.out(2.2)" }, t0 + 0.72);
        });
      }

      /* ============ 片头 · 内容概要版（四行 t=0 全出，入场分三层） ============
         ① 核心 0.00~0.66s  主线行1 + 超大数字
         ② 支撑 0.22~1.06s  分隔线 + 主线行2 + 超大数字 + 一句话概述
         ③ 日期 0.78~1.63s  由大变小（纯白 #ffffff，只靠尺度做强调）
         全部只做位移/缩放 —— **绝不动 opacity**，否则 t=0 首帧黑屏、
         平台抽首帧当封面就废了（旧版 y:-320 + autoAlpha:0 的教训）。 */
      tl.from("#intro-main",   { y: -60,      duration: 0.66, ease: "power3.out"    }, 0.00);
      tl.from("#intro-big",    { scale: 0.58, duration: 0.74, ease: "back.out(2.0)" }, 0.12);
      tl.fromTo("#intro-line", { scaleX: 0.35 }, { scaleX: 1, duration: 0.54, ease: "power2.inOut", immediateRender: false }, 0.22);
      tl.from("#intro-main2",  { y: -44,      duration: 0.60, ease: "power3.out"    }, 0.26);
      tl.from("#intro-big2",   { scale: 0.58, duration: 0.68, ease: "back.out(2.0)" }, 0.38);
      tl.from("#intro-note",   { y: 26,       duration: 0.54, ease: "power3.out"    }, 0.52);
      tl.fromTo("#intro-date", { scale: 1.25 },
                               { scale: 1.0, duration: 0.85, ease: "power2.out", immediateRender: false }, 0.78);

      /* ===== 片头 A/B/C（2026-09-25；三条铁律见 skill 第 5C 步） =====
         铁律①：from()/fromTo() 一律显式 immediateRender:false —— paused timeline 里它们
                默认 true，会在 t=0 就写成起始值：三角被压成 30%（封面里就是个小三角），
                fromTo 的 scale:1.0 还会盖掉数字自己的 from{scale:0.58} 入场。 */
      /* A · 方向三角入场（scale 0.30 → 过冲 → 1.0），与同排数字弹性同步 */
      tl.fromTo("#intro-main .intro-arrow",  { scale: 0.30 },
              { scale: 1, duration: 0.60, ease: "back.out(2.6)", immediateRender: false }, 0.12);
      tl.fromTo("#intro-main2 .intro-arrow", { scale: 0.30 },
              { scale: 1, duration: 0.56, ease: "back.out(2.6)", immediateRender: false }, 0.38);
      /* B · 数字 count-up（只改 textContent、绝不动 opacity —— t=0 封面必须是终值）。
             铁律③：HTML 里写终值、count-up 在 t>0 才启动 → 封面正确，代价是 t=0~0.12s
             这 4 帧先显终值再回落，此时数字仍在 scale 0.58→1.0 放大中，观感可接受。 */
      function countUp(sel, end, tStart) {
        const el = document.querySelector(sel);
        const sign = end >= 0 ? "+" : "\u2212";
        const o = { v: 0 };
        tl.to(o, { v: Math.abs(end), duration: 0.62, ease: "power2.out",
          onUpdate: function () { el.textContent = sign + o.v.toFixed(2) + "%"; } }, tStart);
      }
      countUp("#intro-big",  0.86, 0.12);
      countUp("#intro-big2", -1.08, 0.38);
      /* C · 一次性 pulse（yoyo:true + repeat:1）。铁律②：改成无限循环会把 static-dedup
             复用率从 ~50% 打到 ~13%，渲染时长与体积双涨。 */
      tl.fromTo("#intro-big, #intro-big2", { scale: 1.0 },
              { scale: 1.045, duration: 0.26, ease: "sine.inOut", yoyo: true, repeat: 1,
                immediateRender: false }, 3.00);

      /* ============ 板块通用：标题左滑 + 分隔线 + 右上角页点 + 光晕 ============ */
      function secChrome(name, sid, tStart) {
        tl.from("#" + name + "-title", { x: -80, autoAlpha: 0, duration: 0.35, ease: "back.out(1.7)" }, tStart + 0.05);
        tl.fromTo("#" + sid + "-line", { scaleX: 0, autoAlpha: 0 }, { scaleX: 1, autoAlpha: 1, duration: 0.4, ease: "power2.inOut" }, tStart + 0.30);
        if (document.getElementById(sid + "-dots")) {
          tl.from("#" + sid + "-dots .dot", { autoAlpha: 0, x: 30, duration: 0.4, ease: "power2.out", stagger: 0.07 }, tStart + 0.22);
        }
        tl.fromTo("#" + sid + "-glow", { opacity: 0.25 }, { opacity: 0.6, duration: 1.2, ease: "sine.inOut", yoyo: true, repeat: 1 }, tStart + 1.5);
      }

      /* ============ 分页轮播：切页淡出左移 / 淡入右移 + 页点点亮 ============ */
      function pages(name, times) {
        const sec = document.getElementById(name);
        const ps = sec.querySelectorAll(".page");
        const dots = sec.querySelectorAll(".dot");
        tl.set(ps, { opacity: 0, x: 90 }, 0);
        if (dots.length) tl.set(dots, { backgroundColor: "rgba(255,255,255,0.25)", scale: 1 }, 0);
        for (let i = 0; i < ps.length; i++) {
          const t = times[i];
          tl.fromTo(ps[i], { opacity: 0, x: 90 }, { opacity: 1, x: 0, duration: 0.38, ease: "power2.out" }, t);
          if (dots.length) {
            tl.to(dots[i], { backgroundColor: "#00d4ff", scale: 1.4, duration: 0.3, ease: "back.out(2)" }, t + 0.04);
            if (i > 0) tl.to(dots[i - 1], { backgroundColor: "rgba(255,255,255,0.25)", scale: 1, duration: 0.3 }, t - 0.30);
          }
          if (i > 0) tl.to(ps[i - 1], { opacity: 0, x: -90, duration: 0.30, ease: "power2.in" }, t - 0.32);
        }
      }

      /* 元素入场 tween 由 build_cards.py 逐条注入（每个元素一个唯一类名） */

__SECTIONS_JS__

      /* ============ 片尾 CTA ============ */
      const OT = __TOUT__;
      tl.fromTo("#cta-halo", { scale: 0.35, autoAlpha: 0 }, { scale: 1, autoAlpha: 1, duration: 0.85, ease: "power2.out" }, OT + 0.02);
      tl.from("#cta-title", { y: 46, scale: 0.68, autoAlpha: 0, duration: 0.55, ease: "back.out(2.6)" }, OT + 0.08);
      tl.fromTo("#cta-line", { scaleX: 0, autoAlpha: 0 }, { scaleX: 1, autoAlpha: 1, duration: 0.55, ease: "power3.inOut" }, OT + 0.42);
      tl.fromTo("#cta-sheen", { xPercent: -120 }, { xPercent: 260, duration: 0.8, ease: "power2.inOut" }, OT + 0.62);
      tl.from("#cta-sub", { y: 26, scale: 0.55, autoAlpha: 0, duration: 0.6, ease: "back.out(2.4)" }, OT + 0.70);
      tl.fromTo("#cta-sub", { textShadow: "0 0 0px rgba(0,212,255,0)" }, { textShadow: "0 0 34px rgba(0,212,255,0.9)", duration: 0.22, ease: "sine.out", yoyo: true, repeat: 1 }, OT + 1.30);
      tl.to("#cta-sub", { scale: 1.055, textShadow: "0 0 26px rgba(0,212,255,0.7)", duration: 0.43, ease: "sine.inOut", yoyo: true, repeat: 5 }, OT + 1.75);
      tl.to("#cta-title", { scale: 1.07, textShadow: "0 0 22px rgba(0,212,255,0.55)", duration: 0.43, ease: "sine.inOut", yoyo: true, repeat: 5 }, OT + 1.75);
      tl.to("#cta-halo", { scale: 1.14, autoAlpha: 0.62, duration: 0.43, ease: "sine.inOut", yoyo: true, repeat: 5 }, OT + 1.75);

      window.__timelines["main"] = tl;
    </script>
  </body>
</html>
'''

js = lambda xs: "[" + ", ".join(f2(v) for v in xs) + "]"

def _section_js(s):
    """按段配置生成该段的 JS 块：段标题动效 + 分页轮播 + 元素入场（+ 指数卡数字滚动）。

    ⚠ 逐段调用会推进 hid() 计数器 —— 生成顺序必须与 SECTIONS / SEC_HTML 一致。
    """
    name, sid, t0 = s["name"], s["sid"], T[s["name"]][0]
    parts = [
        f'      /* ============ {s["label"]} ============ */',
        f'      secChrome("{name}", "{sid}", {f2(t0)});',
        f'      pages("{name}", {js(PAGE_IN[name])});',
        js_ent(name, entrances(name, s["pages"])),
    ]
    times = _mini_times(s)
    if times:
        parts.append(f'      setupCountCards("{name}", {js(times)});')
    return "\n".join(parts)


def _mini_times(s):
    """该段**所有**含 `mini` 的屏的逐卡绝对入场时刻（与 DOM 顺序一致）。

    ★ 新结构下同一段可有 2 屏指数卡（大盘：屏1 A股 4 张 + 屏2 港韩日 3 张），
    不能再「只取第一屏的 mini_at」—— 旧写法会让第二屏的卡取到 undefined 而滚成 NaN。
    """
    out = []
    for pi, pg in enumerate(s["pages"]):
        if not pg.get("mini"):
            continue
        base = PAGE_IN[s["name"]][pi]
        offs = pg.get("mini_at") or [1.00] * len(pg["mini"])
        out += [round(base + o, 2) for o in offs]
    return out


REPL = {
    "__TOUT__": f2(t_out),
    "__SECTIONS_JS__": "\n\n".join(_section_js(s) for s in SECTIONS),
}
for k, v in REPL.items():
    JS = JS.replace(k, v)
assert "__" not in JS.replace("__timelines", ""), "JS 占位符未全部替换"

out = head + BODY_HEAD + "".join(SEC_HTML) + TAIL + JS
with open(os.path.join(HERE, "index.html"), "w", encoding="utf-8") as f:
    f.write(out)

print(f"total = {total:.2f}s")
print("分页（每屏时长 / 该屏「完整态」真实停留 = 切屏换场起点(切点-0.32s) − 最后一个元素动完）：")
for s in SECTIONS:
    name, pages = s["name"], s["pages"]
    pts = PAGE_IN[name] + [T[name][0] + T[name][1]]
    es = entrances(name, pages)
    line = []
    for i in range(len(pts) - 1):
        e = [e[1] + e[3] for e in es if e[0].startswith(f"a{i}_")]
        settled = pts[i + 1] - 0.32 - (max(e) if e else pts[i])
        line.append(f"屏{i + 1}[{pts[i]:.2f}~{pts[i + 1]:.2f} {(pts[i + 1] - pts[i]):5.1f}s "
                    f"停留{settled:4.1f}s{'' if settled >= 1.5 else ' ⚠'}]")
    print(f"  {name} (n={len(pages)})  " + "  ".join(line))
print("page 总数 =", sum(len(s["pages"]) for s in SECTIONS))
print(f"written -> {os.path.join(HERE, 'index.html')} ({len(out.splitlines())} lines)")
